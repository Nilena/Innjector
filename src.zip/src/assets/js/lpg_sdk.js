
var LPG = {};
var LPGlocalObj = {};
var callback;
LPG.Open = function (obj, auth, cb) {
	LPG.createLoader();
    LPGlocalObj.constructBackgroundBlur(obj, auth);
    callback = cb;
}
LPG.Approve = function (obj) {
    var iframe = document.getElementById("LPG_ID_IFRAME");
    if (iframe && obj && (obj.LPGInfo || obj.data)) {
        iframe.parentNode.removeChild(iframe);
        callback(obj);
    }
}
LPGlocalObj.constructBackgroundBlur = function (obj, auths) {
    var lpgIframe = document.createElement("iframe");
    lpgIframe.setAttribute("style", "width:0;height:0;border:0;border:none;");
    lpgIframe.setAttribute("id", "LPG_ID_IFRAME");
    let tokenURL = (auths && auths.encToken) ? auths.encToken : '';
    let mainURL = (auths && auths.lpgURL) ? auths.lpgURL : '';
    lpgIframe.src = mainURL + '?' + tokenURL;
    lpgIframe.onload = function () {
		
        setTimeout(function () {
			 document.getElementById('sdk-loader').remove();
        
            lpgIframe.setAttribute("style", "width:100%;height:100%;overflow:auto;background:rgb(0,0,0.5,0.3);position: fixed;z-index: 214746;top: 0;left: 0;transform: translate3d(0, 0, 0);color: #fff;display: block;");
                       let data = {
                req: obj,
                auth: auths
            }
            lpgIframe.contentWindow.postMessage(data, '*');
			
        }, 500);
    }
    document.body.appendChild(lpgIframe);
}
function bindEvent(element, eventName, eventHandler) {
    if (element.addEventListener) {
        element.addEventListener(eventName, eventHandler, false);
    } else if (element.attachEvent) {
        element.attachEvent('on' + eventName, eventHandler);
    }
}
bindEvent(window, 'message', function (e) {
    if (e && e.data) {
        if (e.data == "cancel") {
            var iframe = document.getElementById("LPG_ID_IFRAME");
            if (iframe) {
                iframe.parentNode.removeChild(iframe);
            }
        } else {
            LPG.Approve(e.data);
        }
    }
});
window.onhashchange = function () {
	 var ldr = document.getElementById('sdk-loader');
	   if (ldr) {
       document.getElementById('sdk-loader').remove();
    }
          
    var iframe = document.getElementById("LPG_ID_IFRAME");
    if (iframe) {
        iframe.parentNode.removeChild(iframe);
    }
}
LPG.createLoader = function() {
   let css = '.loader-wrp{display:none}.loader-wrp.show{display:block!important}.loader-wrp .wrap{position:fixed;display:-webkit-box;display:-ms-flexbox;display:flex;left:0;top:0;right:0;bottom:0;width:100%;height:100%;background-color:rgba(255,255,255,.33);z-index:2000!important;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center}.loader-wrp .lds-spinner{color:official;display:inline-block;position:relative;width:80px;height:80px}.loader-wrp .lds-spinner div{-webkit-transform-origin:40px 40px;-ms-transform-origin:40px 40px;transform-origin:40px 40px;-webkit-animation:lds-spinner 1.2s linear infinite;animation:lds-spinner 1.2s linear infinite}.loader-wrp .lds-spinner div:after{content:" ";display:block;position:absolute;top:3px;left:37px;width:6px;height:18px;border-radius:20%;background:#5bb9fa}.loader-wrp .lds-spinner div:nth-child(1){-webkit-transform:rotate(0);-ms-transform:rotate(0);transform:rotate(0);-webkit-animation-delay:-1.1s;animation-delay:-1.1s}.loader-wrp .lds-spinner div:nth-child(2){-webkit-transform:rotate(30deg);-ms-transform:rotate(30deg);transform:rotate(30deg);-webkit-animation-delay:-1s;animation-delay:-1s}.loader-wrp .lds-spinner div:nth-child(3){-webkit-transform:rotate(60deg);-ms-transform:rotate(60deg);transform:rotate(60deg);-webkit-animation-delay:-.9s;animation-delay:-.9s}.loader-wrp .lds-spinner div:nth-child(4){-webkit-transform:rotate(90deg);-ms-transform:rotate(90deg);transform:rotate(90deg);-webkit-animation-delay:-.8s;animation-delay:-.8s}.loader-wrp .lds-spinner div:nth-child(5){-webkit-transform:rotate(120deg);-ms-transform:rotate(120deg);transform:rotate(120deg);-webkit-animation-delay:-.7s;animation-delay:-.7s}.loader-wrp .lds-spinner div:nth-child(6){-webkit-transform:rotate(150deg);-ms-transform:rotate(150deg);transform:rotate(150deg);-webkit-animation-delay:-.6s;animation-delay:-.6s}.loader-wrp .lds-spinner div:nth-child(7){-webkit-transform:rotate(180deg);-ms-transform:rotate(180deg);transform:rotate(180deg);-webkit-animation-delay:-.5s;animation-delay:-.5s}.loader-wrp .lds-spinner div:nth-child(8){-webkit-transform:rotate(210deg);-ms-transform:rotate(210deg);transform:rotate(210deg);-webkit-animation-delay:-.4s;animation-delay:-.4s}.loader-wrp .lds-spinner div:nth-child(9){-webkit-transform:rotate(240deg);-ms-transform:rotate(240deg);transform:rotate(240deg);-webkit-animation-delay:-.3s;animation-delay:-.3s}.loader-wrp .lds-spinner div:nth-child(10){-webkit-transform:rotate(270deg);-ms-transform:rotate(270deg);transform:rotate(270deg);-webkit-animation-delay:-.2s;animation-delay:-.2s}.loader-wrp .lds-spinner div:nth-child(11){-webkit-transform:rotate(300deg);-ms-transform:rotate(300deg);transform:rotate(300deg);-webkit-animation-delay:-.1s;animation-delay:-.1s}.loader-wrp .lds-spinner div:nth-child(12){-webkit-transform:rotate(330deg);-ms-transform:rotate(330deg);transform:rotate(330deg);-webkit-animation-delay:0s;animation-delay:0s}@-webkit-keyframes lds-spinner{0%{opacity:1}100%{opacity:0}}@keyframes lds-spinner{0%{opacity:1}100%{opacity:0}}';
    if (!('remove' in Element.prototype)) {
  Element.prototype.remove = function() {
      if (this.parentNode) {
          this.parentNode.removeChild(this);
      }
  };
}
    let style = document.createElement('style');
    document.head.appendChild(style);
    style.type = 'text/css';
    if (style.styleSheet){
style.styleSheet.cssText = css;
} else {
style.appendChild(document.createTextNode(css));
}
document.body.insertAdjacentHTML('beforeend', '<div class="loader-wrp show" id="sdk-loader"><div class="wrap"><div class="lds-spinner"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div></div></div>');
  }

