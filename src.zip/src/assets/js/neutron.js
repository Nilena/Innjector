/* eslint-disable */ 
"use strict";

var _this = void 0;

/* ==========================================================================
   Neutron Button Groups - Toggle Buttons
   ========================================================================== */

/* defines and assigns all dropdown tabs */
var buttonToggles = document.querySelectorAll('.neu-button-toggles .neu-button-toggles__button');
/* iterates over all buttons in node list */

Object.keys(buttonToggles).map(function (b) {
  /* adds event listener to buttons */
  buttonToggles[b].addEventListener('click', handleButtonToggle);
});
/* removes button class */

function buttonOff() {
  Object.keys(buttonToggles).map(function (t) {
    buttonToggles[t].classList.remove('neu-button-toggles__button-active');
  });
}
/* toggles button class */


function handleButtonToggle(e) {
  // clears active button
  buttonOff();
  e.currentTarget.classList.toggle('neu-button-toggles__button-active');
}
/* ==========================================================================
   Neutron Chip
   ========================================================================== */


var chips = document.querySelectorAll('.neu-chip--interact');
Object.keys(chips).map(function (c) {
  chips[c].addEventListener('click', handleChipClick);
});

function handleChipClick(e) {
  /* if the target is the action button it removes chip */
  if (e.target.className.includes('neu-chip__action')) {
    this.parentNode.removeChild(this);
  }
}
/* ================================================================================
  Dropdown
  ================================================================================ */

/* defines and assigns all dropdown tabs */


var dropdownTabs = document.querySelectorAll('.neu-dropdown--tab .neu-tablist__tab');
/* iterates over all dropdown tabs in node list */

Object.keys(dropdownTabs).map(function (t) {
  /* adds event listener to each tab that has a dropdown */
  dropdownTabs[t].addEventListener('click', handleDropdownClick);
});
/* defines function that toggles visibility of dropdown content */

function handleDropdownClick(e) {
  // clears all active dropdowns
  removeActiveDropdowns();
  e.currentTarget.nextElementSibling.classList.toggle('neu-dropdown__is-active');
}
/* removes visibility class of dropdown content
 * when user clicks off of the menu
 */


document.addEventListener('mouseup', function (e) {
  var isTab = e.target.classList.contains('.neu-tablist__tab');

  if (!isTab) {
    removeActiveDropdowns();
  }
});

function removeActiveDropdowns() {
  var dropdownContent = document.querySelectorAll('.neu-dropdown--tab .neu-dropdown__content');
  Object.keys(dropdownContent).map(function (c) {
    dropdownContent[c].classList.remove('neu-dropdown__is-active');
  });
}

document.onkeydown = function (evt) {
  evt = evt || window.event;

  if (evt.keyCode == 27) {
    removeActiveDropdowns();
  }
};
/* ========================================================================
  File Uploader
  ======================================================================== */


(function () {
  var InputFile = function InputFile(element) {
    this.element = element;
    this.input = this.element.getElementsByClassName('neu-uploader__input')[0];
    this.label = this.element.getElementsByClassName('neu-uploader__label')[0];
    this.multipleUpload = this.input.hasAttribute('multiple'); // allows for multiple files selection
    // when user selects a file, neu-uploader__text will populate with the uploaded file's name

    this.labelText = this.element.getElementsByClassName('neu-uploader__text')[0];
    this.initialLabel = this.labelText.textContent;
    initInputFileEvents(this);
  };

  function initInputFileEvents(inputFile) {
    // makes label focusable
    inputFile.label.setAttribute('tabindex', '0');
    inputFile.input.setAttribute('tabindex', '-1'); // triggered when file is selected or the file picker modal is closed

    inputFile.input.addEventListener('focusin', function (event) {
      inputFile.label.focus();
    }); // 'enter' key triggers file selection

    inputFile.label.addEventListener('keydown', function (event) {
      if (event.keyCode && event.keyCode == 13 || event.key && event.key.toLowerCase() == 'enter') {
        inputFile.input.click();
      }
    }); // file has been selected -> update label text

    inputFile.input.addEventListener('change', function (event) {
      updateInputLabelText(inputFile);
    });
  }

  function updateInputLabelText(inputFile) {
    var label = '';

    if (inputFile.input.files && inputFile.input.files.length < 1) {
      label = inputFile.initialLabel; // no selection -> revert to initial label
    } else if (inputFile.multipleUpload && inputFile.input.files && inputFile.input.files.length > 1) {
      label = inputFile.input.files.length + ' files'; // multiple selection -> show number of files
    } else {
      label = inputFile.input.value.split('\\').pop(); // single file selection -> show name of the file
    }

    inputFile.labelText.textContent = label;
  } //initialize the InputFile objects


  var inputFiles = document.getElementsByClassName('neu-uploader');

  if (inputFiles.length > 0) {
    for (var i = 0; i < inputFiles.length; i++) {
      (function (i) {
        new InputFile(inputFiles[i]);
      })(i);
    }
  }
})();
/* ==========================================================================
   Navigation - Mobile
   ========================================================================== */
// Switches the Menu Icon onclick


function mobileMenuIconSwitch() {
  var menuIcon = document.getElementById('neu-mobile-nav__icon-switch');

  if (menuIcon.innerHTML === 'menu') {
    menuIcon.innerHTML = 'close';
    openMobileNav();
  } else {
    menuIcon.innerHTML = 'menu';
    closeMobileNav();
  }
}

function openMobileNav() {
  document.querySelector('.neu-mobile-nav').style.width = '100%';
}

function closeMobileNav() {
  document.querySelector('.neu-mobile-nav').style.width = '0';
}

var mobNav = document.querySelector('.neu-mobile-nav');
var mobNavParents = [];
var mobNavMenus = [];

if (mobNav) {
  mobNav.addEventListener('click', function (event) {
    if (typeof event.target.dataset.childMenu !== 'undefined') {
      var childMenu = getChildMenu(event.target);
      showMenu(childMenu);
      event.preventDefault();
    }

    if (event.target.classList.contains('neu-nav-mobile__button_back')) {
      resetMenu();
    }
  });
}

function getChildMenu(element) {
  var selector = element.dataset.childMenu;
  var childMenu = document.querySelector(selector);
  return childMenu;
}

function showMenu(menu) {
  mobNavParents.push(menu.parentElement);
  mobNavMenus.push(menu);
  menu.remove();
  menu.style.transform = 'translateX(100%)';
  mobNav.appendChild(menu);
  setTimeout(reveal, 0);
}

function reveal() {
  var menu = mobNavMenus[mobNavMenus.length - 1];
  var prev = menu.previousElementSibling;
  menu.style.transform = 'translateX(0)';
  prev.style.transform = 'translateX(-100%)';
}

function resetMenu() {
  if (mobNavParents.length === 0 || mobNavMenus.length === 0) {
    return;
  }

  var menu = mobNavMenus[mobNavMenus.length - 1];
  var prev = menu.previousElementSibling;
  menu.style.transform = 'translateX(100%)';
  prev.style.transform = 'translateX(0)';
  mobNav.addEventListener('transitionend', hide, {
    once: true
  });
}

function hide() {
  var menu = mobNavMenus.pop();
  var parent = mobNavParents.pop();
  menu.remove();
  parent.appendChild(menu);
}
/* ================================================================================
   POLYFILLS JS
   ================================================================================ */

/* ==============================
   NodeList FOREACH
   ============================== */


if (window.NodeList && !NodeList.prototype.forEach) {
  NodeList.prototype.forEach = Array.prototype.forEach;
}
/* ==============================
   Element CLOSEST
   ============================== */


if (!Element.prototype.matches) {
  Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector;
}

if (!Element.prototype.closest) {
  Element.prototype.closest = function (s) {
    var el = _this;

    do {
      if (el.matches(s)) return el;
      el = el.parentElement || el.parentNode;
    } while (el !== null && el.nodeType === 1);

    return null;
  };
}
/* eslint-disable no-tabs */

/* ==========================================================================
   Neutron Radio
   ========================================================================== */


var NeutronRadioButton = function NeutronRadioButton(domNode, groupObj) {
  this.domNode = domNode;
  this.radioGroup = groupObj;
  this.keyCode = Object.freeze({
    RETURN: 13,
    SPACE: 32,
    END: 35,
    HOME: 36,
    LEFT: 37,
    UP: 38,
    RIGHT: 39,
    DOWN: 40
  });
};

NeutronRadioButton.prototype.init = function () {
  this.domNode.tabIndex = -1;
  this.domNode.setAttribute('aria-checked', 'false');
  this.domNode.addEventListener('keydown', this.handleKeydown.bind(this));
  this.domNode.addEventListener('click', this.handleClick.bind(this));
  this.domNode.addEventListener('focus', this.handleFocus.bind(this));
  this.domNode.addEventListener('blur', this.handleBlur.bind(this));
};
/* EVENT HANDLERS */


NeutronRadioButton.prototype.handleKeydown = function (e) {
  var flag = false;

  switch (e.keyCode) {
    case this.keyCode.SPACE:
    case this.keyCode.RETURN:
      this.radioGroup.setChecked(this);
      flag = true;
      break;

    case this.keyCode.UP:
      this.radioGroup.setCheckedToPreviousItem(this);
      flag = true;
      break;

    case this.keyCode.DOWN:
      this.radioGroup.setCheckedToNextItem(this);
      flag = true;
      break;

    case this.keyCode.LEFT:
      this.radioGroup.setCheckedToPreviousItem(this);
      flag = true;
      break;

    case this.keyCode.RIGHT:
      this.radioGroup.setCheckedToNextItem(this);
      flag = true;
      break;

    default:
      break;
  }

  if (flag) {
    e.stopPropagation();
    e.preventDefault();
  }
};

NeutronRadioButton.prototype.handleClick = function () {
  this.radioGroup.setChecked(this);
};

NeutronRadioButton.prototype.handleFocus = function (e) {// this.domNode.classList.add('neu-radio--is-checked');
};

NeutronRadioButton.prototype.handleBlur = function (e) {// this.domNode.classList.remove('neu-radio--is-checked');
};
/* Radiogroups */


var NeutronRadioGroup = function NeutronRadioGroup(domNode) {
  this.domNode = domNode;
  this.radioButtons = [];
  this.firstNeutronRadio = null;
  this.lastNeutronRadio = null;
};

NeutronRadioGroup.prototype.init = function () {
  var _this2 = this;

  // ensures radiogroup role is added
  if (!this.domNode.getAttribute('role')) {
    this.domNode.setAttribute('role', 'radiogroup');
  }

  var radios = this.domNode.querySelectorAll('.neu-radio');
  radios.forEach(function (r) {
    var radio = new NeutronRadioButton(r, _this2);
    radio.init();

    _this2.radioButtons.push(radio);

    !_this2.firstNeutronRadio ? _this2.firstNeutronRadio = radio : _this2.lastNeutronRadio = radio;
  });
  this.firstNeutronRadio.domNode.querySelector('.neu-radio__button').tabIndex = 0;
};

NeutronRadioGroup.prototype.setChecked = function (currentItem) {
  var radio = currentItem.domNode.querySelector('.neu-radio__button');
  this.radioButtons.forEach(function (b) {
    var button = b.domNode.querySelector('.neu-radio__button');
    button.setAttribute('aria-checked', 'false');
    button.classList.remove('neu-radio--is-checked');
    button.tabIndex = -1;
  });
  radio.setAttribute('aria-checked', 'true');
  radio.classList.add('neu-radio--is-checked');
  radio.tabIndex = 0;
  radio.focus();
};

NeutronRadioGroup.prototype.setCheckedToPreviousItem = function (currentItem) {
  var index;

  if (currentItem === this.firstNeutronRadio) {
    this.setChecked(this.lastNeutronRadio);
  } else {
    index = this.radioButtons.indexOf(currentItem);
    this.setChecked(this.radioButtons[index - 1]);
  }
};

NeutronRadioGroup.prototype.setCheckedToNextItem = function (currentItem) {
  var index;

  if (currentItem === this.lastNeutronRadio) {
    this.setChecked(this.firstNeutronRadio);
  } else {
    index = this.radioButtons.indexOf(currentItem);
    this.setChecked(this.radioButtons[index + 1]);
  }
};
/* Component Variables */


var neuRadios = document.querySelectorAll('.neu-radiogroup');
neuRadios.forEach(function (r) {
  var rg = new NeutronRadioGroup(r);
  rg.init();
});
/* ==========================================================================
   Neutron Sidenav - Tabbed
   ========================================================================== */

function switchTab(event, tabList) {
  var i, tabContent, tabs; // variables
  // Hide tab content

  tabContent = document.getElementsByClassName('neu-sidenav--tabbed__list');

  for (i = 0; i < tabContent.length; i++) {
    tabContent[i].style.display = 'none';
  } // Remove tab "active" class


  tabs = document.getElementsByClassName('neu-tablist__tab');

  for (i = 0; i < tabs.length; i++) {
    tabs[i].className = tabs[i].className.replace(' neu-tablist__tab-on-light--is-active', '');
  } // Show current tab content and assign "active"


  document.getElementById(tabList).style.display = 'block';
  event.currentTarget.className += ' neu-tablist__tab-on-light--is-active';
}
/* ==========================================================================
   Neutron Tooltip
   ========================================================================== */


var tip = {
  tooltip: null,
  parent: null,
  timer: null
};
/* initialisation function */

tip.init = function () {
  // if the necessary collection is supported
  if (typeof document.getElementsByTagName !== 'undefined') {
    // get all tags
    tip.tags = document.querySelectorAll('.neu-tooltip');
    Object.keys(tip.tags).map(function (t) {
      tip.tags[t].onfocus = tip.focusTimer;
      tip.tags[t].onmouseover = tip.focusTimer;
      tip.tags[t].onmouseout = tip.blurTip;
      tip.tags[t].onblur = tip.blurTip;
    });
  }
};
/* setup initialisation function */


if (typeof window.addEventListener !== 'undefined') {
  // .. gecko, safari, konqueror and standard
  window.addEventListener('load', tip.init, false);
} else if (typeof document.addEventListener !== 'undefined') {
  // .. opera 7
  document.addEventListener('load', tip.init, false);
} else if (typeof window.attachEvent !== 'undefined') {
  // .. win/ie
  window.attachEvent('onload', tip.init);
}
/* find object position */


tip.getRealPosition = function (ele, dir) {
  tip.pos = dir === 'x' ? ele.offsetLeft : ele.offsetTop;
  tip.tmp = ele.offsetParent;

  while (tip.tmp != null) {
    tip.pos += dir === 'x' ? tip.tmp.offsetLeft : tip.tmp.offsetTop;
    tip.tmp = tip.tmp.offsetParent;
  }

  return tip.pos;
};
/* delay timer */


tip.focusTimer = function (e) {
  if (tip.timer != null) {
    clearInterval(tip.timer); // clear timer

    tip.timer = null;
    /* if the current element is not the parent tooltip finds parent with class 'neu-tooltip' and assign to 'e' */
    // if (!e.classList.contains('neu-tooltip')) {
    //   e = findParentWithClass(e, 'neu-tooltip');
    // }

    tip.focusTip(e);
  } else {
    tip.tmp = e ? e.target : e.srcElement; // get focused object to pass back through timer

    tip.timer = setInterval(function () {
      return tip.focusTimer(tip.tmp);
    }, 250); // set interval
  }
};
/* create tooltip */


tip.focusTip = function (obj) {
  tip.blurTip(); // remove any existing tooltip
  // if tooltip is null

  if (tip.tooltip == null) {
    // get window dimensions
    if (typeof window.innerWidth !== 'undefined') {
      tip.window = {
        x: window.innerWidth,
        y: window.innerHeight
      };
    } else if (typeof document.documentElement.offsetWidth !== 'undefined') {
      tip.window = {
        x: document.documentElement.offsetWidth,
        y: document.documentElement.offsetHeight
      };
    } else {
      tip.window = {
        x: document.body.offsetWidth,
        y: document.body.offsetHeight
      };
    }
    /* create toolTip, detecting support for namespaced element creation, in case we're in the XML DOM */


    tip.tooltip = typeof document.createElementNS !== 'undefined' ? document.createElementNS('http://www.w3.org/1999/xhtml', 'div') : document.createElement('div');
    var randomIdentifier = Math.floor(Math.random() * 10000);
    /* add classname and unique id */

    tip.tooltip.setAttribute('id', "tooltip".concat(randomIdentifier));
    tip.tooltip.setAttribute('class', 'neu-tooltip--active');
    obj.setAttribute('aria-describedby', "tooltip".concat(randomIdentifier));
    /* get focused object co-ordinates */

    if (tip.parent == null) {
      tip.parent = {
        x: tip.getRealPosition(obj, 'x'),
        y: tip.getRealPosition(obj, 'y') + 10
      };
    }
    /* offset tooltip from object */


    tip.parent.y += obj.offsetHeight; // apply tooltip position

    tip.tooltip.style.left = tip.parent.x + 'px';
    tip.tooltip.style.top = tip.parent.y + 'px';
    /* write in title attribute */

    var tipText = obj.getAttribute('tooltip-data');
    tip.tooltip.appendChild(document.createTextNode(tipText));
    /* add to document */

    document.getElementsByTagName('body')[0].appendChild(tip.tooltip);
    /* restrict width */

    if (tip.tooltip.offsetWidth > 200) {
      tip.tooltip.style.width = '200px';
    }
    /* get tooltip tip.extent */


    tip.extent = {
      x: tip.tooltip.offsetWidth,
      y: tip.tooltip.offsetHeight
    };
    /* if tooltip exceeds window width */

    if (tip.parent.x + tip.extent.x >= tip.window.x) {
      // shift tooltip left
      tip.parent.x -= tip.extent.x;
      tip.tooltip.style.left = tip.parent.x + 'px';
    }
    /* get scroll height */


    if (typeof window.pageYOffset !== 'undefined') {
      tip.scroll = window.pageYOffset;
    } else if (typeof document.documentElement.scrollTop !== 'undefined') {
      tip.scroll = document.documentElement.scrollTop;
    } else {
      tip.scroll = document.body.scrollTop;
    }
    /* if tooltip exceeds window height */


    if (tip.parent.y + tip.extent.y >= tip.window.y + tip.scroll) {
      // shift tooltip up
      tip.parent.y -= tip.extent.y + obj.offsetHeight + 4;
      tip.tooltip.style.top = tip.parent.y + 'px';
    }
    /* centers tooltip below subject */


    var width = (tip.tooltip.offsetWidth - 24) / 2;
    tip.tooltip.style.marginLeft = "-".concat(width, "px");
    /* Creates transition animation */

    setTimeout(function () {
      if (tip.tooltip == null) {
        tip.tooltip.style.opacity = 0;
      } else {
        tip.tooltip.style.opacity = 1;
      }
    }, 400);
  }
}; // remove tooltip


tip.blurTip = function (e) {
  // if tooltip exists
  if (tip.tooltip != null) {
    // remove and nullify tooltip
    document.getElementsByTagName('body')[0].removeChild(tip.tooltip);
    e.currentTarget.setAttribute('aria-describedby', '');
    tip.tooltip = null;
    tip.parent = null;
  } // cancel timer


  clearInterval(tip.timer);
  tip.timer = null;
};
/* ================================================================================
   UTILS JS
   ================================================================================ */
// traverses dom nodes until it finds parent that has the desired class


function findParentWithClass(el, cls) {
  while (el.parentNode) {
    el = el.parentNode;

    if (el.classList.contains(cls)) {
      return el;
    }
  }

  return null;
}