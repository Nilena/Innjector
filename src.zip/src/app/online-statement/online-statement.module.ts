import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

import { SharedModule } from '../shared/shared.module';

import { StatementListingComponent } from './statement-listing/statement-listing.component';
import { StatementFilterComponent } from './statement-filter/statement-filter.component';
import { NgxExtendedPdfViewerModule } from 'ngx-extended-pdf-viewer';


const routes: Routes = [{
  path: 'listing',
  component: StatementListingComponent
}, {
  path: 'listing/:id',
  component: StatementListingComponent
}

]


@NgModule({
  declarations: [
    StatementListingComponent,
    StatementFilterComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild(routes),
    FormsModule, ReactiveFormsModule,
    NgxExtendedPdfViewerModule
  ]
})
export class OnlineStatementModule { }
