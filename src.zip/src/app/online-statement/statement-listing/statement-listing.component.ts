import { Component, OnInit, asNativeElements, Renderer2, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from '../../auth/services/user.service';
import { UtilityService } from '../../shared/services/utility.service';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ApiResponse } from 'src/app/core/models/auth';
import { FilterData } from 'src/app/core/models/histroy and online state';

@Component({
  selector: 'app-statement-listing',
  templateUrl: './statement-listing.component.html',
  styleUrls: ['./statement-listing.component.css']
})
export class StatementListingComponent implements OnInit {
  showPdfView: boolean = false;
  filterOpen: boolean = false;
  clientDetails: FilterData | null = null;
  recievedPdf: string = "";
  showDiv: boolean = true;
  payload: any = {};
  loaderOne: boolean = false;
  loaderTwo: boolean = false;
  @ViewChild('Statement') Statement! : ElementRef;
  constructor(private router: Router,
    private userService: UserService,
    public utility: UtilityService,
    private _renderer: Renderer2,
    private http: HttpClient,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    if (this.activatedRoute.snapshot.paramMap.get('id')) {
      let payloadItem = this.activatedRoute.snapshot.paramMap.get('id');
      payloadItem = atob(payloadItem as string);
      this.payload = JSON.parse(payloadItem);
      this.selectedItems(this.payload);
    }
    this.getOnlineData();
  }
  ngAfterViewInit(){
    this.Statement.nativeElement.focus();
 }

  filterToggle() {
    this.filterOpen = !this.filterOpen;
    this.showPdfView = false;
  }

  /**
    * @desc:to get filter data (for facility)
    * @author:Nilena Alexander
  */
  getOnlineData() {
    this.utility.loader.next(true);
    this.showDiv = false;
    let payload = { "ClientCode": "none", "Flag": "ClientName", "AccountNo": "none" };
    let endpoint = getApiUrl(apiList.onlineStatements.getFilterData);
    this.http.post<ApiResponse>(endpoint, payload).subscribe((data) => {
      if (data.Status == true) {
        this.clientDetails = data.Data as FilterData;
        this.utility.loader.next(false)
        this.showDiv = true;
      }
      else {
        this.utility.loader.next(false)
        this.showDiv = true;
        this.utility.alert.toast({ title: data.Message, type: 'error' });
      }
      this.utility.loader.next(false);

    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.utility.loader.next(false);
      this.showDiv = true;
    })
  }

  closeEvent(event: any) {
    this.filterToggle();
    if (Object.keys(this.payload).length)
    this.selectedItems(this.payload);
  }
  // Add body-print-visibility
  // @author : Arjun 
  beforePrint() {
    this._renderer.addClass(document.body, 'body-print-visibility');
  }

  // Remove body-print-visibility
  // @author : Arjun 
  afterPrint() {
    this._renderer.removeClass(document.body, 'body-print-visibility');
  }

  /**
    * @desc  :get emited value  from filter and get api details for pdf
    * @author:Nilena Alexander
  */
  selectedItems(event: any) {
    if (event) {
      this.utility.loader.next(true);
      this.filterOpen = false;
      let endpoint = getApiUrl(apiList.onlineStatements.PatientStatement);
      this.utility.loader.next(true);
      this.http.post<ApiResponse>(endpoint, event).subscribe((data) => {
        if (data.Status == true) {
          this.showPdfView = true;
          this.recievedPdf = data.Data.statementData[0].statementDataBinary;
          if (data.Message)
            this.utility.alert.toast({ title: data.Message, type: 'success' });
          this.showPdfView = true;
          this.utility.loader.next(false);
        }
        else {
          this.showPdfView = false;
          if (data.Message)
            this.utility.alert.toast({ title: data.Message, type: 'error' });
        }
        this.utility.loader.next(false);
      }, (err: HttpErrorResponse) => {
        console.log(err);
        this.showPdfView = false;
        this.utility.loader.next(false);
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      })
    }
    else {
      this.showPdfView = false;
      this.filterOpen = false;
      this.getOnlineData();
    }
  }

}