import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StatementFilterComponent } from './statement-filter.component';

describe('StatementFilterComponent', () => {
  let component: StatementFilterComponent;
  let fixture: ComponentFixture<StatementFilterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StatementFilterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StatementFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
