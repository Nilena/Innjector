import { Component, OnInit, Input, Output, EventEmitter, NgZone } from '@angular/core';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ApiResponse } from 'src/app/core/models/auth';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { AccountNo, DatesArr, ClientDetails } from '../../core/models/histroy and online state';
import { Router } from '@angular/router';


@Component({
  selector: 'app-statement-filter',
  templateUrl: './statement-filter.component.html',
  styleUrls: ['./statement-filter.component.css']
})
export class StatementFilterComponent implements OnInit {
  dates: DatesArr[] = [];
  accountNumbers: AccountNo[] = [];
  facilities: ClientDetails[] = [];
  statementId: number | null = null;
  ClientCode: string | null = null;
  accNumber: string | null = null;
  clientFtchLdr: boolean = false;
  accNoFtchLdr: boolean = false;
  dateFtchLdr: boolean = false;
  submitted: boolean = false;
  selectedArray: any = {};
  @Output() selectedData = new EventEmitter();
  @Output()closeFn = new EventEmitter();
  constructor(private http: HttpClient,
    private utility: UtilityService,
    private router :Router) { }
  /**
   * @desc: to get data from parent component to set value in  facility field 
   * @author:Nilena Alexander
   */
  @Input() set ClientDetails(value: any) {
    if (value && value?.Client && value?.Client?.length) {
      this.clientFtchLdr = true;
      for (let i = 0; i < value?.Client?.length; i++) {
        this.facilities.push({ 'ClientName': value?.Client[i]?.ClientName, 'ClientCode': value?.Client[i]?.ClientCode })
      }
      this.clientFtchLdr = false;
      this.facilities = [...this.facilities];
    }
  }
  @Input() set routeParams(value: any) {
    this.selectedArray = value;
  }

  ngOnInit(): void {
    this.setData();
  }

  setData() {
    if (this.selectedArray && this.selectedArray.ClientCode) {
      this.selectedFacility(this.selectedArray.ClientCode);
    }
  }


  /**
    * @desc: Filter to apply
    * @author:Nilena Alexander
  */
  filterApply() {
    this.submitted = true;
    if (!this.ClientCode || !this.accNumber || !this.statementId) {
      return;
    } else {
      let payload = {
        'ClientCode': this.ClientCode,
        'AccountNo': this.accNumber,
        'ID': this.statementId,
      }
      this.selectedData.emit(payload);
    }
  }
  /**
    * @desc:to get data for accdetails from selected facilty
    * @author:Nilena Alexander
  */
  selectedFacility(event: any) {
    this.dates = [];
    this.accountNumbers = [];
    this.accNoFtchLdr = true;
    this.ClientCode = event;
    let endpoint = getApiUrl(apiList.onlineStatements.getFilterData);
    let payload = { "Flag": "AccountNo", "ClientCode": event, "AccountNo": "" };
    this.http.post<ApiResponse>(endpoint, payload).subscribe((data) => {
      if (data.Status == true) {
        if (data.Data.AccountNo && data.Data.AccountNo.length) {
          for (let i = 0; i < data.Data.AccountNo.length; i++) {
            this.accountNumbers.push({ 'AccountNo': data.Data.AccountNo[i], 'AccName': data.Data.AccountNo[i] })
          }
        }
        this.accountNumbers = this.utility.deepCopy(this.accountNumbers);
        this.accNoFtchLdr = false;
        if (this.selectedArray && this.selectedArray.AccountNo) {
          this.selectedAccountNumber(this.selectedArray.AccountNo);
        }
      } else {
        this.accNoFtchLdr = false;
        this.utility.alert.toast({ title: data.Message, type: 'error' });
      }
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.accNoFtchLdr = false;
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }
  /**
    * @desc:to get api data for date from selected facilty and accnumber
    * @author:Nilena Alexander
  */
  selectedAccountNumber(event: any) {
    this.dateFtchLdr = true;
    this.accNumber = event;
    this.dates = [];
    let endpoint = getApiUrl(apiList.onlineStatements.getFilterData);
    let payload = { "Flag": "Date", "ClientCode": this.ClientCode, "AccountNo": this.accNumber };
    this.http.post<ApiResponse>(endpoint, payload).subscribe((data) => {
      if (data.Status == true) {
        if (data.Data.Dates && data.Data.Dates.length) {
          for (let i = 0; i < data.Data.Dates.length; i++) {
            this.dates.push({ 'StatementDate': data.Data.Dates[i].StatementDate, 'StatementID': data.Data.Dates[i].StatementID })
          }
        }
        this.dates = this.utility.deepCopy(this.dates);
        this.dateFtchLdr = false;
        if (this.selectedArray && this.selectedArray.ID) {
          this.statementId = (this.selectedArray.ID);
        }
      }
      else {
        this.dateFtchLdr = false;
        this.utility.alert.toast({ title: data.Message, type: 'error' });
      }
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.dateFtchLdr = false;
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }
  /**
    * @desc:to selected date
    * @author:Nilena Alexander
  */
  selectedDates(event: any) {
    this.statementId = event;
    // this.filterData.controls.date = this.utility.deepCopy(this.dates);
  }
  /**
    * @desc:to cancel all data
    * @author:Nilena Alexander
  */
  close() {
    // this.selectedArray = null;
     this.closeFn.emit(null);
  }
  reset(){
    if (this.utility.isMobile()){
      if(Object.keys(this.selectedArray).length)
      this.router.navigate(['/online-statement/listing'])
      else
      this.selectedData.emit(null);
    }else{
      if(Object.keys(this.selectedArray).length)
      this.router.navigate(['/online-statement/listing'])
      else{
        this.dates = []
        this.accountNumbers = [];
        this.facilities = []
        this.selectedData.emit(null);
      }
    }
  }
}
