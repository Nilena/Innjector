import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse
} from '@angular/common/http';
import { EmptyError, Observable, of, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { UserService } from '../auth/services/user.service';
import { Router } from '@angular/router';
import { isTokenIgnore } from './constants/api-list';
import { UtilityService } from '../shared/services/utility.service';

@Injectable()
export class MainInterceptor implements HttpInterceptor {
  constructor(
    private userService: UserService,
    private router: Router,
    private utility: UtilityService
  ) { }

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    if (!window.navigator.onLine) {
      // if there is no internet, throw a HttpErrorResponse error
      // since an error is thrown, the function will terminate here
      this.utility.alert.toast({ title: 'No Network Connection!', type: 'error' });
      let error = {
        message: 'No Network Connection!'
      }
      return throwError(new HttpErrorResponse({ error }));
      // return Observable.throw(new HttpErrorResponse({ error: 'Internet is required.' }));
    } else {
      // else return the normal request
      // return next.handle(request);
      const authToken = this.userService.getAuthToken();
      let sourceReq = request.clone();
      if (authToken && isTokenIgnore(request.url)) {
        sourceReq = sourceReq.clone({
          headers: request.headers.set('token', authToken)
        })
      }
      return next.handle(sourceReq).pipe(catchError((error) => {
        let message = 'Something went wrong!';
        if (error instanceof HttpErrorResponse && (!error.status || error.status == 401 || error.status == 403)) {
          this.utility.resetLoader.next(true);
          // this.utility.alert.toast({type: 'error', title: 'We encountered an issue, kindly login again.'})
          message = 'We encountered an issue, kindly login again.';
          this.userService.logout();
        }
        error.error.message = message;
        return throwError(new HttpErrorResponse(error));
        // return Observable.throw(new HttpErrorResponse(error));
      }))
    }
  }
}