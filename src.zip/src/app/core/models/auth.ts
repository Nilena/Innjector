
export interface LoginResponse {
    Data: Profile;
    IsException: boolean;
    Message: string;
    Status: boolean;
}
export interface PlanDetail {
    Status: boolean;
    scheduledPayment: string;
}
export interface ApiResponse {
    statusList: any;
    paymentplanActivityLogDetails: any;
    Data: any;
    IsException: boolean;
    Message: string;
    Status: boolean;
}
export interface Profile {
    AccountNo: string;
    ClientCode: string;
    ClientGroupID: null
    ConditionalLogin: boolean;
    EmailId: string;
    EmailLogin: null
    EmailStatus: null
    EncString: null
    FromMHO: boolean;
    IsActive: boolean;
    IsGuarantor: null
    IsGuest: boolean;
    IsMHO: boolean;
    Locked: boolean;
    LogId: number;
    LogSourceDetails: null
    LogonStatus: number;
    PeopleID: number;
    ProfileName: string;
    prefernceID: number,
    RequestToken: string;
    UserHeader: {
        AccountNo: null
        ClientCode: null
        ClientGroupCode: null
        ConditionalLogin: boolean;
        Email: string;
        EncString: null
        FacebookID: null
        FirstName: string;
        GoogleID: null
        InvalidAttempts: null
        IsActive: boolean;
        IsProvider: boolean;
        LastAccessedOn: null
        LastLockoutOn: null
        LastName: string;
        LastResetOn: null
        Locked: null
        LogId: null
        MasterClientCode: string;
        MiddleName: null
        NoOfLockOuts: null
        Password: null
        PeopleID: number;
        Phone: string;
        ProfileName: string;
        ProviderADName: null
        ProviderName: null
        RequestToken: string;
        ResetReferenceID: null
        UserID: number;
        UserName: null
        client_group_id: number;
        isRMEXUser: null,
        prefernceID: number,

    }
    UserID: number;
    UserPaymentDetails: UserPaymentDetails;
    UserType: null;
}
export interface UserPaymentDetails {
    BalanceRequiringAction: number;
    ScheduledPayments: number;
    TotalBalance: number;
}
export interface RegisterPayload {
    ConfirmEmail: string;
    ConfirmPassword: string;
    Email: string;
    FirstName: string;
    LastName: string;
    Password: string;
    PersonalData: {
        IsGuarantor: boolean | null;
        EncString: string | null;
        DOB: string | null;
        AccountNo?: string | null;
        LastFourSSN?: string | null;
    }
    UserName: string;
    Guid?: string;
}

export interface DashboardData {
    BalanceRequiringAction: number
    DashBoardItem: []
    DuplicateContinueButton: boolean
    IsRmexMultipleAccounts: boolean
    IsRmexPaymentEnable: boolean
    NewBillCount: number
    NoScheduledPaymentList: null
    RmexSchedulePaymentDetails: null
    RmexdashBoard: null
    ScheduledPayments: number
    SheduledPaymentList: {}
    ShowSurvey: boolean
    SurveyIdleTime: null
    SurveyUrl: null
    TotalBalance: number
    WarningMessagePaynow: string
    duplicateMessage: string
    duplicateMessage_x: string
    duplicatecheckstatus: boolean
    rmexMessage: string
    IsException: boolean
    Message: string
}
export interface PayData {
    openSub?: boolean
    deleteBtnLoader?: boolean
    radioBtnLoader?: boolean
    ngChecked?: boolean
    AccountHolderName: string
    AccountNo: string
    AccountType: string
    BankName: string
    CardStatus: string
    CardType: string
    CreatedBy: null
    CreatedDate: string
    CreditCardNo: string
    Details: []
    Email: string
    ErrorMessage: string
    Id: string
    ImageType: string
    IsAssociated: boolean
    IsDefault: boolean
    IsFromPMList: boolean
    LastFourDigits: string
    MerchantId: string
    MethodName: string
    Mode: string
    NewTokenId: number
    NickName: string
    ParentTokenId: number
    PaymentType: string
    PeopleId: number
    ProcessorType: string
    RoutingTransistNumber: string
    Source: string
    Status: string
    Token: string
    TokenId: number
    clientcode: string
    scrollBottom?: boolean
}
export interface PaymentResponse {
    Data: any;
    success: boolean
}
export interface TempDataResponse {
    Key: string
    UserID?: number
    Value: string
}

export interface TempData {
    HeaderID?: any;
    PaymentTokenId?: any;
    Mode: string,
    BillData: any[],
    facilities: []
    CardData?: CardItem,
    Total?: {
        balance: string,
        paid: string
    }
    selectedOption?: {}
}
export interface CardItem {
    AccountName: string
    AccountNo: string
    AccountType: string
    CardStatus: string
    Email: string
    IsAssociated: boolean
    LastFourDigits: string
    Nickname: string
    ParentTokenId: number
    PaymentType: string
    ProcessorType: string
    RoutingTransitNo: string
    SaveStatus: boolean
    Token: string
    TokenId: any
    formattedCard: string,
    CardType?: string
}

export interface AddPaymentResponse {

    Data: paymentData
    IsException: boolean
    Message: string
    Status: boolean
}

export interface paymentData {
    ProcessorMessage: [
        {
            tx_no: string,
            errorMessage: string,
            errorCode: string
        }
    ]
    ProcessorType: string
    TokenResponseList: string
    attribute1: string
    attribute2: string
    attribute3: string
    code: string
    isValid: boolean
    message: string
}

export interface ScheduledPaymentInfo {
    Pagination: null;
    RmexSchedulePaymentDetails: RmexScheduledPaymentInfo;
    ScheduledPayment: PaymentDetail[];
    ScheduledTotal: number;
    TotalMonthlyPayments: number;
  }
  export interface PaymentDetail {
    AmountDue: number;
    AmountPaid: number;
    CreatedBy: null
    CreatorType: null
    EnrollmentOn: null
    EventCode: null
    FollowupDate: null
    HeaderID: number;
    InstallmentDate: string;
    InstallmentNo: number;
    IsNoteAdded: false
    IsPastDue: false
    IsRmexAccount: false
    LastModifiedDate: null
    Name: null
    NextPaymentAmount: number;
    PeopleID: number;
    PlanAmount: number;
    PlanStatus: string;
    PrimaryCaseNumber: null
    Reason: null
    RemainingBalance: number;
    RmexBalance: number;
    RowDetailID: number;
    RowHeaderID: number;
    TotalRecords: null
    isRmex: boolean
  }
  export interface StanderdSliderInfo {
    IsPastDue?: boolean;
    IsCompleted?: boolean;
    AmountDue: number;
    AmountPaid: number;
    RemainingBalance: number;
    Rmx: boolean;
    InstallmentDate: string;
    Percentage: number;
    PlanAmount: number | string;
    HeaderID: number;
    PlanStatus: string;
    IsRmex?: boolean;
    NextPaymentAmount?:any
  }
  export interface RmexScheduledPaymentInfo {
    AmountDue: number;
    IsCompleted: boolean;
    IsPastDue: boolean;
    NextPaymentAmount: number;
    NextpaymentDate: string;
    PaidAmount: number;
    PaidDate: string;
    PeopleId: number;
    PrimaryCaseNumber: number;
    RemainingBalance: number;
    isRmexDown: boolean;
    IsRmex?:boolean
  }
  export interface MakePaymentHeaderList {
    "ChargeHeaderRowID": number;
    "ClientCode": string;
    "ClientName": string;
    "CurrentBalance": number;
    "StatementURL": null,
    "PatientPeopleID": number;
    "GuarantorPeopleID": number;
    "PatientName": string;
    "GuarantorName": string;
    "PatientAccountNo": string;
    "DateOfService": string;
    "PaymentAmount": number;
    "Cnid": null,
    "UPID": number;
    "ItemCode": string;
    "StationCode": string;
    "ClientGroupCode": string;
    "PhysicianName": null,
    "PhysicianID": null,
    "FacilityID": null,
    "HeaderRowID": number;
    "RemainingAmount": number;
    "BalanceRequiringAction": number;
    "ClientType": string;
    "BillNumber": null,
    "Email": null,
    "DOB": null,
    "ArrangementAmount": number;
    "OriginalPlanAmount": number;
    "BalancePlanAmount": null,
    "NoOfInstallments": number;
    "FirstInstallmentDate": string;
    "PlanStatus": string;
    "PlanStatusDescription": null,
    "PaymentMethod": string;
    "PaymentMethodType": null,
    "Frequency": null,
    "AccountNumber": string;
    "InstallmentAmount": null,
    "PaymentTokenId": number;
    "LastFourDigits": string;
    "CardType": null,
    "EditStatus": boolean;
    "Reason": null,
    "TotalScheduledPayments": number;
    "TotalScheduledAmount": null,
    "TotalAmountDue": 344.99,
    "TotalPaid": number;
    "MinNoInstallment": number;
    "MaxNoInstallment": number;
    "EditFlag": number;
    "IsRmex": boolean;
    "CurrentChargeHeaderAmount": number;
    "TermsAndConditions": string;
    "CreatedBy": null,
    "CreatorType": null,
    "AgencyCode": null,
    "AgencyName": null,
    "AgencyPhone": null,
    "restricted_account_status": null,
    "MerchantId": null,
    "txhistory": null,
    "PaymentPlanHeaderID": number;
    "IsPaymentPlanAddBalance": boolean;
    "AddbalanceAgreedDate": string;
    "PlanPaymentOption": number;
    "ProcessorType": string;
    _open?: boolean;
  }
  
  export interface ScheduledInstallment {
    "SerailNo": number;
    "ScheduledDate": string;
    "ScheduledAmount": number;
    "PaymentType": string;
    "PaidStatus": string;
    "InstallmentStatus": string;
    "PaidDate": null,
    "ScheduledDateTime": null,
    "AmountPaid": number;
    "PlanDetailRowId": number;
    "IsTransactionDone": boolean;
    "Distribution": null
  }
  
  export interface PaymentPlanHeaderDetails {
    "TotalPaymentAmount": number;
    "PaymentMethodName": string;
    "NoOfInstallments": number;
    "PlanStatus": string;
    "FirstPaymentDate": string;
    "Frequency": string;
    "Email": string;
    "TotalRemaingAmount": number;
    "TotalArragementAmount": number;
    "TotalBalanceReqAction": number;
    "PlanHeaderID": number;
    "EditFlag": number;
    "PaymentTokenId": number;
    "TermsAndConditions": string;
    "OriginalPlanAmount": number;
  }
  
  export interface PaymentPlanDetails {
    "MakePaymentHeaderList": MakePaymentHeaderList[];
    "ScheduledInstallmentList": ScheduledInstallment[];
    "PaymentPlanHeaderDetails": PaymentPlanHeaderDetails;
    "PlanStatusList": null;
    "ActivePlansCount": number;
  }