export type ToolTipPosition = 'top' | 'right' | 'bottom' | 'left';
export type AlertType = 'success' | 'error' | 'warning' | 'info';

export type SurveyConfig = {
    loginMode: string;
    popupDelay: number;
    surveyCount: number;
    surveyCountSession: number;
    responseTime: number;
}

export interface AlertInfo {
    type: AlertType;
    title: string;
    text: string;
    okText?: string;
    cancelText?: string;
    hideCancelButton?: boolean;
    isTitleCash?: boolean;
    hideOkButton?: boolean;
  }
  export interface Toast {
    title: string;
    type: AlertType,
    __disableAutoClose?: boolean;
    __clearAll?: boolean;
    __lifeSpan?: any;
    __id?: number;
    hideCloseBtn?: boolean;
  }
  export interface alertInfoTrigger extends AlertInfo {
    resolve: Function;
  }

  