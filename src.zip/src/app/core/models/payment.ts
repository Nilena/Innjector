
export type ValidationError = {
  [key: string]: {
    error?: boolean,
    message?: string,
    min?: boolean,
    max?: boolean,
    invalid?: boolean
  }
}

export interface RmexPaymentDetailsInfo {
  BalanceRequiringAction: number;
  DashBoardItem: RmexDashboardItem[];
  DuplicateContinueButton: boolean;
  IsRmexMultipleAccounts: boolean;
  IsRmexPaymentEnable: null
  NewBillCount: number;
  NoScheduledPaymentList: null
  RmexSchedulePaymentDetails: null
  RmexdashBoard: null
  ScheduledPayments: number;
  SheduledPaymentList: null
  ShowSurvey: boolean;
  SurveyIdleTime: null
  SurveyUrl: null
  TotalBalance: number;
  WarningMessagePaynow: null
  duplicateMessage: string;
  duplicateMessage_x: string;
  duplicatecheckstatus: boolean;
  rmexMessage: null
}
export interface RmexDashboardItem {
  Balance: number;
  BalanceRequiringAction: number;
  ClientCode: string;
  ClientName: string;
  ClientType: string;
  CurrentBalance: number;
  PatientBalance: PatientBalance[];
  RmexDirectCheckIndicator: null
  RmexPlanIndicator: null
  ScheduledPayments: number;
  StatementURL: null;
  _open?: boolean;
}
export interface PatientBalance {
  AccountNumber: string;
  AgencyCode: null
  AgencyName: null
  AgencyPhone: null
  ArrangementAmount: number;
  BalanceRequiringAction: number;
  BillNumber: string;
  ChargeHeaderRowID: number;
  ClientCode: string;
  ClientGroupCode: string;
  ClientName: string;
  ClientType: string;
  Cnid: null
  CurrentBalance: number;
  DateOfService: string;
  FacilityID: string;
  GuarantorName: null
  GuarantorPeopleID: null
  IsNoScheduledPayments: boolean;
  IsRmex: boolean;
  IsRmexAccount: boolean;
  ItemCode: string;
  MerchantId: string;
  NextPaymentDate: string;
  PatientAccountNo: string;
  PatientName: string;
  PatientPeopleID: number;
  PaymentAmount: number;
  PhysicianID: null
  PhysicianName: null
  ProcessorType: string;
  RemainingBalance: number;
  ResponsibleParty: string;
  RmexBalance: number;
  ScheduledPayments: null
  StatementDate: string;
  StatementID: null
  StatementName: null
  StatementURL: null
  StationCode: null
  UPID: number;
  restricted_account_status: null
  txhistory: TxHistory[];
  _checked?: boolean;
  error?: boolean;
  _backupPaymentAmount: number;
}

export interface PaymentDetailsInfo {
  BalanceRequiringAction: null
  DemograhicInfo: null
  DuplicateContinueButton: boolean;
  OthersMinAmount: number;
  PayHalfMinAmount: number;
  PayThirtyMinAmount: number;
  PaymentDetails: PaymentDetails[];
  ScheduledPayments: null
  TotalBalance: number;
  duplicateMessage: string;
  duplicateMessage_x: string;
  duplicatecheckstatus: boolean;
  dupMsg?: string;
  dupMsgFooter?: string;
  dupMsg_x?: string;
}
export interface PaymentDetails {
  ClientCode: string;
  ClientName: string;
  ClientType: string;
  PaymentHeaderDetails: PaymentHeaderDetails[]
  TotalBalanceAmount: number;
  TotalPlanAmount: number;
  _open?: boolean;
}
export interface PaymentHeaderDetails {
  AccountNumber: null
  AddbalanceAgreedDate: string;
  AgencyCode: null
  AgencyName: null
  AgencyPhone: null
  ArrangementAmount: null
  BalancePlanAmount: null
  BalanceRequiringAction: number;
  BillNumber: string;
  CardType: null
  ChargeHeaderRowID: number;
  ClientCode: string;
  ClientGroupCode: string;
  ClientName: string;
  ClientType: string;
  Cnid: null
  CreatedBy: null
  CreatorType: null
  CurrentBalance: number;
  CurrentChargeHeaderAmount: 0
  DOB: null
  DateOfService: string;
  EditFlag: null
  EditStatus: boolean;
  Email: null
  FacilityID: string;
  FirstInstallmentDate: null
  Frequency: null
  GuarantorName: string;
  GuarantorPeopleID: number;
  HeaderRowID: null
  InstallmentAmount: null
  IsPaymentPlanAddBalance: boolean;
  IsRmex: boolean;
  ItemCode: string;
  LastFourDigits: null
  MaxNoInstallment: number;
  MerchantId: string;
  MinNoInstallment: number;
  NoOfInstallments: number;
  OriginalPlanAmount: null
  PatientAccountNo: string;
  PatientName: string;
  PatientPeopleID: number;
  PaymentAmount: number;
  PaymentMethod: null
  PaymentMethodType: null
  PaymentPlanHeaderID: number;
  PaymentTokenId: null
  PhysicianID: null
  PhysicianName: null
  PlanPaymentOption: number;
  PlanStatus: null
  PlanStatusDescription: null
  ProcessorType: string;
  Reason: null
  RemainingAmount: null
  StatementURL: string;
  StationCode: string;
  TermsAndConditions: null
  TotalAmountDue: null
  TotalPaid: null
  TotalScheduledAmount: null
  TotalScheduledPayments: number;
  UPID: number;
  restricted_account_status: number;
  txhistory: TxHistory[],
  _checked?: boolean;
  error?: string;
  _backupPaymentAmount: number;
}
export interface TxHistory {
  accNo?: any;
  ClientType?: any;
  client?: any;
  claimNo?: any;
  amount: number;
  billdate: string;
  billno: string;
  chargeheaderrowid: number;
  peopleid: number;
  status: string;
  txno: number;
}
export interface InstallmentDetails {
  DownPaymentAmount: number;
  Email: string;
  FirstInstallmentDate: string;
  Frequency: string;
  InstallmentAmount: number;
  MaxInstallment: number;
  MaximumDate: string;
  MidInstallment: number;
  MinInstallment: number;
  MinInstallmentAmount: number;
  MinimumDate: string;
  NextInstallmentDate: null
  NoOfInstallment: number;
  OptionNo: number;
  PayOptions: number;
  PaymentRuleID: number;
  RuleViolationId: null
  ScheduledInstallment: ScheduledInstallment[];
  SelectedOption: null
  TermsAndCondition: string;
  TotalScheduledAmount: number;
}
export interface ScheduledInstallment {
  AmountPaid: null
  Distribution: null
  InstallmentStatus: null
  IsTransactionDone: false
  PaidDate: null
  PaidStatus: null
  PaymentType: string;
  PlanDetailRowId: number;
  ScheduledAmount: number;
  ScheduledDate: string;
  ScheduledDateTime: null
  SerailNo: number;
}

export interface PatientprocessorType {
  MerchantIds: string
  ProcessorTypes: [{
  }]
}

export interface processorType {
  ProcessorTypes: string
}
