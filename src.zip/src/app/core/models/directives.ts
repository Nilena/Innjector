/**
     * igx-mask
     */

/** @hidden */
export interface MaskOptions {
    format: string;
    promptChar: string;
}

/** @hidden */
export interface Replaced {
    value: string;
    end: number;
}
export interface IBaseEventArgs {
    /**
     * Provides reference to the owner component.
     */
    owner?: any;
}

/**
 * The IgxMaskModule provides the {@link IgxMaskDirective} inside your application.
 */
export interface IMaskEventArgs extends IBaseEventArgs {
    rawValue: string;
    formattedValue: string;
}
  /**
   * igx-mask
   */
  
  