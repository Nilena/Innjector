export interface LpgTokenResponse {
    LPGCOrderCreateUrl: string;
    LpgCCUrl: string;
    ProcessroProfile: any;
    access_token: string;
    access_token_encrypted: string;
    error: any;
    error_description: string;
    expires_in: number;
    profileid: string;
    refresh_token: string;
    token_type: string;
}
export interface LPG {
    Open: (firstParam: any, authParam: any, callback: (data: any) => void) => void;
    // Open: (firstParam: any, authParam: any, callback: (data: any) => void) => void;
}