export interface paymentHistroyDetails {
    AccountNo: string
    CaptureFlag: boolean
    CaptureResultCode: string
    ClientCode: string
    ClientName: string
    HideRefund: number
    HideReverse: number
    IsConsolidated: boolean
    ItemTranactionId: number
    PaidAmount: number
    PaidBy: string
    PaidOn: string
    PaidSource: string
    PaymentCardDetails: string
    PaymentDescription: string
    PaymentTransactionId: number
    PaymentType: string
    PaymentTypeDescription: string
    PeopleId: number
    ProcessorCode: string
    ReceiptNo: string
    TotalRecords: number
    TransactionStatus: string
    TransactionType: string
    TxnStatus: string
    TxnType: string
    tx_pmt_id: number
  }

  export interface FilterData {
    AccountNo: string,
    Client: ClientDetails,
    ClientCode: string
    ClientName: string
    Dates: string
  }
  export interface Pagination {
    CurrentPage: number,
    RecordsPerPage: number,
    TotalPages?: number
    TotalRecords?: number
  }

  export interface ClientDetails {
    ClientName: string,
    ClientCode: string
  }
  export interface AccountNo {
    AccountNo: string,
    AccName: string
  }
  export interface DatesArr {
    StatementDate: string,
    StatementID: string
  }
  export interface filterData {
    AccountNo: string,
    Client: [ClientDetails],
    ClientCode: string
    ClientName: string
    Dates: string
  }

  export interface payload {
    PaymentMethod?: string | null,
    PaymentMethods?: [],
    RecieptNo?: string,
    AmountEndRange?: string,
    AmountStartRange?: string,
    PaidFromDate?: string,
    PaidToDate?: string,
  }
  export interface ReceiptHeaderDetails {
    AuthCode: string
    Email: string
    IsConsolidated: boolean
    ManualSum: string
    OrignalTxnNo: string
    PaidBystring: string
    PaidDate: string
    PayerName: string
    PaymentDescription: string
    PaymentMode: string
    PaymentTxnId: string
    ReceiptNumber: string
    ReferenceID: number
    Source: string
    Status: string
    TotalAmount: number
    TransactionType: string,
  }
  export interface ReceiptDetailsList {
    subDetails: any
    AccountNumber: string
    AuthCode: null
    ChargerHeaderAccountNumber: string
    ClaimNumber: string
    ClientCode: string
    ClientName: string
    ClientType: string
    CommunicationEmail: string
    DateOfService: string
    Email: string
    GuarantorName: string
    ItemDescription: string
    OrginalTxnNo: string
    PaidBy: string
    PaidDate: string
    PatientName: string
    PayerName: string
    PaymentDescription: string
    PaymentMode: string
    PaymentTxnId: number
    PhysicianID: string
    PhysicianName: string
    ProcessorCode: string
    ReceiptNo: string
    ReferenceID: string
    RowAmount: number
    SourceType: string
    TotalAmount: number
    TransactionType: string
    TxnStatus: string
    openStat?: boolean
  }
  export interface receiptData {
    Consolidated: boolean,
    ReceiptDetailsList: [ReceiptDetailsList],
    ReceiptHeaderDetails: ReceiptHeaderDetails,
  }
  