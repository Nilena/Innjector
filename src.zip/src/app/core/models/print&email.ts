export interface receiptData {
    Consolidated: boolean,
    ReceiptDetailsList: [ReceiptDetailsList],
    ReceiptHeaderDetails: ReceiptHeaderDetails,
  }
  export interface ReceiptHeaderDetails {
    AuthCode: string
    Email: string
    IsConsolidated: boolean
    ManualSum: string
    OrignalTxnNo: string
    PaidBystring: string
    PaidDate: string
    PayerName: string
    PaymentDescription: string
    PaymentMode: string
    PaymentTxnId: string
    ReceiptNumber: string
    ReferenceID: number
    Source: string
    Status: string
    TotalAmount: number
    TransactionType: string,
  }
  export interface ReceiptDetailsList {
    subDetails: any
    AccountNumber: string
    AuthCode: null
    ChargerHeaderAccountNumber: string
    ClaimNumber: string
    ClientCode: string
    ClientName: string
    ClientType: string
    CommunicationEmail: string
    DateOfService: string
    Email: string
    GuarantorName: string
    ItemDescription: string
    OrginalTxnNo: string
    PaidBy: string
    PaidDate: string
    PatientName: string
    PayerName: string
    PaymentDescription: string
    PaymentMode: string
    PaymentTxnId: number
    PhysicianID: string
    PhysicianName: string
    ProcessorCode: string
    ReceiptNo: string
    ReferenceID: string
    RowAmount: number
    SourceType: string
    TotalAmount: number
    TransactionType: string
    TxnStatus: string
    openStat?: boolean
  }