export const CONSTANTS = {
    APP_CONFIG: {
        FIRST_TIME_LOADING: 'first_time_loading',
        login_config: 'login_config'
    },
    PAY_MODES: {
        ADD: "addMethod",
        ATTACH: "attachPlan",
        HALF: "payInHalf",
        NOW: "payNow",
        OTHERS: "othersPayment",
        THIRTY: "payInThirty",
        EDIT: "editMethod"
    },
    EVENTS: {
        ALERT_MSG: 'alert_msg',
        TRACK_ACTION: "trackEvent",
        SIGN_OUT: "sign_out",
        RESET_ALERT: "reset_alert",
        CHANGE_PAGE: "change_page",
        CONFIRM_POPUP_AGREE: "confirm_popup_agree",
        EMAIL_OPEN: "open_email_popup",
        LOGO_POPUP: "logo-popup-show",
        SHOW_CONFIRM_POPUP: "confirm_popup_open",
        TERMS_CONDITIONS: "terms_conditions",
        SHOW_FAQ: "open_faq_popup",
        UPDATE_PHONE_NUMBER: "update_phone_number_format",
        UPDATE_CC_DATA: "update_cc_data",
        UPDATE_EMAIL_DATA: "update_email_data",
        UPDATE_PAGINATION: "history_payment",
        UPDATE_TERMS_CONDITION: "update_terms_conditions",
        SHOW_ACTIVITY: "show_activity",
        START_POPUP: "start_popup",
        RMEX_POP: "rmex_pop",
        RMEX_POP_CLOSE: "rmex_pop_close",
        RMEX_DASH_MSG: 'rmex_dash_msg',
        RESTRICTED_POPUP: 'restricted_popup',
        SET_FOCUS: 'set-focus',
        GOOGLE_ANALYTIC_GUEST: 'google-analytic-guest',
        DOB_FUTURE: "dob-future",
        PREV_POPUP_AGREE: "prev-popup-agree",
        SHOW_PREV_POPUP: "show-prev-popup",
        CLOSE_SURVEY_POPUP: "close-survey-popup",
        PAYMENT: {
            CONFIG_METHODS: "config_payment_method",
            UPDATE_USER_INFO: "update_user_details",
        },
        HEADER: {
            UPDATE_PAYMENT_HEADER: "update_payment_details",
            UPDATE_USER_INFO: "update_user_details",
            SSO_LOGIN_SUCCESS: "sso_login_success",
        },
        HISTORY: {
            HISTORY_PAGE: "history_payment",
            RECEIPT_DETAILS: "receipt_details",
            SEARCH_UPDATED: "search_updated",
        },
        ONLINE_STATMENT: {
            GET_STATEMENT: "get_statement",
        },
        PAYMENT_PLAN: {
            DEFAULT_FILTER: "A,S"
        },
        SHOW_CHAT: {
            SHOW_CHAT: "show-chat",
            HIDE_CHAT: "hide-chat",
        }
    },
    SESSION: {
        BILL_ID: "payment_bill_id",
        PAYMENT_RESULT: "payment_result",
        PAYMENT_TEMP_ID: "paymet_temp_id",
        USER_DATA: "user_details",
        SURVEY_DATA: "survey_details",
        INIT_POPUP: "start_popup",
        SHOW_RMEX_POP: 'show_rmex_pop',
        SSO_LOGIN: 'sso_login',
        SSO_GUID: 'sso_guid',
        SPLASH_REFERROR: 'splash_refr',
        MHO_FACILITY: 'mho_facility',
        SSO_EMAIL_PPLID: 'sso_pplId',
        SSO_EMAIL_NAV: 'sso_email_nav',
        MHO_BLOCK_MSG: 'mho_block_msg',
        COM_MHO_EMAIL: 'com_mho_email',
        FROMDASH: 'from-dash',
        REG_USER: 'reg_user',
        LPG_TOKEN: 'lpg_token',
        GUID_CHAT: 'guid-for-chat'
    },
    PASSWORD_HINT: {
        PSWD_HINT: 'Password should have : At least 8 characters, one uppercase , one lower case , one number and one symbol'

    },
    statusMap: {
        "A": "Active",
        "S": "Suspended",
        "W": "Withdrawn",
        "C": "Completed"
    },
    statusClassMap: {
        "A": "neu-status--active",
        "S": "neu-status--suspended",
        "W": "neu-status--withdrawn",
        "C": "neu-status--completed"
    },

    dataArr: [{ id: 'A', name: 'Active' },
    { id: 'S', name: 'Suspended' },
    { id: 'W', name: 'Withdrawn' },
    { id: 'C', name: 'Completed' }],
    histroyfiter: [{
        'Code': "ACH",
        'Id': 1,
        'IsActive': false,
        'LongId': 0,
        'Name': "Electronic Check",
        'statusType': null,
        'ticked': true,
    }, {
        'Code': "CC",
        'Id': 2,
        'IsActive': false,
        'LongId': 0,
        'Name': "Credit Card",
        'statusType': null,
        'ticked': true,
    },
    {
        'Code': "MEMO",
        'Id': 3,
        'IsActive': false,
        'LongId': 0,
        'Name': "Memo",
        'statusType': null,
        'ticked': true,
    }],

   
}