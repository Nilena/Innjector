import { environment } from "src/environments/environment"

export const apiList = {
    auth: {
        login: 'api/account/authenticate',
        forgotUserName: 'api/account/forgotUserNameEmailSend?emailId=',
        showUsername: 'api/account/getUsernameByEmailId?',
        resetPasswrd: 'api/account/ResetPasswordMail',
        guestLogin: 'api/account/guestlogin',
        loadHospital: 'api/account/loadGuid?peopleId=',
        loadMhoHospital: 'api/account/loadGuidList?peopleId=',
        register: '/api/account/FirstFormAuth',
        getCustomMessageByName: 'api/account/getCustomMessageByName?',
        resetPasswrdFromMail: 'api/account/ResetPassword',
        resendEmailVerification: 'api/account/ActivationLinkResend',
        emailChange: 'api/account/updateEmailToUserDetails',
        communicationPreference: 'api/account/getPatientCommunicationPreference',
        saveCommunicationPreference: 'api/account/savePatientCommunicationPreference',
        getdashboarddata: 'api/dashboard/getdashboarddata',
        accountActivation: 'api/account/AccountActivation?encryptedUrlData=',
        profileUpdate: 'api/account/ProfileUpdate',
        userRegistration: 'api/account/userregistration',
        emailGuestLogin: 'api/account/EmailGuestLogin',
        emailLogin: 'api/account/AuthenticateEmail',
        getGUID: 'api/account/GetGuid',
        getPeaopleId: 'api/account/getPeopleIdFromEncoded',
        TermsAndConditon: "api/account/TermsAndConditonForRegistration",
        contactUs: "api/contactus/setcontactus",
        faq: "api/account/GetCustomMessage?messageType=8",
        faqForMob:"api/account/getCustomMessageByName?messageKey=FAQ_MOBILE",
        webChat: "api/account/getWebchatStatusandMessages",
        contactUsMsg: 'api/account/GetCustomMessage?messageType=6',
        surveySettings: 'api/survey/GetSurveySettings',
        getChat: 'api/account/getWebChatDetails',
        planActivity: 'api/paymentplan/GetPaymentPlanActivityList?PlanHeaderId',
        updateUserDetails: 'api/paymentplan/UserPaymentDetails',
        ValidateTextLinkURL: 'api/account/ValidateTextLinkURL?',
        GetAuthConfig: 'api/account/GetAuthConfig',
        TextLinkGuestLogin: 'api/account/TextLinkGuestLogin',
        AuthenticateTextLinkLogin: 'api/account/AuthenticateTextLinkLogin',
        achActivationAgree: 'api/paymentplan/achConfirmation'
    },
    common: {
        getSurveyMessage: 'api/account/getCustomMessageByName',
        getSurveyQuestion: 'api/survey/GetSurveyQuestions',
        saveSurvey: 'api/survey/SaveSurveyDetails',
        getCustomMessage: 'api/account/GetCustomMessage?messageType=',
        planStatus: 'api/paymentplan/getEditPaymentPlanStatus',
        getClientSettings: 'api/account/GetClientSettings'
    },
    dashboard: {
        dashboardData: 'api/dashboard/getdashboarddata',
        getPaymentPlanDetails: 'api/paymentplan/GetPaymentPlanDetails?scheduledPayment=',
        PlanActivityList: 'api/paymentplan/GetPaymentPlanActivityList',
        RmexPlanDetails: 'api/paymentplan/getPatientRmexPlanDetails?'
    },
    paymentPlans: {
        paymentPlanStatus: 'api/paymentplan/ScheduldePayment?',
        filterItem: 'api/paymentplan/PaymentPlanFilters'
    },
    payment: {
        getPaymentDetails: 'api/payment/MakeAPayment',
        getRmexPaymentDetails: 'api/paymentplan/getPatientRmexPlanDetails?PrimaryCaseNumber=',
        paymentMethodList: 'api/payment/getPaymentMethodListSelected',
        makePayment: 'api/payment/submitpayment',
        payInthirty: 'api/paymentplan/PayThirtyInstallments',
        PayHalf: 'api/paymentplan/PayHalfInstallments',
        ConfirmDistribution: 'api/paymentplan/ConfirmDistribution',
        GetSettings: 'api/account/GetSettings',
        otherOptions: 'api/payment/OtherOption',
        paymentInstallmentOptions: 'api/paymentplan/GenerateInstallmentList',
        editInstallment: 'api/paymentplan/EditInstallment',
        paymentMethodCount: 'api/payment/getPaymentMethodCount'
    },
    temp: {
        clear: 'api/patienttemp/ClearTempTable',
        save: 'api/patienttemp/SaveToTemp',
        get: 'api/patienttemp/GetFromTemp?tempID='
    },
    paymentMethods: {
        configurePayment: 'api/payment/getPaymentMethodList?includeInactive=true',
        updatePaymentMethod: 'api/payment/updatePaymentMethod',
        RoutingNumCheck: 'api/payment/RoutingNumCheck?',
        CheckNickNameExist: 'api/payment/CheckNickNameExist?',
        GetTermsAndConditionForPayment: 'api/payment/GetTermsAndConditionForPayment',
        getPatientProcessorType: 'api/payment/getPatientProcessorType',
        getProcessorTypeByTokenId: 'api/provider/action/getProcessorTypeByTokenId?',
        savepmtmethod: 'api/payment/savepmtmethod',
        PAYMENT_CC_URL: 'api/payment/getcciframeurl',
        applePaySubmit: 'api/payment/submitpayment',
        savePaymentMethod: 'api/paymentplan/UpdatePaymentPlanWithPaymentMethod'
    },
    lpg: {
        token: 'api/LPG/getLPGToken'
    },
    paymentHistroy: {
        BasicPaymentHistory: 'api/payment/BasicPaymentHistory',
        ShowReceipt: 'api/payment/ShowReceipt?',
        sendMail: 'api/payment/MailReceipt'
    },
    cc: {
        createNickName: 'api/payment/CreateNickName_CC',
        updatePaymentMethod: 'api/payment/updatePaymentMethod',
        savepmtmethod: 'api/payment/savepmtmethod'
    },
    onlineStatements: {
        getFilterData: "api/statement/getStatementFilters",
        PatientStatement: 'api/statement/getPatientStatement'
    },
    sso: {
        getFacilityGUID: 'api/account/getFacilityGUID',
        mhoAuth: 'api/account/MobilemhoAuth',
        GUIDValid: 'api/account/isGUIDValidate'

    }
}

export const tokenIgnoreList = [
    'api/account/ActivationLinkResend',
    'api/account/updateEmailToUserDetails',
    'api/account/AccountActivation',
    'api/account/ResetPassword',
    'api/account/getUsernameByEmailId'
]

export const isTokenIgnore = (url: string) => {
    const absUrl = url.split('?')[0];
    const found = tokenIgnoreList.find(relativeUrl => getApiUrl(relativeUrl) == absUrl);
    return found ? false : true;
}

export const getApiUrl = (relativeUrl: string): string => {
    return `${environment.apiDomain}/${relativeUrl}`;
}

export const loginApiUrl = (relativeUrl: string): string => {
    return `${environment.loginDomain}/${relativeUrl}`;
}