import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GtmService {

  constructor() { }
  public gtmPush = (data: any) => {
    try {
      (window as any).dataLayer.push(data);
      let analytics_event = document.createEvent("CustomEvent");
      analytics_event.initCustomEvent('analyticsEvent', false, false, data.detail);
      document.body.dispatchEvent(analytics_event);
    } catch (e) { }
  };
}
