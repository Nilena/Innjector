import { TestBed } from '@angular/core/testing';

import { CommonChannelService } from './common-channel.service';

describe('CommonChannelService', () => {
  let service: CommonChannelService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CommonChannelService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
