import { HttpErrorResponse, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject, throwError } from 'rxjs';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { GtmService } from './gtm.service';
import { apiList, getApiUrl } from '../../core/constants/api-list';
import { alertInfoTrigger, AlertInfo, Toast } from 'src/app/core/models/utility';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UtilityService {

  /** @hidden */
  public alertTrigger$: Subject<alertInfoTrigger> = new Subject();
  public surveyTrigger$: Subject<any> = new Subject();
  public toastTrigger$: Subject<Toast> = new Subject();
  public clearAllToastTrigger$: Subject<boolean> = new Subject();
  public hideChatIcon$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(true);
  public loader$: Subject<boolean> = new Subject();
  private tempData: any = {};
  public headerText$: Subject<string> = new Subject();
  public toolTipBuffer$: Subject<any> = new Subject();
  public loaderCount: number = 0;
  public paymentLoaderCount: number = 0;
  public ssoLoaderCount: number = 0;
  public loader: Subject<boolean> = new Subject<boolean>();
  public paymentLoader: Subject<boolean> = new Subject<boolean>();
  public ssoLoader: Subject<boolean> = new Subject<boolean>();
  public resetLoader: Subject<boolean> = new Subject<boolean>();
  public showMakePaymentOptions$: Subject<boolean> = new Subject<boolean>();
  public phoneNumber$: BehaviorSubject<string> = new BehaviorSubject<string>('');
  public hasRmexPlans: boolean = false;
  public ifFirstTimeHasRmexPlans: boolean = true;

  constructor(
    private gtm: GtmService,
    private http: HttpClient,
    private router: Router
  ) { }

  public alert = {
    confirm: (config: AlertInfo): Promise<boolean> => {
      return new Promise((resolve, reject) => {
        let payload: alertInfoTrigger = { ...config, resolve };
        this.alertTrigger$.next(payload);
      })
    },
    toast: (toast: Toast): void => {
      this.toastTrigger$.next(toast);
    },
    clearAllToast: (): void => {
      this.clearAllToastTrigger$.next(true);
    }
  }

  public handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong.
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // Return an observable with a user-facing error message.
    return throwError(
      'Something bad happened; please try again later.');
  }

  public parseJSON(value: any) {
    try {
      return JSON.parse(value);
    } catch (err) {
      return null;
    }
  }

  public deepCopy(value: any) {
    try {
      return JSON.parse(JSON.stringify(value));
    } catch (err) {
      return null;
    }
  }

  /*
  author : Arun
  */
  public setTempData(key: string, value: any) {
    try {
      if (!this.tempData || !Object.keys(this.tempData).length) {
        this.tempData = JSON.parse(localStorage.getItem('tempData') || '{}');
      }
      this.tempData[key] = value;
      localStorage.setItem('tempData', JSON.stringify(this.tempData));
    } catch (err) {
      console.error('Something went wrong with storage!');
    }
  }
  public saveToLocalStorage(key: string, value: any) {
    try {
      localStorage.setItem(key, value);
    } catch (err) {
      console.error('Something went wrong with storage!');
      this.checkCookieEnabled();
    }
  }
  public getFromLocalStorage(key: string) {
    try {
      return localStorage.getItem(key);
    } catch (err) {
      console.error('Something went wrong with storage!');
      this.checkCookieEnabled();
    }
    return null;
  }
  /*
  author : Arun
*/
  public getTempData(key: string): any | null {
    try {
      if (!this.tempData || !this.tempData[key]) {
        let tempData = localStorage.getItem('tempData');
        this.tempData = tempData ? JSON.parse(tempData) : null;
      }
      return this.deepCopy(!this.tempData ? null : this.tempData[key]);
    } catch (err) {
      console.error('Something went wrong with storage!');
      return {};
    }
  }
  public clearTemp() {
    try {
      this.tempData = {};
      localStorage.setItem('tempData', "{}");
    } catch (err) {
      console.error('Something went wrong with storage!');
    }
  }
  public googleTrack(data: any) {
    let context_object = {
      logged_in: data.event_logged_in,
      registration_type: data.event_registration_type ? data.event_registration_type : 'na',
      facility: data.event_facility ? data.event_facility : 'na',
      user_id: data.event_user_id,
      user_type: data.event_user_type ? data.event_user_type : 'na'
    };
    let analytics_event_details = {
      success: data.event_success,
      owner: "ePay",
      category: data.event_category,
      title: data.event_title,
      interactive: data.event_interactive,
      session_id: data.event_session_id ? data.event_session_id : -1,
      context: context_object,
      data: data.data_object
    };
    this.gtm.gtmPush({ detail: analytics_event_details });
  }

  getSettingsData() {
    this.loader.next(true);
    let payload = { "SettingsKey": "IsWebChatEnabled,IsSurveyEnabled" };
    let endpoint = getApiUrl(apiList.payment.GetSettings);
    this.http.post<any>(endpoint, payload).subscribe((response) => {
      if (response.Data) {
        if (response.Data[0].Key == 'IsWebChatEnabled' && response.Data[0].Value == "1")
          this.hideChatIcon$.next(false);
        else
          this.hideChatIcon$.next(true);
        if (response.Data[1].Key == 'IsSurveyEnabled' && response.Data[1].Value == "1")
          this.saveToLocalStorage('IsSurveyEnabled', JSON.stringify(true));
        else
          localStorage.removeItem('IsSurveyEnabled');
        // this.hideChatIcon$.next(true);
        this.loader.next(false);
      } else {
        this.alert.toast({ title: response.Message, type: 'error' });
        this.loader.next(false);
      }
    }, (err: HttpErrorResponse) => {
      this.alert.toast({ title: err?.error?.message, type: 'error' });
      this.loader.next(false);
    })
  }

  public checkCookieEnabled() {
    if(this.hasBlockerIssue()) {
      this.router.navigate(['/error']);
    }
    // if (!navigator.cookieEnabled) {
    //   this.alert.toast({
    //     title: 'Please enable Cookies. Features on this site may break if we disable cookies.',
    //     type: 'error',
    //     __disableAutoClose: true,
    //   })
    // }
  }

  public hasBlockerIssue() {
    return (
      !navigator.cookieEnabled
    )
  }

  public isFirstTimeLoading(): boolean {
    try {
      let isFirstTimeLoading = !localStorage.getItem(CONSTANTS.APP_CONFIG.FIRST_TIME_LOADING);
      return isFirstTimeLoading ? true : false;
    } catch (err) {
      console.error('Something went wrong with storage!');
      return false;
    }
  }
  public isMobile(){
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  }
}

