import { TestBed } from '@angular/core/testing';

import { IgxMaskParsingService } from './igx-mask-parsing.service';

describe('IgxMaskParsingService', () => {
  let service: IgxMaskParsingService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(IgxMaskParsingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
