import { Injectable } from '@angular/core';
import {  UtilityService } from './utility.service';
import { Toast } from 'src/app/core/models/utility';

@Injectable({
  providedIn: 'root'
})
export class ToasterService {
  public messageGroup: Toast[] = [];
  public AGE: number = 5000;
  constructor(
    public utilityService:UtilityService
  ) {  }

  checkRepeatedToasters(title:string){
   return this.messageGroup.find(t =>(t.title)?.toLocaleLowerCase()==title?.toLocaleLowerCase() )
  }
   listenToaster(){
    this.utilityService.toastTrigger$.subscribe((toast: Toast) => {
      // toast.__clearAll = true;
      if(!toast.title) return;
      if(this.checkRepeatedToasters(toast.title)){
        return;
      }
      if (toast.__clearAll) {
        this.messageGroup.forEach(t => {
          this.removeToast(t);
        })
      }
      toast.__id = new Date().getTime();
      if (!toast.__disableAutoClose) {
        toast.__lifeSpan = setTimeout(() => {
          this.removeToast(toast);
        }, this.AGE
      )
      }
      this.messageGroup.unshift(toast);
    })
    this.utilityService.clearAllToastTrigger$.subscribe((status) => {
      this.clearAllToast();
    })



  }

  public removeToast(toast: Toast) {
    if (toast.__lifeSpan) {
      clearTimeout(toast.__lifeSpan);
    }
    let index = this.messageGroup.findIndex(el => el.__id === toast.__id);
    if (index != -1) {
      this.messageGroup.splice(index, 1);
    }
  }

  public clearAllToast() {
    this.messageGroup.forEach(toast => {
      this.removeToast(toast);
    })
  }
}


