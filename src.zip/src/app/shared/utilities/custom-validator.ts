import { AbstractControl, ValidationErrors } from "@angular/forms";
import * as moment from 'moment';


export class CustomValidation {
    /*
    author : Arun Lalithabaran
    desc   : for Email Validation
    */
    public static email(control: AbstractControl) {
        const email = control.value; // to get value in input tag
        const pattern = new RegExp(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,3}))$/);
        if (email && !pattern.test(email)) {
            return { invalidEmail: true };
        }
        return null;
    }
    /*
        author : Arun Lalithabaran
        desc   :for alpha checking only
      */
    public static alphabets(control: AbstractControl) {
        const text = control.value; // to get value in input tag
        const pattern = new RegExp(/^[a-zA-Z ]+$/);
        if (!pattern.test(text)) {
            return { alphabetsOnly: true };
        } else {
            return null;
        }
    }
     /*
    author : Arun Lalithabaran
    desc   : for mobile Validation
    */
    public static mobileNum(control: AbstractControl) {
        const text = control.value; // to get value in input tag
        const pattern = new RegExp(/^(\+\d{1,3}[- ]?)?\d{10,12}$/);
        if (!pattern.test(text)) {
            return { invalidMobile: true };
        } else {
            return null;
        }
    }
    /*
        author : Arun Lalithabaran
        desc   :for checking description only
      */
    public static discriptionText(control: AbstractControl) {
        const text = control.value; // to get value in input tag
        const pattern = new RegExp(/^[a-zA-Z\.&\s]+$/);
        if (!pattern.test(text)) {
            return { discriptionText: true };
        } else {
            return null;
        }
    }
    /*
        author : Arun Lalithabaran
        desc   :for checking decimal number only
      */
     
        public static floatingNumber(control: AbstractControl) {
        const floatingNumber = control.value; // to get value in input tag
        const pattern = new RegExp(/^[+-]?([0-9]*[.])?[0-9]+$/);
        if (!pattern.test(floatingNumber) && (control.value != '' || control.value != null)) {
            return { floatingNumber: true };
        } else {
            return null;
        }
    }
    /*
        author : Arun Lalithabaran
        desc   :for checking number only
      */
    public static onlyNumber(control: AbstractControl) {
        const onlyNumber = control.value; // to get value in input tag
        const pattern = new RegExp(/^[0-9]*$/);
        if (!pattern.test(onlyNumber)) {
            return { onlyNumber: true };
        } else {
            return null;
        }
    }
     /*
        author : Arun Lalithabaran
        desc   :for checking number amd decimal only
      */
    public static numberWithDecimal(control: AbstractControl) {
        const onlyNumber = control.value; // to get value in input tag
        const pattern = new RegExp(/^[0-9]*(\.[0-9]{0,2})?$/);
        if (!pattern.test(onlyNumber)) {
            return { onlyNumber: true };
        } else {
            return null;
        }
    }
    // ^\d+\.\d{0,2}$
    /*
        author : Arun Lalithabaran
        desc   :for checking input contain password
      */
    public static PasswordRule(control: AbstractControl) {
        const password = control.value; // to get value in input tag
        const pattern = new RegExp('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,64}');
        if (password && !pattern.test(password)) {
            return { passwordRule: true };
        }
        return null;
    }
    /*
        author : Arun Lalithabaran
        desc   :for checking input contain space
      */

    public static cannotContainSpace(control: AbstractControl): ValidationErrors | null {
        // set error on matchingControl if validation fails
        if (control.value && control.value.indexOf(' ') > -1) {
            return { cannotContainSpace: true };
        } else {
            return null;
        }
    }
    /*
        author : Arun Lalithabaran
        desc   :for checking input has no space
      */
    public static noSpaceOnly(control: AbstractControl): ValidationErrors | null {
        if (control.value && control.value.trim() == '') {
            return { required: true };
        } else {
            return null;
        }
    }
    /*
        author : Nilena Alexander
        desc   :for checking input has future dates
      */
    public static futureDate(control: AbstractControl): ValidationErrors | null {
        try {
            let today = new Date().getTime();
            let date = control.value ? new Date(control.value).getTime() : null;
            if (date && date > today) {
                return { futureDate: true }
            }
        } catch (err) {
            return null;
        }
        return null;
    }
/*
        author :Nilena Alexander
        desc   :for checking input has valid dates
      */
    public static validDate(control: AbstractControl): ValidationErrors | null {
        try {
            let date = control.value ? new Date(control.value).getTime() : null;
            if (!date) {
                return { inValid: true }
            }
            if (date) {
                if(!(moment(control.value, "MM/DD/YYYY").isValid())){
                    return { inValid: true }
                }
            }
        } catch (err) {
            return null;
        }
        return null;
    }

    /*
        author :Arjun
        desc   :for checking min date is 1899
      */

     public static OldDate(control: AbstractControl): ValidationErrors | null {
        try {
            let date = control.value ? new Date(control.value).getTime() : null;
            if (date) {
                let timestamp  = Date.parse(control.value);
                let dateObject = new Date(timestamp);
                let dateYear = dateObject.getFullYear();
                if(dateYear<1900){
                    return { inValidrange: true }
                }
            }
        } catch (err) {
            return null;
        }
        return null;
    }







    // public static validDate(control: AbstractControl): ValidationErrors {

    //     // set error on matchingControl if validation fails
    //     if (!control.value) {
    //         return null;
    //     }


    //     const date = moment(control.value);
    //     const isoDatetime = DateTime.fromISO(date.toISOString());
    //     if (!date.isValid()) {
    //         return { validDate: true };
    //     } else {
    //         return null;
    //     }

    // }

    // public static todayAndPast(control: AbstractControl): ValidationErrors {
    //     // set error on matchingControl if validation fails
    //     if (!control.value) {
    //         return null;
    //     }


    //     const date = moment(control.value);

    //     if (date.isValid()) {
    //         const now = moment(new Date());
    //         const duration = moment.duration(date.diff(now));
    //         if (duration.asSeconds() > 0) {
    //             // Oops...In the future
    //             return { todayAndPast: true };
    //         } else {
    //             return null;
    //         }
    //     }
    //     return null;
    // }



    // public static underAge(control: AbstractControl): ValidationErrors {
    //     // set error on matchingControl if validation fails
    //     if (!control.value) {
    //         return null;
    //     }


    //     const date = moment(control.value);

    //     if (date.isValid()) {
    //         const now = moment(new Date());
    //         const duration = moment.duration(now.diff(date));
    //         if (duration.asYears() > 12) {
    //             // Oops...In the past
    //             return { underAge: true };
    //         } else {
    //             return null;
    //         }
    //     }
    //     return null;
    // }
}