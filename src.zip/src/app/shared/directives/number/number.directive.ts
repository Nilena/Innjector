import { Directive, ElementRef, HostListener, Input } from '@angular/core';
import { REGCONSTANTS } from 'src/app/core/constants/regex-constants';

@Directive({
  selector: '[appNumber]'
})
export class NumberDirective {

  @Input('appOnlyNumber') decimalCheck: boolean = false;

  private regXwithDecimal = REGCONSTANTS.regXwithDecimal;
  private regX = REGCONSTANTS.regXwithDecimal;
  constructor(private _el: ElementRef) {
  }
  @HostListener('input', ['$event'])
  onInputChange(event: KeyboardEvent) {
    const initalValue = this._el.nativeElement.value;
    this._el.nativeElement.value = initalValue.replace(this.decimalCheck ? this.regXwithDecimal : this.regX, '');
    if (initalValue !== this._el.nativeElement.value) {
      event.stopPropagation();
    }
  }
}
