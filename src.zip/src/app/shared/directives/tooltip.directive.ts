import { AfterViewInit, Directive, ElementRef, HostListener, Input, OnDestroy } from '@angular/core';
import { ToolTipPosition } from 'src/app/core/models/utility';
import { UtilityService } from 'src/app/shared/services/utility.service';

@Directive({
  selector: '[fsTooltip]'
})
export class TooltipDirective implements AfterViewInit, OnDestroy {

  @Input() tooltipText: string = '';
  @Input() position: ToolTipPosition = 'top';

  private tooltip: TooltipMeta | null = null;

  constructor(
    private utility: UtilityService,
    private element: ElementRef
  ) { }

  ngAfterViewInit(): void {

  }

  @HostListener('window:scroll')
  onScroll(): void {
    if (this.tooltip) {
      this.triggerTooltip();
    }
  }

  @HostListener('mouseover')
  onMouseEnter(): void {
    this.triggerTooltip();
  }

  @HostListener('mouseleave')
  onMouseLeave(): void {
    this.tooltip = null;
    this.utility.toolTipBuffer$.next(null);
  }

  @HostListener('window:hashchange')
  windowBack(): void {
    this.tooltip = null;
    this.utility.toolTipBuffer$.next(null);
  }
  private triggerTooltip() {
    let position = (this.element.nativeElement as HTMLElement).getBoundingClientRect();
    let parentPosition = {};
    if (this.position == 'top') {
      parentPosition = {
        left: Math.abs(position.left + (position.width / 2)),
        top: position.top
      }
    } else if (this.position == 'right') {
      parentPosition = {
        left: position.left + position.width,
        top: position.top
      }
    } else if (this.position == 'left') {
      parentPosition = {
        left: position.left,
        top: position.top
      }
    } else if (this.position == 'bottom') {
      parentPosition = {
        left: Math.abs(position.left + (position.width / 2)),
        top: position.top + position.height
      }
    }
    this.tooltip = {
      text: this.tooltipText,
      position: this.position,
      parentPosition: parentPosition
    }
    this.utility.toolTipBuffer$.next(this.tooltip);
  }

  ngOnDestroy(): void {
    // throw new Error('Method not implemented.');
    this.tooltip = null;
    this.utility.toolTipBuffer$.next(null);
  }

}


export type TooltipMeta = {
  text: string;
  position: any;
  parentPosition: any;
}
