import { IgxMaskDirective } from './igx-mask.directive';

describe('IgxMaskDirective', () => {
  it('should create an instance', () => {
    const directive = new IgxMaskDirective();
    expect(directive).toBeTruthy();
  });
});
