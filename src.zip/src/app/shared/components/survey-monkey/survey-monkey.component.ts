import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, Renderer2 } from '@angular/core';
import { UserService } from 'src/app/auth/services/user.service';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { ApiResponse, Profile } from 'src/app/core/models/auth';
import { SurveyConfig } from 'src/app/core/models/utility';
import { UtilityService } from '../../services/utility.service';

@Component({
  selector: 'app-survey-monkey',
  templateUrl: './survey-monkey.component.html',
  styleUrls: ['./survey-monkey.component.css']
})
export class SurveyMonkeyComponent implements OnInit {


  public showSurvey: boolean = false;
  public starRating: number = 5;
  public comment: string = '';
  public surveyConfig: SurveyConfig | null = null;
  public surveyMessage: string = '';
  private profile: Profile | null = null;
  public paymentData: any = null;
  public surveyRatingQuestion: any = {};
  public surveyQuestions: any[] = [];
  public surveyTimeout: any;

  constructor(
    private utility: UtilityService,
    private renderer: Renderer2,
    private http: HttpClient,
    private userService: UserService
  ) { }

  ngOnInit(): void {
    this.utility.surveyTrigger$.subscribe((paymentData: any) => {
      this.surveyConfig = this.utility.getTempData(CONSTANTS.SESSION.SURVEY_DATA);
      let surveyStatus = localStorage.getItem('IsSurveyEnabled');
      this.profile = this.userService.getUserInfo();
      if (this.surveyConfig) {
        this.paymentData = paymentData;
        if (surveyStatus && this.surveyConfig.surveyCount > 0 && this.surveyConfig.surveyCountSession > 0) {
          this.comment = '';
          this.starRating = 5;
          this.getSurveyMessages();
          this.getSurveyQuestion();
        }
      }
    })
  }

  public surveyAutoClose() {
    this.surveyTimeout = setTimeout(() => {
      this.openSurveyPopup(false);
    }, (this.surveyConfig?.responseTime || 1) * 1000)
  }

  clearAutoClose() {
    if (this.surveyTimeout) clearTimeout(this.surveyTimeout);
  }

  public openSurveyPopup(status: boolean = true) {
    this.clearAutoClose();
    if (status) {
      setTimeout(() => {
        this.showSurvey = true;
        this.renderer.addClass(document.body, 'modal--open');
        this.surveyAutoClose();
      }, (this.surveyConfig?.popupDelay || 1) * 1000)
    } else {
      this.showSurvey = false;
      this.renderer.removeClass(document.body, 'modal--open');
    }
  }

  private getSurveyQuestion() {
    this.surveyQuestions = [];
    let endpoint = getApiUrl(apiList.common.getSurveyQuestion);
    let payload = {
      event_id: this.paymentData,
      client_group_code: this.profile?.ClientCode
    }
    this.http.post<ApiResponse>(endpoint, payload).subscribe((response) => {
      if (response.Data && response.Data.length) {
        response.Data.forEach((item: any) => {
          if (item.question_type_id == "1") {
            this.surveyRatingQuestion = item;
          } else {
            this.surveyQuestions.push(item);
          }
        })
        if (response.Data.length) this.openSurveyPopup(true);
      } else {
        // this.utility.alert.toast({ title: loginResponse.Message, type: 'error' });
      }
      // this.loginInProgress = false;
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      // this.loginInProgress = false;
    })
  }

  private getSurveyMessages() {
    let endpoint = getApiUrl(apiList.common.getSurveyMessage + '?messageKey=msg_After_Survey');
    this.http.get<ApiResponse>(endpoint).subscribe((response) => {
      if (response.Status == true) {
        this.surveyMessage = response.Data;
      } else {
        // this.utility.alert.toast({ title: loginResponse.Message, type: 'error' });
      }
      // this.loginInProgress = false;
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      // this.loginInProgress = false;
    })
  }

  updateStarRating(rating: number) {
    this.starRating = rating;
    this.clearAutoClose();
  }

  public preparePayload() {
    let finalObject = {
      SurveyHeaderData: {
        people_id: this.profile?.PeopleID,
        logged_user_id: this.profile?.LogId,
        client_group_code: this.profile?.UserHeader.MasterClientCode,//this.profile?.ClientCode,
        login_type: this.surveyConfig?.loginMode,
        is_attended: true,
        event_id: this.paymentData,
        terminated_by: this.profile?.ProfileName,
        ip_address: null,
        created_by: this.profile?.UserID
      },
      SurveyDetailsData: ([] as any[])
    }
    if (this.surveyRatingQuestion) {
      finalObject.SurveyDetailsData.push({
        question_mapping_id: this.surveyRatingQuestion.question_mapping_id,
        question_type_id: this.surveyRatingQuestion.question_type_id,
        survey_result: this.starRating,
      })
    }
    if (this.surveyRatingQuestion && this.surveyQuestions.length) {
      finalObject.SurveyDetailsData.push({
        question_mapping_id: this.surveyQuestions[0].question_mapping_id,
        question_type_id: this.surveyQuestions[0].question_type_id,
        survey_result: this.comment
      })
    }
    return finalObject;
  }

  submitSurvey() {
    this.openSurveyPopup(false);
    let payload = this.preparePayload();
    let endpoint = getApiUrl(apiList.common.saveSurvey);
    this.http.post<ApiResponse>(endpoint, payload).subscribe((response) => {
      if (response.Status) {
        this.utility.alert.toast({ title: this.surveyMessage, type: 'success' });
        if (this.surveyConfig) {
          this.surveyConfig.surveyCount -= 1;
          this.surveyConfig.surveyCountSession -= 1;
          this.utility.setTempData(CONSTANTS.SESSION.SURVEY_DATA, this.surveyConfig);
        }
      } else {
        // this.utility.alert.toast({ title: loginResponse.Message, type: 'error' });
      }
      // this.loginInProgress = false;
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      // this.loginInProgress = false;
    })
  }


}
