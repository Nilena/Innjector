import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SurveyMonkeyComponent } from './survey-monkey.component';

describe('SurveyMonkeyComponent', () => {
  let component: SurveyMonkeyComponent;
  let fixture: ComponentFixture<SurveyMonkeyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SurveyMonkeyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SurveyMonkeyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
