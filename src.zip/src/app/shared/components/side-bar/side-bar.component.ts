import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/auth/services/user.service';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { Profile } from 'src/app/core/models/auth';
import { UtilityService } from '../../services/utility.service';
import { PaymentService } from '../../../payment/services/payment.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-side-bar',
  templateUrl: './side-bar.component.html',
  styleUrls: ['./side-bar.component.css']
})
export class SideBarComponent implements OnInit {

  sideBar: boolean = true
  userInfoData: Profile | null = null;
  mhoIcon: boolean = false;

  @Output() emittedData = new EventEmitter();
  constructor(private router: Router,
    private utility: UtilityService,
    private userService: UserService,
    public paymentService: PaymentService) { }

  @Input() set showMenu(sidebar: boolean) {
    this.sideBar = sidebar
  }
  ngOnInit(): void {
    this.userInfoData = this.userService.getUserInfo();
    if (this.utility.getTempData(CONSTANTS.SESSION.COM_MHO_EMAIL))
      this.mhoIcon = true;
    else
      this.mhoIcon = false;
  }

  public gotoMakePayment() {
    if (this.utility.hasRmexPlans) {
      this.utility.showMakePaymentOptions$.next(true);
    } else {
      this.router.navigate(['/payment/pay'])
    }
  }

  /*
     author : Nilena Alexander
     desc   :for show and hide menu bar
   */
  menuOpening() {
    this.sideBar = !this.sideBar;
    this.emittedData.emit(this.sideBar);
  }

  /*
    author : Nilena Alexander
    desc   :confirmation pop for logout.
  */

  logoutPopup() {
    this.utility.alert.confirm({
      text: 'Are you sure you want to logout?',
      title: 'Confirmation',
      type: 'warning',
      okText: 'Yes',
      cancelText: 'No'
    }).then(res => {
      if (res) {
        this.logout();
      }
    })
  }

  /*
     author : Nilena Alexander
     desc   : for clear local storage
   */
  logout() {
    this.userService.logout();
  }

  //survey test
  showReview() {
    this.utility.surveyTrigger$.next({});
  }
  /*
  author : Nilena Alexander
  desc   : redirect to mho login
  */
  mhoLogin() {
    this.userService.removeSession(true);
    let url = environment.mhoDomain;
    window.location.replace(url);

  }

}
