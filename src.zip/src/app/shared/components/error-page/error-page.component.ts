import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UtilityService } from '../../services/utility.service';

@Component({
  selector: 'app-error-page',
  templateUrl: './error-page.component.html',
  styleUrls: ['./error-page.component.css']
})
export class ErrorPageComponent implements OnInit {

  constructor(
    private utility: UtilityService,
    // private router: Router
  ) { }

  ngOnInit(): void {
  }

  goBack() {
    if(this.utility.hasBlockerIssue()) {
      this.utility.alert.toast({
        type: 'error',
        title: 'Cookies are still disabled in your browser settings. Please call (844) 236-3525 for assistance.',
        __clearAll: true
      })
    } else {
      location.reload();
    }
  }

}
