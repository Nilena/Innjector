

import { Component, OnInit, Input, HostListener, ViewChildren, ViewChild, ElementRef, Output, EventEmitter, SimpleChanges, ChangeDetectorRef } from '@angular/core';
import { UtilityService } from '../../services/utility.service';

@Component({
  selector: 'app-multi-selector',
  templateUrl: './multi-selector.component.html',
  styleUrls: ['./multi-selector.component.css']
})
export class MultiSelectorComponent implements OnInit {
  @HostListener('document:click', ['$event'])
  clickout(event: any) {
    if (this.el.nativeElement.contains(event.target)) {
    } else {
      this.clickedOutside({});
    }
  }
  @Input() disabled: boolean = false;
  @Input() label: string = '';
  @Input() uId: string = '';
  @Input() icon: string = '';
  @Input() placeholder = 'Search'
  @Input() inputLoader: boolean = false;
  @Input() searchLimit: any = null;
  @Input() maxLength: any = null;
  @Input() autoComplete: boolean = false;
  @ViewChild('chosenList', { static: true }) private chosenList: ElementRef | null = null;
  @ViewChild('chosenSearch', { static: true }) private inputField: ElementRef | null = null;
  @ViewChild('select', { static: true }) private select: ElementRef | null = null;
  checkedValue: boolean = false
  public activeScrollState: any = null;
  keyEventFired = false;
  _selectedOption: any;
  _selectedOptionName: any;
  _options: any;
  filteredArr: any[] = [];
  scrollOptions = {
    axis: 'y', theme: 'minimal-dark', mouseWheel: { preventDefault: true },
    keyboard: { enable: false }, advanced: { updateOnSelectorChange: true }
  };
  duplicateData: any;
  showOptions = false;
  showAutocompleteOptions = false;
  count = 0;
  searchText: string = '';
  firstItemLabel: string = '';
  sucessBtnName: string = 'Apply';
  cancelBtnName: string = 'Cancel';
  @ViewChildren('result') filteredItems: any;
  @Output() selectedOutput = new EventEmitter();
  @Output() selectedObjects = new EventEmitter();

  @Input() set subtBtnName(value: string) {
    this.sucessBtnName = value;
  }
  @Input() set cancelBtn(value: string) {
    this.cancelBtnName = value;
  }
  @Input() set selectedInput(value: any[]) {
    this._selectedOption = value;
  }

  @Input() set options(value: any[]) {
    this.setSelectionOptnData(value)
  }

  constructor(private el: ElementRef, private cdRef: ChangeDetectorRef,
    private utility: UtilityService) { }


  ngOnChanges() {
    this.count = 0;
    // if (this._selectedOption && this._selectedOption.length) {​
    //   this._selectedOption.forEach((el: any) => {​
    //     el = el + '';
    //   }​);
    // }​ else {​
    //   this._selectedOption = [];
    // }​
    if (this._options && this._options.length) {
      let tempArray: any = [];
      tempArray = this._options.filter((el: any) => el[this.label] && el[this.label].toString().trim() !== '');
      this._options = tempArray;
      this._options.forEach((element: any) => {
        if (this._selectedOption.indexOf(element[this.uId]) > -1) {
          element['status'] = true;
          this.count++;
        } else {
          element['status'] = false;
        }
      });

    }
  }


  ngOnInit() {
    this.updateScrollView();
    this.searchLimit = this.searchLimit ? this.searchLimit : null;
    this.initChosen();
    // if (this.select)
    //   this.select.nativeElement.addEventListener('keydown', this.dropdown);
  }

  ngAfterViewChecked() {
    this.cdRef.detectChanges();
  }

  initChosen() {
    if (this._options && this._options.length) {
      if (this.isObject() && this.uId) {
        this.addStatusLabel();
      } else if (!this.isObject()) {
        this.processArray();
      }
    }
  }

  isObject() {
    return (typeof this._options[0] == 'object') ? true : false;
  }

  seTCount() {
    this.count = 0;
    this._options.forEach((option: any) => {
      if (option.status === true) {
        this.count++;
      }
    })
    if (this.count == 0)
      this.firstItemLabel = '';
  }
  openDropDown() {
    this.showOptions = !this.showOptions;
    if (this.showOptions) {
      this.duplicateData = null;
      this.duplicateData = this.utility.deepCopy(this._selectedOption);
    }

    if (!this.showOptions)
      this.cancel()
  }
  addStatusLabel() {
    this._options.forEach((option: any) => {
      if (this._selectedOption && this._selectedOption.length) {
        if (this._selectedOption.indexOf(option[this.uId]) !== -1) {
          option.status = true;
        } else {
          option.status = false;
        }
      } else {
        option.status = false;
      }
    });
    this.seTCount();
  }

  processArray() {
    const temp = this._options;
    this._options = temp.map((item: any, index: number) => {
      return {
        id: index,
        value: item,
        status: (this._selectedOption
          && this._selectedOption.length
          && this._selectedOption.indexOf(item) != -1) ? true : false
      }
    });
    this.label = 'value';
    this.uId = 'value';
    this.seTCount();
  }

  changeOption(event: any, option: any) {
    option.status = !option.status;
    this.cdRef.detectChanges();
    this.filteredArr.forEach((x: any) => {
      if (option[this.uId] == x[this.uId]) {
        x.status = option.status;
      }
    });
    option.status ? this.count++ : this.count--;
    if (this.count == 0)
      this.firstItemLabel = '';
    if (this._selectedOption.indexOf(option[this.uId]) != -1) {
      this._selectedOption.splice(this._selectedOption.indexOf(option[this.uId]), 1);
    } else {
      this._selectedOption.push(option[this.uId]);
    }
    if (event.target.attributes.autoCompleteState && event.target.attributes.autoCompleteState.value == 'true') {
      event.stopPropagation();
    }
    for (let i = 0; i < this.filteredArr.length; i++) {
      if (!this.filteredArr[i].status) {
        this.checkedValue = false;
        break
      } else
        this.checkedValue = true;
    }
    this.setLabel()
  }
  setLabel() {
    if (this._selectedOption.length > 0) {
      let item = this.filteredArr.find((el: any) => {
        return el[this.uId] == this._selectedOption[0]
      })
      if (item) {
        this.firstItemLabel = item[this.label];
      }
    }
  }

  checkedBox(value: boolean) {
    this.count = 0;
    this._selectedOption = [];
    if (!this.checkedValue) {
      this.filteredArr.forEach((element) => {
        element.status = false
      });
      this.seTCount()
      // this.selectedOutput.emit(null);
    } else {
      this.filteredArr.forEach((element) => {
        element.status = true
        this._selectedOption.push(element[this.uId])
      });
      this.setLabel();
      this.seTCount();
      //this.selectedOutput.emit(this._selectedOption);
    }
  }
  submitSelectedValues() {
    if (!this._selectedOption.length)
      this.selectedOutput.emit(null);
    else
      this.selectedOutput.emit(this._selectedOption);
    this.showOptions = false;
  }
  cancel() {
    this._selectedOption = this.duplicateData;
    this.showOptions = false;
    this._options.forEach((element: any) => {
      for (let a = 0; a < this._selectedOption.length; a++) {
        if (element[this.uId] !== this._selectedOption[a]) {
          element['status'] = false;
        }
      }
    });
    if (this._selectedOption.length == 0) {
      this.count = 0;
      this._selectedOption = [];
      this.filteredArr.forEach((element) => {
        element.status = false
      });
      this.checkedValue = false;
    }
    else {
      this.setSelectionOptnData(this._options)
    }
  }
  setSelectionOptnData(value: any) {
    this._options = value;
    this.count = 0;
    if (this._options && this._options.length) {
      let tempArray: any = [];
      tempArray = this._options.filter((el: any) => el[this.label] && el[this.label].toString().trim() !== '');
      this._options = tempArray;
    }
    if (this._selectedOption && this._selectedOption.length) {
      let removeList = [];
      for (let j = 0; j < this._selectedOption.length; j++) {
        let found = false;
        for (let i = 0; i < this._options.length; i++) {
          if (this._options[i][this.uId] == this._selectedOption[j]) {
            found = true;
            break;
          }
        }
        if (!found) {
          removeList.push(this._selectedOption[j]);
          found = false;
        }
      };
      removeList.forEach(item => {
        let index = this._selectedOption.findIndex((el: any) => el == item);
        if (index !== -1) {
          this._selectedOption.splice(index, 1);
        }

      })

      this._options.forEach((element: any) => {
        for (let a = 0; a < this._selectedOption.length; a++) {
          if (element[this.uId] === this._selectedOption[a]) {
            element['status'] = true;
            this.count++;
          }
        }
      });
    }
    if (!this.autoComplete) {
      this.filteredArr = this._options;
    }
    if (this._selectedOption.length == this.filteredArr.length) {
      this.checkedValue = true;
    }

    this.setLabel();
  }
  closeOnTab(e: any) {
    if (e.which === 9) {
      let el = this.el.nativeElement.querySelector('#choosen-head');
      this.showOptions = false;
      this.showAutocompleteOptions = false;
      this.updateScrollView();
      this.searchText = '';
    }
  }
  onSearch() {
    if (!this.autoComplete) {
      this.showOptions = true;
      this.filteredArr = this._options;
    } else {
      this.showAutocompleteOptions = true;
    }
    this.updateScrollView();
    let el = this.el.nativeElement.querySelector('#choosen-head');
  }

  public onBlur() {
    let el = this.el.nativeElement.querySelector('#chosenSearch');
    let elm = this.el.nativeElement.querySelector('#tag-list-ul').children;
  }

  tabKeyPress(event: any) {
    if (event && event.keyCode === 9) {
      if (event.target.attributes.autoCompleteState && event.target.attributes.autoCompleteState.value == 'true') {
        let el = this.el.nativeElement.querySelector('#choosen-head');
      }
    }
  }

  clickedOutside(event: any) {
    let el = this.el.nativeElement.querySelector('#choosen-head');
    if (!this.keyEventFired) {
      this.keyEventFired = true;
      this.showOptions = false;
      this.showAutocompleteOptions = false;
      this.updateScrollView();
      this.searchText = '';
      if (this.autoComplete) {
        this.filteredArr = [];
      }
    }
    this.keyEventFired = false;
  }

  filter() {
    if (this.inputField)
      this.inputField.nativeElement.focus();
    if (this._options && this._options.length) {
      this.filteredArr = this._options.filter((item: any) => {
        const searchValue = this.searchText.toLowerCase();
        if (searchValue.trim() !== '' || !this.autoComplete) {
          return JSON.stringify(item[this.label]).toLowerCase().includes(searchValue.trim());
        }
        return false
      });
    } else {
      this.filteredArr = [];
    }
    this.showOptions = true;
  }

  dropdown = (e: any) => {
    if ((this.showOptions || (this.searchText !== '' &&
      this.searchText !== null && this.searchText.length && this.autoComplete)) && this.chosenList) {
      const list = this.chosenList.nativeElement;
      const first = list.firstElementChild.firstChild.children[0].children[0];
      const maininput = this.inputField?.nativeElement;
      switch (e.key) {
        case 'ArrowUp':
          if (document.activeElement === first) {
            this.inputField?.nativeElement.focus();
            e.preventDefault();
            break;
          } else {
            // if (document.activeElement.previousSibling && document.activeElement.previousSibling.firstChild) {​
            //   const element = document.activeElement.firstChild.parentElement.previousSibling as HTMLElement;
            //   element.focus();
            // }​
            e.preventDefault();
          }
          break;
        case 'ArrowDown':
          if (document.activeElement === maininput) {

            first.focus();

            e.preventDefault();
          } else {
            // if (document.activeElement.nextSibling && document.activeElement.nextSibling.firstChild) {​
            //   const element = document.activeElement.firstChild.parentElement.nextSibling as HTMLElement;
            //   element.focus();
            // }​
            e.preventDefault();
          }
          break;
        case 'Enter':
          if (!this.inputLoader && document.activeElement !== maininput) {
            if (document.activeElement) {
              const el = document.getElementById('check-' + document.activeElement.id) as HTMLInputElement;
              el.click();
            }

            let element = this.el.nativeElement.querySelector('#choosen-head');
            // setTimeout(() => {​
            //   $(element).mCustomScrollbar('scrollTo', 'bottom', {​
            //     scrollInertia: 200,
            //   }​)
            // }​, 250)
          }
          break;
        case 'Tab':
          this.showOptions = false;
          this.showAutocompleteOptions = false;
          this.updateScrollView();
          // let el = this.el.nativeElement.querySelector('#choosen-head');
          // setTimeout(() => {​
          //     $(el).mCustomScrollbar('scrollTo', 'top', {​
          //         scrollInertia: 200,
          //     }​)
          // }​, 250)
          if (this.select)
            this.select.nativeElement.removeEventListener('keydown', this.dropdown);
      }
    }
  }

  clear() {
    this._selectedOption = [];
    this.count = 0;
    this.initChosen();
  }

  trackByFn(index: number, item: any) {
    if (!item) {
      return null;
    } else {
      return item[this.uId];
    }
  }

  updateScrollView() {
    const state = (this.showOptions || this.showAutocompleteOptions || document.activeElement === this.inputField?.nativeElement);
    if (this.activeScrollState !== state) {
      this.activeScrollState = state;
      setTimeout(() => {
        const scrollEl: any = this.el.nativeElement.querySelector('[data-element="choosen-mscrollbar"]');
        if (scrollEl) {
          if (this.activeScrollState) {

            // ($(scrollEl).mCustomScrollbar as any)(this.scrollOptions);
            // $(scrollEl).mCustomScrollbar('scrollTo', 'bottom');
            if (this.inputField)
              this.inputField.nativeElement.focus();
          } else {

            // $(scrollEl).mCustomScrollbar('scrollTo', 'top');
            // $(scrollEl).mCustomScrollbar('scrollTo', 'top');
            //$(scrollEl).mCustomScrollbar('destroy');
          }
        }
      }, 100)
    }


  }

  ngOnDestroy() {
    // if (this.select)
    //   this.select.nativeElement.removeEventListener('keydown', this.dropdown);
  }

}













