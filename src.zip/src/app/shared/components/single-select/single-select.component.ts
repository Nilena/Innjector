import { Component, OnInit, Input, HostListener, ViewChild, ElementRef, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-single-select',
  templateUrl: './single-select.component.html',
  styleUrls: ['./single-select.component.css']
})
export class SingleSelectComponent implements OnInit {

  SearchItem: string = '';
  searchD: string = '';
  filteredArr: any = [];
  selectedItemName: string = 'Select';
  displayList: boolean = false;
  selectedOption: any = null
  selectedItemId: string = ''
  _dataArr: any = [];
  @Input() uid: string = '';
  @Input() label: string = '';
  @Input() isDisabled: boolean = false;
  @Input() loader: boolean = false;
  @Input() SearchItem2: string = '';
  @Input() SearchItem1: string = '';
  public objectX:any;
  @Output() selectedEvent = new EventEmitter<string>();

  @ViewChild('search') search! : ElementRef; 
  @ViewChild('listitem') listitem! : ElementRef;
  @Output() selectedDisplayValue = new EventEmitter<string>();

  public paymentLoader: Subject<boolean> = new Subject<boolean>();

  @HostListener('document:click', ['$event'])
  clickout(event: any) {
    if (this._elementRef.nativeElement.contains(event.target)) {
    } else {
      this.clickedOutside({});
    }
  }


  @HostListener('keydown', ['$event'])
  clickarrowx(event: any) {

    if(event.code == 'Escape' || event.key == 'Escape'){
      this.clickedOutside({});
    }

    if(event.code == 'Space' || event.key == 'Space'){
      debugger;
      this.objectX = (this._dataArr.find((el: any) => el[`${this.label}`]  == event.target.innerText));
      this.selectItem(this.objectX);
    }
  }


    




  @Input() set dataArr(value: any[]) {
    this._dataArr = value;
    if (this._dataArr && this._dataArr.length) {
      this.filteredArr = [];
      this._dataArr.forEach((item: any) => {
        if (Number.isInteger(item) || item.length) {
          const obj: any = {};
          obj[this.uid] = item;
          obj[this.label] = item;
          this.filteredArr.push(obj);
        }
        else {
          this.filteredArr = this._dataArr;
        }
      });
    }
  }


  @Input() set selectedData(value: any) {
    if (value || (value == 0 && value != '')) {
      this.selectedOption = value;
      this.setSelectedItem();
    } else {
      this.selectedItemId = '';
      this.selectedItemName = '';
      this.selectedOption = null;
    }
  }

  constructor(public _elementRef: ElementRef) { }

  

  ngOnChanges(changes: SimpleChanges) {
    // this.isDisabled = this.isDisabled;
    if (this._dataArr && this._dataArr.length) {
      if (this.selectedOption) {
        this.setSelectedItem();
      } else {
        this.selectedItemId = '';
        this.selectedItemName = '';
      }

      let tempArray: any = [];
      tempArray = this.filteredArr.filter((el: any) => el[this.label] && el[this.label].toString().trim() !== '');
      this._dataArr = tempArray;
      this.filteredArr = tempArray;
    } else {
      this.selectedItemId = '';
      this.selectedItemName = '';
    }
  }

  ngOnInit(): void {
    this.SearchItem = this.label;
  }

  ngAfterViewInit(){
    if(this.displayList){
      this.search.nativeElement.focus();
    }
  }

  private setSelectedItem() {
    if (typeof (this.selectedOption) !== 'object') {
      const obj: any = {};
      obj[this.uid] = this.selectedOption ? this.selectedOption : null;
      obj[this.label] = this.selectedOption ? this.selectedOption : null;
      this.selectedOption = obj
    }
    if (this.selectedOption && this._dataArr) {
      let isAvailable = false;
      let selectedObject: any;
      this._dataArr.forEach((item: any) => {
        if (typeof (this.selectedOption) !== 'object') {
          if (item[this.uid] == this.selectedOption) {
            isAvailable = true;
            selectedObject = item;
          }
        } else {
          if (item[this.uid] == this.selectedOption[this.uid]) {
            isAvailable = true;
            selectedObject = item;
          }
        }
      });
      if (isAvailable) {
        if (typeof (this.selectedOption) === 'string') {
          this.selectedItemId = this.selectedOption;
          this.selectedItemName = this.selectedOption;
        } else {
          this.selectedItemId = selectedObject[this.uid];
          this.selectedItemName = selectedObject[this.label];
        }
      }
    }
  }
  clickedOutside(event: any) {
    this.displayList = false;
  }

  selectItem = (item: any) => {
    this.displayList = false;
    this.selectedItemId = item[this.uid];
    this.selectedItemName = item[this.label]
    this.selectedEvent.emit(item[this.uid]);
    this.selectedDisplayValue.emit(item[this.label]);
  }

  onEnter(key: string, item: any) {
    if (key === 'Enter') {
      this.selectItem(item);
    }
  }

}
