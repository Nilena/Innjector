import { Component, OnInit, Output, Input, EventEmitter, HostListener, ViewChild, ElementRef } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Component({
  selector: 'app-terms-and-conditions',
  templateUrl: './terms-and-conditions.component.html',
  styleUrls: ['./terms-and-conditions.component.css']
})
export class TermsAndConditionsComponent implements OnInit {
  @Output() selectedValue = new EventEmitter<boolean>();

  @Input()
  termsAndConditions: SafeHtml | string = ""
  faqData: SafeHtml | string = ""

  @Input() checkBoxval: boolean = false;
  constructor(private sanitizer: DomSanitizer) { }

  @ViewChild('agree') agree : ElementRef|null = null;

  @HostListener('keydown', ['$event'])
  clickarrowx(event: any) {

    if(event.code == 'Escape' || event.key == 'Escape'){
     this.selectedData(false);
    }

  }

  ngOnInit(): void {
    this.termsAndConditions = this.sanitizer.bypassSecurityTrustHtml(this.termsAndConditions.toString());
  }
  
  ngAfterViewInit(): void{
    Promise.resolve().then(()=>this.agree?.nativeElement.focus());

  }

  selectedData(event: boolean) {
    let value = event;
    this.selectedValue.emit(value)
  }
}
