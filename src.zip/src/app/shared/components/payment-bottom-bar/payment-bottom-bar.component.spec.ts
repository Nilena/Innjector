import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentBottomBarComponent } from './payment-bottom-bar.component';

describe('PaymentBottomBarComponent', () => {
  let component: PaymentBottomBarComponent;
  let fixture: ComponentFixture<PaymentBottomBarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaymentBottomBarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentBottomBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
