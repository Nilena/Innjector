import { Component, EventEmitter, OnDestroy, OnInit, Output, Renderer2, HostListener, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { PaymentService } from 'src/app/payment/services/payment.service';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { UserService } from 'src/app/auth/services/user.service';
import { UtilityService } from '../../services/utility.service';

@Component({
  selector: 'app-payment-bottom-bar',
  templateUrl: './payment-bottom-bar.component.html',
  styleUrls: ['./payment-bottom-bar.component.css']
})
export class PaymentBottomBarComponent implements OnInit, OnDestroy {

  public showPaymentOptions: boolean = false;
  public paymentOptionList: any[];
  public selectedPaymentOption: number;

  @ViewChild('payopt') payopt! : ElementRef;
  @Output() paymentOptionChanged: EventEmitter<any> = new EventEmitter();

  constructor(
    private paymentService: PaymentService,
    private router: Router,
    private renderer: Renderer2,
    private userService: UserService,
    private utility: UtilityService
  ) {
    this.paymentOptionList = this.paymentService.paymentOptionList;
    this.selectedPaymentOption = this.paymentService.getSelectedPaymentOption() || 1;
  }

  ngOnInit(): void {
    // this.payopt.nativeElement.focus();
  }

  @HostListener('keydown', ['$event'])
  clickarrowx(event: any) {
    if(event.code == 'Escape' || event.key == 'Escape'){
     this.togglePopup(false);
    }
  }

  togglePopup(status: boolean) {
    this.showPaymentOptions = status;
    if (this.showPaymentOptions) {
      this.renderer.addClass(document.body, 'modal--open');
    } else {
      this.renderer.removeClass(document.body, 'modal--open');
    }
  }

  public gotoPaymentScreen() {
    this.renderer.removeClass(document.body, 'modal--open');
    this.paymentService.setSelectedPaymentOption(this.selectedPaymentOption);
    let user = this.userService.getUserInfo();
    if (user.IsGuest && (this.selectedPaymentOption === 2 ||
      this.selectedPaymentOption === 3 || this.selectedPaymentOption === 4)) {
      this.utility.alert.confirm({
        text: 'To view other payment options, please login or create an account',
        type: 'warning',
        hideCancelButton: true,
        okText: 'Back to login',
        title: ''
      }).then((res: any) => {
        if (res) {
          //this.loaderSub =true;
          this.logout();
        }
      })
      return;
    }


    this.showPaymentOptions = false;
    if (this.selectedPaymentOption == 4) {
      this.router.navigate(['/payment/create-payment-plan']);
      return;
    } else {
      this.router.navigate(['/payment/pay']);
    }
    this.paymentOptionChanged.emit(true);
  }
  /*
     author : Nilena Alexander
     desc   : for clear local storage
   */
  public logout() {
    let loginConfig = this.utility.getTempData(CONSTANTS.APP_CONFIG.login_config);
    this.userService.removeSession(true);
    try {
      if (loginConfig && loginConfig.eLogin == 1) {
        this.router.navigate(['/email-login' + loginConfig.token]);
      } else if (loginConfig.eLogin && loginConfig.eLogin == 2) {
        this.router.navigate(['/text-login' + loginConfig.token]);
      } else {
        this.router.navigate(['/user-login']);
      }
    } catch (err) {
      this.router.navigate(['/user-login']);
    }
  }

  ngOnDestroy(): void {
    this.renderer.removeClass(document.body, 'modal--open');
  }

}
