import { Component, NgZone, OnDestroy, OnInit, HostListener, ViewChild, ElementRef } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs';
import { UtilityService } from '../../services/utility.service';
import { getApiUrl, apiList } from 'src/app/core/constants/api-list';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ApiResponse } from 'src/app/core/models/auth';
import { UserService } from 'src/app/auth/services/user.service';
import { Profile } from 'src/app/core/models/auth';
import { environment } from 'src/environments/environment';
import { CONSTANTS } from 'src/app/core/constants/constants';



@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, OnDestroy {

  @ViewChild('profilesection') profilesection!: ElementRef;

  showProfileMenu: boolean = false;
  userInfoData: Profile | null = null
  sideBar: boolean = false
  private subscriptionMap: { [key: string]: Subscription } = {};
  public headerText: string = '';
  public hideChatIcon: boolean = false;
  public showMakePaymentOptions: boolean = false;
  mhoIcon: boolean = false;

  constructor(
    private router: Router,
    private utility: UtilityService,
    private http: HttpClient,
    private userService: UserService,
    private ngZone: NgZone
  ) { }


  @HostListener('document:click', ['$event'])
  clickout(event: any) {
    if (!this.profilesection?.nativeElement.contains(event.target)) {
      this.showProfileMenu = false
    }
  }

  @HostListener('keydown', ['$event'])
  clickarrowx(event: any) {
    if(event.code == 'Enter' || event.key == 'Enter'){
        if(document.activeElement?.lastChild?.textContent==='Payment Method'){
          this.router.navigate(['/payment-methods/configure-payment'])
        }
        if(document.activeElement?.lastChild?.textContent==='Make a Payment'){
          this.router.navigate(['payment/pay'])
        }
        if(document.activeElement?.lastChild?.textContent==='Online Statements'){
          this.router.navigate(['/online-statement/listing'])
        }
        if(document.activeElement?.lastChild?.textContent==='Payment Plan'){
          this.router.navigate(['payment-plans/list'])
        }
        if(document.activeElement?.lastChild?.textContent==='Payment History'){
          this.router.navigate(['/payment-history/listing'])
        }
    }
  }

  ngOnInit(): void {
    this.subscriptionMap['showMakePaymentOptions'] = this.utility.showMakePaymentOptions$.subscribe(status => {
      this.showMakePaymentOptions = status;
    })
    this.subscriptionMap['headerText'] = this.utility.headerText$.subscribe((text: string) => {
      this.headerText = text;
    })
    this.subscriptionMap['chatIconToggle'] = this.utility.hideChatIcon$.subscribe(status => {
      this.ngZone.run(() => {
        this.hideChatIcon = status;
      })
    })
    this.subscriptionMap['routerChange'] = this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.sideBar = false;
        this.headerText = '';
        this.utility.resetLoader.next(true);
      }
    })
    this.fetchDetails();
    this.userInfoData = this.userService.getUserInfo(true);

    if (this.utility.getTempData(CONSTANTS.SESSION.COM_MHO_EMAIL))
      this.mhoIcon = true;
    else
      this.mhoIcon = false;

  }

  menuBar(event: boolean) {
    this.sideBar = event
  }


  openMenu() {
    this.sideBar = !this.sideBar
  }

  gotoChat() {
    if (this.hideChatIcon) {
      this.router.navigate(['/web-chat']);
    } else {
      this.router.navigate(['/web-chat/2']);
    }
  }

  fetchDetails() {
    let endpoint = getApiUrl(apiList.auth.contactUsMsg);
    this.http.get<ApiResponse>(endpoint).subscribe((response) => {
      if (response.Data) {
        const parsedNumber = "(" + response.Data.slice(0, 3) + ") " + response.Data.slice(3, 6) + "-" + response.Data.slice(6);
        this.utility.setTempData('phoneNumber', parsedNumber);
        this.utility.phoneNumber$.next(parsedNumber);
      }
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }


  mhoLogin() {
    this.userService.removeSession(true);
    let url = environment.mhoDomain;
    window.location.replace(url);

  }


  ngOnDestroy() {
    for (const key in this.subscriptionMap) {
      if (this.subscriptionMap[key]) this.subscriptionMap[key].unsubscribe();
    }
  }

  logoutPopup() {
    this.utility.alert.confirm({
      text: 'Are you sure you want to logout?',
      title: 'Confirmation',
      type: 'warning',
      okText: 'Yes',
      cancelText: 'No'
    }).then(res => {
      if (res) {
        // this.removeSession(); 
        this.logout(); 
      }
    })
  }

  logout() {
    this.userService.logout();
  }

  removeSession() {
    this.userService.removeSession(true);
    this.router.navigate(['/user-login']);
  }

}
