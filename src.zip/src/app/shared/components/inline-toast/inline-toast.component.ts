import { Component, ElementRef, OnInit } from '@angular/core';
import { Toast } from 'src/app/core/models/utility';
import { UtilityService } from '../../services/utility.service';
import { ToasterService } from '../../services/toaster.service';

@Component({
  selector: 'app-inline-toast',
  templateUrl: './inline-toast.component.html',
  styleUrls: ['./inline-toast.component.css']
})
export class InlineToastComponent implements OnInit {

  public iconMap = {
    'success': 'check_circle',
    'error': 'error',
    'warning': 'warning',
    'info': 'info'
  }
  public classMap = {
    'success': 'neu-snackbar--success',
    'error': 'neu-snackbar--error',
    'warning': 'neu-snackbar--warning',
    'info': 'info'
  }
  public btnClassMap = {
    'success': 'neu-button--success',
    'error': 'neu-button--danger',
    'warning': 'neu-button--warning',
    'info': 'info'
  }
  public messageGroup: Toast[] =[...this.toasterService.messageGroup.filter(el=>el.__disableAutoClose)];
  private AGE: number = 5000;

  constructor(
    private utilityService: UtilityService,
    private toasterService: ToasterService
  ) { }

  ngOnInit(): void {

  }

  public removeToast(toast: Toast) {
    if (toast.__lifeSpan) {
      clearTimeout(toast.__lifeSpan);
    }
    let index = this.messageGroup.findIndex(el => el.__id === toast.__id);
    if (index != -1) {
      this.messageGroup.splice(index, 1);
    }
  }

  public clearToast() {
    this.messageGroup.forEach(toast => {
      this.removeToast(toast);
    })
  }

  public inlineToast(toast: Toast) {
    toast.__id = new Date().getTime();
    if (!toast.__disableAutoClose) {
      toast.__lifeSpan = setTimeout(() => {
        this.removeToast(toast);
      }, this.AGE)
    }
    this.messageGroup.unshift(toast);
  }

  

}
export interface InlineToaster extends ElementRef {
  inlineToast: (toast: Toast) => void;
  clearToast: () => void;
}
