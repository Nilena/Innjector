import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InlineToastComponent } from './inline-toast.component';

describe('InlineToastComponent', () => {
  let component: InlineToastComponent;
  let fixture: ComponentFixture<InlineToastComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InlineToastComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InlineToastComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
