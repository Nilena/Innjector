import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { UtilityService } from '../../services/utility.service';
import { tooltipAnimation } from '../../utilities/animations'

@Component({
  selector: 'app-tooltip',
  templateUrl: './tooltip.component.html',
  styleUrls: ['./tooltip.component.css'],
  animations: [tooltipAnimation]
})
export class TooltipComponent implements OnInit {

  public toolTip: any = null;
  @ViewChild('tip', { static: false }) tip: ElementRef | null = null;

  constructor(
    private utility: UtilityService
  ) {
    this.utility.toolTipBuffer$.subscribe(tip => {
      this.toolTip = tip;
    })
  }

  ngOnInit(): void {
  }

}
