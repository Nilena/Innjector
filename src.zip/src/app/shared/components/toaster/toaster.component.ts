import { Component, OnInit, OnDestroy } from '@angular/core';
// import { Toast, UtilityService } from '../../services/utility.service';
import { ToasterService } from '../../services/toaster.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-toaster',
  templateUrl: './toaster.component.html',
  styleUrls: ['./toaster.component.css']
})
export class ToasterComponent implements OnInit, OnDestroy {

  public iconMap : { [key: string]: string }= {
    'success': 'check_circle',
    'error': 'error',
    'warning': 'warning',
    'info': 'info'
  }
  public classMap: { [key: string]: string } = {
    'success': 'neu-snackbar--success',
    'error': 'neu-snackbar--error',
    'warning': 'neu-snackbar--warning',
    'info': 'info'
  }
  public btnClassMap: { [key: string]: string } = {
    'success': 'neu-button--success',
    'error': 'neu-button--danger',
    'warning': 'neu-button--warning',
    'info': 'info'
  }

  constructor(public toasterService: ToasterService) { }



  ngOnInit(): void {

  }
  ngOnDestroy(): void {
  }
}
