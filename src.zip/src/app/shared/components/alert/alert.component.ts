import { Component, OnInit, Renderer2, HostListener, ViewChild, ElementRef } from '@angular/core';
import { UtilityService } from '../../services/utility.service';
import { AlertType, alertInfoTrigger } from 'src/app/core/models/utility';

@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.css']
})
export class AlertComponent implements OnInit {

  public showAlert: boolean = false;
  private resolve: any;
  public title: string = '';
  public text: string = '';
  public type: AlertType = 'success';
  public hideCancelButton: boolean = false;
  public hideOkButton: boolean = false;
  public okText: string = 'Ok';
  public cancelText: string = 'Cancel';
  public iconMap = {
    'success': 'success',
    'error': 'err',
    'warning': 'warning',
    'info': 'info'
  }
  public isTitleCash: boolean | undefined = false;

  constructor(
    private utilityService: UtilityService,
    private renderer: Renderer2
  ) { }


  @HostListener('keydown', ['$event'])
  clickarrowx(event: any) {
    if(event.code == 'Escape' || event.key == 'Escape'){
      this.confirm(false);
    }
  }

  @ViewChild('ok') ok! : ElementRef; 

  ngOnInit(): void {
    this.utilityService.alertTrigger$.subscribe(({ type, title, text, okText, cancelText, hideCancelButton, hideOkButton, resolve, isTitleCash }: alertInfoTrigger) => {
      this.showAlert = true;
      this.renderer.addClass(document.body, 'modal--open');
      this.resolve = resolve;
      this.type = type;
      this.title = title;
      this.text = text;
      this.okText = okText || 'Ok';
      this.cancelText = cancelText || 'Cancel';
      this.hideCancelButton = hideCancelButton || false;
      this.hideOkButton = hideOkButton || false;
      this.isTitleCash = isTitleCash
      setTimeout(()=> {
        this.ok.nativeElement.focus();
      });
      
    })
  }



  confirm(status: boolean) {
    // this.decision.emit({status, data: this.data});
    this.resolve(status);
    this.showAlert = false;
    this.renderer.removeClass(document.body, 'modal--open');
  }


}
