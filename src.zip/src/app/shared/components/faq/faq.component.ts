import { Component, OnDestroy, OnInit, Renderer2, SecurityContext } from '@angular/core';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ApiResponse, RegisterPayload } from 'src/app/core/models/auth';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { UserService } from 'src/app/auth/services/user.service';


@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css']
})
export class FaqComponent implements OnInit, OnDestroy {

  private headElements?: NodeListOf<Element>;
  // private eventList: any[] = [];

  constructor(
    private http: HttpClient,
    private utility: UtilityService,
    private sanitizer: DomSanitizer,
    private userService: UserService,
    private renderer: Renderer2
  ) { }

  faqData: SafeHtml | string = ""


  ngOnInit(): void {
    this.gtmLog('Expand', 'page FAQ expanded on', "FAQ");
    this.faqDatafetch()
  }
  back() {
    history.back();
  }

  headClickHandler(event: Event) {
    let targetElement = event.currentTarget as HTMLElement;
    let contentId = targetElement.getAttribute('aria-controls') as string;
    let content = document.getElementById(contentId);
    if(content?.hasAttribute('hidden')) {
      content.removeAttribute('hidden');
      targetElement.classList.add('collapsed');
      // this.renderer.addClass(targetElement, 'collapsed');
    } else {
      content?.setAttribute('hidden', 'true');
      targetElement.classList.remove('collapsed');
      // this.renderer.removeClass(targetElement, 'collapsed');
    }
  }

  addClickEvent() {
    let headElements = document.querySelectorAll('.accordion-trigger');
    headElements.forEach(el => {
       el.addEventListener('click', this.headClickHandler);
    })
  }

  ngOnDestroy(): void {
    // this.eventList.forEach(event => {
      
    // })
  }

  faqDatafetch() {
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.auth.faqForMob);
    // let endpoint = getApiUrl(apiList.auth.faq);
    let payload = { }

    this.http.get<ApiResponse>(endpoint, payload).subscribe((data) => {
      if (data.Status == true) {
        // this.utility.alert.toast({ title: data.Message, type: 'success' });
        this.faqData = this.sanitizer.bypassSecurityTrustHtml(data.Data);
        setTimeout(() => {
          this.addClickEvent();
        }, 500)
      }
      else {
        this.utility.alert.toast({ title: data.Message, type: 'error' });
      }
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
        console.log(err);
        this.utility.alert.toast({ title: err?.error?.message, type: 'error'});
        this.utility.loader.next(false);
      })

  }


  private gtmLog(title: string, item: string, category: string) {
    let data: any = {};
    let user = this.userService.getUserInfo();
    data.event_title = title;
    data.data_object = {
      item_selected: item
    }
    data.event_interactive = true;
    data.event_logged_in = user ? true : false;
    data.event_category = category;
    data.event_registration_type = user ? (user.IsGuest ? 'guest' : user.FromMHO ? 'mho' : 'epay') : null;
    data.event_facility = user ? user.ClientCode : null;
    data.event_user_id = user ? user.UserID : null;
    data.event_user_type = user ? 'patient' : null;
    data.event_success = true;
    data.event_session_id = user ? user.RequestToken : null;
    this.utility.googleTrack(data);
  }

}
