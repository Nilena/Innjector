import { Component, Input, OnInit } from '@angular/core';
import { UtilityService } from '../../services/utility.service';

@Component({
  selector: 'app-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.css']
})
export class LoaderComponent implements OnInit {

  @Input('commonLoader') commonLoader: boolean = false;

  constructor(
    public utility: UtilityService
  ) { }

  ngOnInit(): void {
    if (this.commonLoader) {
      this.utility.loader.subscribe(status => {
        if (status) {
          this.utility.loaderCount += 1;
        } else {
          this.utility.loaderCount -= 1;
          if (this.utility.loaderCount < 0) this.utility.loaderCount = 0;
        }
      })
      this.utility.paymentLoader.subscribe(status => {
        if (status) {
          this.utility.paymentLoaderCount += 1;
        } else {
          this.utility.paymentLoaderCount -= 1;
          if (this.utility.paymentLoaderCount < 0) this.utility.paymentLoaderCount = 0;
        }
      })
      this.utility.ssoLoader.subscribe(status => {
        if (status) {
          this.utility.ssoLoaderCount += 1;
        } else {
          this.utility.ssoLoaderCount -= 1;
          if (this.utility.ssoLoaderCount < 0) this.utility.ssoLoaderCount = 0;
        }
      })
      this.utility.resetLoader.subscribe(status => {
        if (status) {
          this.utility.loaderCount = 0;
          this.utility.paymentLoaderCount = 0;
          this.utility.ssoLoaderCount = 0;
        }
      })
    }
  }

}
