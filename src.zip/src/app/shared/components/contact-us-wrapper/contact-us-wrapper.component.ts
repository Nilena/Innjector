import { Component, OnInit, ViewChild, ElementRef, HostListener } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/internal/Subscription';
import { UtilityService } from '../../services/utility.service';

@Component({
  selector: 'app-contact-us-wrapper',
  templateUrl: './contact-us-wrapper.component.html',
  styleUrls: ['./contact-us-wrapper.component.css']
})
export class ContactUsWrapperComponent implements OnInit {
  showNav: boolean = true;
  activeView: number = 1;
  private subscriptionMap: { [key: string]: Subscription } = {};
  public hideChatIcon: boolean = true;
  @ViewChild('message') message! : ElementRef;
  constructor(
    private activatedRoute: ActivatedRoute,
    private utility: UtilityService) {
    let view = this.activatedRoute.snapshot.paramMap.get('id');
    if (view) {
      this.activeView = Number(view)
    }
  }
  @HostListener('keydown', ['$event'])
  clickarrowx(event: any) {
    if(event.code == 'Enter' || event.key == 'Enter'){
        if(document.activeElement?.lastChild?.textContent==='Chat'){
         this.activeView = 2;
        }
    }
  }

  ngOnInit(): void {
    this.subscriptionMap['chatIconToggle'] = this.utility.hideChatIcon$.subscribe(status => {
      this.hideChatIcon = status;
      if (this.hideChatIcon) {
        this.activeView = 1;
      }
    })
  }

  funcshowNav() {
    this.showNav = false;

  }
  ngAfterViewInit(){
    this.message.nativeElement.focus();
  }


  goback() {
    history.back();
  }

  ngOnDestroy() {
    for (const key in this.subscriptionMap) {
      if (this.subscriptionMap[key]) this.subscriptionMap[key].unsubscribe();
    }
  }

}
