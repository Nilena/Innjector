import { Component, OnInit, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormControl, Validators, ValidatorFn, AbstractControl, ValidationErrors, FormControlName } from '@angular/forms';
import { CustomValidation } from '../../utilities/custom-validator';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ApiResponse, RegisterPayload, Profile } from 'src/app/core/models/auth';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { UserService } from 'src/app/auth/services/user.service';
import { ActivatedRoute } from '@angular/router';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})


export class ContactUsComponent implements OnInit {

  @Output()
  contact = new EventEmitter();

  public contactUsForm: FormGroup;
  public get controls() { return this.contactUsForm.controls };
  public contactusConfirm: boolean = false;
  public contactconfirm: boolean = false;
  public savingInProgress: boolean = false;
  public phoneNumber: string = "";
  userInfoData: Profile | null = null;
  public clientToken: string | null;
  private subscriptionMap: { [key: string]: Subscription } = {};


  constructor(
    private http: HttpClient,
    private utility: UtilityService,
    private userService: UserService,
    private activatedRoute: ActivatedRoute
  ) {
    //this.clientToken = this.activatedRoute.snapshot.paramMap.get('clientToken');
    this.clientToken = this.utility.getTempData('EncString');
    if (this.clientToken == 'undefined' || this.clientToken == 'null' || this.clientToken == null) {
      this.clientToken = ""
    }
    this.contactUsForm = new FormGroup({
      phoneNumber: new FormControl(null, Validators.compose([Validators.required, CustomValidation.noSpaceOnly])),
      firstName: new FormControl(null, Validators.compose([Validators.required, CustomValidation.noSpaceOnly])),
      lastName: new FormControl(null, Validators.compose([Validators.required, CustomValidation.noSpaceOnly])),
      accNo: new FormControl(null, Validators.compose([Validators.required, CustomValidation.noSpaceOnly])),
      facility: new FormControl(null),
      yourQuestion: new FormControl(null, Validators.compose([Validators.required])),
      morning: new FormControl(false, Validators.compose([Validators.required])),
      midday: new FormControl(false, Validators.compose([Validators.required])),
      afternoon: new FormControl(false, Validators.compose([Validators.required])),
    }, Validators.compose([this.checkboxvalidation()]))
  }
  private gtmLog(title: string, item: string, category: string) {
    let data: any = {};
    let user = this.userService.getUserInfo();
    data.event_title = title;
    data.data_object = {
      item_selected: item
    }
    data.event_interactive = true;
    data.event_logged_in = user ? true : false;
    data.event_category = category;
    data.event_registration_type = user ? (user.IsGuest ? 'guest' : user.FromMHO ? 'mho' : 'epay') : null;
    data.event_facility = user ? user.ClientCode : null;
    data.event_user_id = user ? user.UserID : null;
    data.event_user_type = user ? 'patient' : null;
    data.event_success = true;
    data.event_session_id = user ? user.RequestToken : null;
    this.utility.googleTrack(data);
  }
  private checkboxvalidation(): ValidatorFn {
    return (formGroup: AbstractControl): ValidationErrors | null => {
      let morning = formGroup.get('morning')?.value;
      let midday = formGroup.get('midday')?.value;
      let afternoon = formGroup.get('afternoon')?.value;
      if (morning || midday || afternoon) {
        return null;

      }
      return { checkboxvalidation: true }
    }
  }

  ngOnInit(): void {
    this.subscriptionMap['phoneNumber'] = this.utility.phoneNumber$.subscribe(number => {
      this.phoneNumber = number;
      //console.log(this.phoneNumber)
    })

    //this.fetchDetails()
    this.gtmLog("Expand", 'page contact us expanded on', "Contact Us");
    //this.phoneNumber = this.utility.getTempData('phoneNumber');
    this.userInfoData = this.userService.getUserInfo();
    // this.userInfoData.UserHeader.FirstName;
    //this.userInfoData.UserHeader.LastName;
    if (this.userInfoData != null) {
      this.contactUsForm.controls.firstName?.setValue(this.userInfoData.UserHeader.FirstName);
      this.contactUsForm.controls.lastName?.setValue(this.userInfoData.UserHeader.LastName);
      this.contactUsForm.controls.accNo?.setValidators(null);
    }
    
  }
  confirm() {
    this.contactusConfirm = true;

    if (this.contactUsForm.valid) {
      this.savingInProgress = true;
      let endpoint = getApiUrl(apiList.auth.contactUs);

      let payload = {
        "Phone": this.contactUsForm.controls.phoneNumber.value,
        "FirstName": this.contactUsForm.controls.firstName.value,
        "LastName": this.contactUsForm.controls.lastName.value,
        "AccountNo": this.contactUsForm.controls.accNo.value,
        "FacilityName": this.contactUsForm.controls.facility.value,
        "IssueMessage": this.contactUsForm.controls.yourQuestion.value,
        "Callback_Morning": this.contactUsForm.controls.morning.value,
        "Callback_Midday": this.contactUsForm.controls.midday.value,
        "Callback_Afternoon": this.contactUsForm.controls.afternoon.value,
        "PeopleID": 0,
        "Name": this.contactUsForm.controls.firstName.value + " " + this.contactUsForm.controls.lastName.value
      }
      this.http.post<ApiResponse>(endpoint, payload).subscribe((data) => {
        this.savingInProgress = false;
        this.contact.emit("false")
        this.contactconfirm = true;

      }
        , (err: HttpErrorResponse) => {
          console.log(err);
          this.savingInProgress = false;
          this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
        }

      )
    }
  }
  goback() {
    history.back();
  }
  ngOnDestroy() {
    for (const key in this.subscriptionMap) {
      if (this.subscriptionMap[key]) this.subscriptionMap[key].unsubscribe();
    }
  }
}
