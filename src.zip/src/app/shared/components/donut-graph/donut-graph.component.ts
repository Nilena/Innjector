import { AfterViewInit, Component, ElementRef, Input, OnInit, Renderer2, ViewChild } from '@angular/core';

@Component({
  selector: 'app-donut-graph',
  templateUrl: './donut-graph.component.html',
  styleUrls: ['./donut-graph.component.css']
})
export class DonutGraphComponent implements OnInit, AfterViewInit {

  @Input() label: string | number = '';
  @Input('id') id = 1;
  @Input() percentage: number = 0;
  @Input() subLabel: string | number = '';
  @ViewChild('circle', { static: false }) circle: ElementRef | null = null;
  public circumference: number = 0;

  constructor(
    private renderer: Renderer2
  ) { }

  ngOnInit(): void {
  }

  ngAfterViewInit(): void {
    if (this.circle) {
      let radius = this.circle.nativeElement.r.baseVal.value;
      this.circumference = radius * 2 * Math.PI;
      this.renderer.setStyle(this.circle.nativeElement, 'strokeDasharray', `${this.circumference} ${this.circumference}`);
      this.renderer.setStyle(this.circle.nativeElement, 'strokeDashoffset', `${this.circumference}`);
      this.setProgress(this.percentage);
    }
  }
  public setProgress(percent: number) {
    const offset = this.circumference - percent / 100 * this.circumference;
    if (this.circle) {
      this.renderer.setStyle(this.circle.nativeElement, 'strokeDashoffset', offset);
    }
  }
}
