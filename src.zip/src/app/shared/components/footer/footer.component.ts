import { Component, OnInit, NgZone } from '@angular/core';
import { Subscription } from 'rxjs';
import { UtilityService } from '../../services/utility.service';
import { Router } from '@angular/router';
import {environment} from '../../../../environments/environment'
 
@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  private subscriptionMap: { [key: string]: Subscription } = {};
  public hideChatIcon: boolean = false;
  public phoneNumber: string = '';
  public webServer : string = environment.webServer;

  constructor( private router: Router,private utility: UtilityService, private ngZone: NgZone) { }

  ngOnInit(): void {
    this.subscriptionMap['chatIconToggle'] = this.utility.hideChatIcon$.subscribe(status => {
      this.ngZone.run(() => {
        this.hideChatIcon = status;
      })
    })
    this.subscriptionMap['phoneNumber'] = this.utility.phoneNumber$.subscribe(number => {
      this.phoneNumber = number;
      //console.log(this.phoneNumber)
    })
  }
  gotoChat() {
    if (this.hideChatIcon) {
      this.router.navigate(['/web-chat']);
    } else {
      this.router.navigate(['/web-chat/2']);
    }
  }
  ngOnDestroy() {
    for (const key in this.subscriptionMap) {
      if (this.subscriptionMap[key]) this.subscriptionMap[key].unsubscribe();
    }
  }
}
