
import { Component, NgZone, OnDestroy, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormControl, Validators, ValidatorFn, AbstractControl, ValidationErrors, FormControlName } from '@angular/forms';
import { CustomValidation } from '../../utilities/custom-validator';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { getApiUrl, apiList } from 'src/app/core/constants/api-list';
import { ApiResponse, Profile } from 'src/app/core/models/auth';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { UserService } from 'src/app/auth/services/user.service';
import { Meta } from '@angular/platform-browser';


@Component({
  selector: 'app-web-chat',
  templateUrl: './web-chat.component.html',
  styleUrls: ['./web-chat.component.css']
})
export class WebChatComponent implements OnInit, OnDestroy {

  public webChatForm: FormGroup;
  public webchatSubmitted: boolean = false;
  clientName: string = '';
  public get controls() { return this.webChatForm.controls };
  public reasonList = [];
  userInfo: Profile | null = null;

  private ifrm: any;
  public scriptKey = null;
  public facilitydata = null;
  private reIfrm: any;
  public showOfflineMsg: boolean = false;
  private onceBack: boolean = false;
  
  constructor(private http: HttpClient,
    private utility: UtilityService,
    private ngZone: NgZone,
    private readonly meta: Meta,
    private userService: UserService) {
    this.userInfo = this.userService.getUserInfo();
    let userFullName = null;
    let email = null;
    if (this.userInfo) {
      userFullName = `${this.userInfo.UserHeader?.FirstName} ${this.userInfo.UserHeader?.LastName || ''}`;
      email = `${this.userInfo.UserHeader?.Email || ''}`;
    }
    this.webChatForm = new FormGroup({
      name: new FormControl(userFullName, Validators.compose([Validators.required, CustomValidation.noSpaceOnly])),
      emailAddress: new FormControl(email, Validators.compose([Validators.required, CustomValidation.email])),
      phoneNumber: new FormControl(null, Validators.compose([Validators.required, CustomValidation.noSpaceOnly])),
      accNumber: new FormControl(null, Validators.compose([Validators.required])),
      cName: new FormControl(null),
      reasonforContact: new FormControl(null, Validators.compose([Validators.required])),
      otherReasson: new FormControl(null),
    })
  }

  ngOnInit(): void {
    this.getDetails();
    // this.utility.setTempData("chatApp", this.chatApp);
  }
  init() {
    this.webchatSubmitted = true;
    if (this.webChatForm.valid) {
      let endpoint = getApiUrl(apiList.auth.getChat + '?accountNumber=' + this.controls.accNumber.value);
      this.utility.loader.next(true);
      this.http.get<ApiResponse>(endpoint).subscribe((response) => {
        if (response.Data) {
          this.scriptKey = response.Data.ScriptKey;
          this.facilitydata = response.Data.ClientName;
          this.injectStript();
        }
        this.utility.loader.next(false);
      }, (err: HttpErrorResponse) => {
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
        this.utility.loader.next(false);
      })
    }
  }

  private injectStript() {
    // let userDetails = this.userInfo;
    // let Name = this.controls.name.value;
    // let Phone = this.controls.phoneNumber.value;
    // let Facility = this.controls.cName.value;
    // let Account = this.controls.accNumber.value ? this.controls.accNumber.value : this.userInfo?.AccountNo;
    // let Context = window.location.href;
    // let Question = this.controls.reasonforContact.value;
    this.utility.loader.next(true);
    let currWidget;
    let se: any = document.createElement('script');
    se.type = 'text/javascript';
    se.async = true;
    se.setAttribute("id", "snap-script-imp");
    se.src = '//storage.googleapis.com/code.snapengage.com/js/' + this.scriptKey + '.js'; //'09368a63-0d08-4bf6-82ce-55715017f790' | this.scriptKey
    let done = false;
    se.onload = (se as any).onreadystatechange = () => {
      if (!done && (!se.readyState || se.readyState === 'loaded' || se.readyState === 'complete')) {
        done = true;
        currWidget = (window as any).SnapEngage.getWidgetId();
        // $timeout(function () {
        //   widge.showLoader = true;
        // })
        /* only show chat if agent is online*/
        (window as any).SnapEngage.getAgentStatusAsync((online: any) => {
          this.utility.loader.next(false);
          this.setUpChat(online);
        });
      }
    };
    let s = document.getElementsByTagName('script')[0];
    if (s && s.parentNode) s.parentNode.insertBefore(se, s);
  }

  private setUpChat(online: any) {
    let acconuNumberValue = this.controls.accNumber.value ? this.controls.accNumber.value : this.userInfo?.AccountNo;
    let client_Name = this.controls.cName.value;
    let reasonDataCopy = this.controls.reasonforContact.value;
    (window as any).SnapEngage.setCustomField('company', acconuNumberValue);
    (window as any).SnapEngage.setCustomField('phone', this.controls.phoneNumber.value);
    (window as any).SnapEngage.setCustomField('ClientName', client_Name);
    (window as any).SnapEngage.setUserEmail(this.controls.emailAddress.value, false);
    (window as any).SnapEngage.setUserName(this.controls.name.value);
    (window as any).SnapEngage.setDescription(this.controls.reasonforContact.value);
    // set values
    (window as any).SnapEngage.setUserEmail("", false);
    (window as any).SnapEngage.setUserName("");
    (window as any).SnapEngage.startLink();
    this.ifrm = document.getElementById("designstudio-iframe");
    if (this.ifrm) this.ifrm.style.display = 'none';
    if (online) {
      setTimeout(() => {
        this.initializeChat();
      }, 1000)

    } else {
      setTimeout(() => {
        this.setOfflineChat();
      }, 1000)
    }
  }
  private initializeChat() {
    let form = this.ifrm.contentWindow.document.getElementById('prechat-form');
    let chlid = this.ifrm.contentWindow.document.getElementById("prechat-start-chat");
    form.elements["name"].value = this.controls.name.value;
    form.elements["email"].value = this.controls.emailAddress.value;
    form.elements["phone"].value = this.controls.phoneNumber.value;
    //comment below 3 lines to test with hardcoded key
    form.elements["clientName"].value = this.controls.cName.value;
    form.elements["company"].value = this.controls.accNumber.value ? this.controls.accNumber.value : this.userInfo?.AccountNo;
    form.elements["ReasonforContacting"].value = this.controls.reasonforContact.value;
    if (chlid) {
      chlid.click();
    }
    // $rootScope.openchatForm = false;
    // $rootScope.showContactUs = true;
    // $rootScope.openContactUs = false;
    // this.timer = setInterval(checkOnlineStatus, 500);
    // widge.showLoader = false;
    this.ifrm.style.display = 'block';
    (window as any).SnapEngage.setCallback('Close', (type: any, status: any) => {
      (window as any).SnapEngage.clearAllCookies();
      // clearInterval(timer);
      this.removeElements();
     //this.goback();
      this.utility.hideChatIcon$.next(false);
    });
    (window as any).SnapEngage.setCallback('Minimize', (isMinimized: any, chatType: any, boxType: any) => {
      //this.goback();
      this.utility.hideChatIcon$.next(true);
      // this.utility.setTempData('chatIconStatus', true);
      // document.getElementById('icon-minimize')?.remove();
    });
    (window as any).SnapEngage.setCallback('OpenProactive', (status: any) => {
    });
    this.goback();
  }

  private setOfflineChat() {
    let chlid = this.ifrm.contentWindow.document.getElementById("offline-send-email");
    let form = this.ifrm.contentWindow.document.getElementById('offline-form');
    form.elements["name"].value = this.controls.name.value;
    form.elements["email"].value = this.controls.emailAddress.value;
    form.elements["phone"].value = this.controls.phoneNumber.value;
    // form.elements["company"].value = this.controls.accNumber.value ? this.controls.accNumber.value : this.userInfo?.AccountNo;
    // form.elements["ClientName"].value = this.controls.cName.value;
    // form.elements["Account"].value = widge.form.acno;
    // form.elements["description"].value = this.controls.reasonforContact.value;
    if (chlid) {
      chlid.click();
    }
    this.showOfflineMsg = true;
    // widge.showForm = false;
    // widge.showofflineMsg = true;
    // widge.showLoader = false;
    this.removeElements();
  }
  private removeElements() {
    this.ngZone.run(() => {
      document.getElementById('designstudio')?.remove();
      document.getElementById('snap-script-imp')?.remove();
      document.getElementById('designstudio-iframe')?.remove();
      document.getElementById('designstudio-minimize')?.remove();

      this.removeDefaultChatButton();
    })
    this.removeMetaTag();
  }
  private removeMetaTag() {
    let metaTagList: HTMLCollectionOf<HTMLMetaElement> | HTMLMetaElement[] = document.getElementsByTagName('meta');
    if(metaTagList && metaTagList.length) {
      metaTagList = Array.from(metaTagList);
      metaTagList.forEach(el => {
        if(el.hasAttribute('content') && el.getAttribute('content') == 'width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no'){
          // document.head.removeChild(el);
          el.setAttribute('content', 'width=device-width, initial-scale=1.0');
        }
      })
      // if(metaTagList.length > 1) return;
      // let newMeta = document.createElement('meta');
      // newMeta.setAttribute('name', 'viewport');
      // newMeta.setAttribute('content', 'width=device-width, initial-scale=1.0');
      // document.head.appendChild(newMeta);
    }
  }
  removeDefaultChatButton() {
    setTimeout(() => {
      this.reIfrm = document.getElementById("designstudio-button");
      document.getElementById('transparent-button')?.remove();
      if (!this.reIfrm) this.removeDefaultChatButton();
      this.reIfrm.style.display = 'none';
    }, 100)
  }

  goback() {
    if (!this.onceBack) {
      this.onceBack = true;
      history.back();
    }
  }
  getDetails() {
    let EncString: string | undefined;
    if (this.utility.getTempData('EncString')) {
      EncString = (this.utility.getTempData('EncString'));
    }
    let endpoint = getApiUrl(apiList.auth.webChat);
    let payload = {
      "ClientgroupId": (this.userInfo?.ClientGroupID) ? 1 : 0,
      "Statuskeys": "WebChatReasonType",
      "MessageKeys": "WebChatHeaderMessage,WebChatFooterMessage",
      "EncString": EncString ? EncString : "clinic",
      "ClientGroupMapGuid": EncString ? EncString : undefined
    }
    this.utility.loader.next(true);
    this.http.post<ApiResponse>(endpoint, payload).subscribe((data) => {
      this.reasonList = data.Data.stauslist;
      this.clientName = data.Data.ClientName;
      this.webChatForm.controls.cName?.setValue(this.clientName);

      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.utility.loader.next(false);
    })
  }

  reasonForContactSelected(reason: any) {
    this.controls.reasonforContact.setValue(reason);
  }
  ngOnDestroy(): void {
    this.removeMetaTag();
  }


}













