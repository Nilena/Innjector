import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { CommonModule } from '@angular/common';

import { CookieService } from 'ngx-cookie-service';

import { IgxMaskDirective } from './directives/igx-mask.directive';
import { NumberDirective } from './directives/number/number.directive';
import { TooltipDirective } from './directives/tooltip.directive';

import { SingleSelectComponent } from './components/single-select/single-select.component';
import { AlertComponent } from './components/alert/alert.component';
import { ToasterComponent } from './components/toaster/toaster.component';
import { MultiSelectorComponent } from './components/multi-selector/multi-selector.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { SideBarComponent } from './components/side-bar/side-bar.component';
import { LoaderComponent } from './components/loader/loader.component';
import { DonutGraphComponent } from './components/donut-graph/donut-graph.component';
import { TooltipComponent } from './components/tooltip/tooltip.component';
// import { SubmenuPaymentMethodsComponent } from './submenu-payment-methods/submenu-payment-methods.component';

import { DateTimePipe } from './pipes/date-time.pipe';
import { PaymentBottomBarComponent } from './components/payment-bottom-bar/payment-bottom-bar.component';
import { SearchPipe } from './pipes/search.pipe';
import { TermsAndConditionsComponent } from './components/terms-and-conditions/terms-and-conditions.component';
import { SubmenuPaymentMethodsComponent } from '../payment-methods/submenu-payment-methods/submenu-payment-methods.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { ContactUsWrapperComponent } from './components/contact-us-wrapper/contact-us-wrapper.component';
import { FaqComponent } from './components/faq/faq.component';
import { WebChatComponent } from './components/web-chat/web-chat.component';
import { SurveyMonkeyComponent } from './components/survey-monkey/survey-monkey.component';
import { RoleGuardService } from './services/role-guard.service';
import { InlineToastComponent } from './components/inline-toast/inline-toast.component';
import { ErrorPageComponent } from './components/error-page/error-page.component';

@NgModule({
  declarations: [
    SingleSelectComponent,
    IgxMaskDirective,
    AlertComponent,
    ToasterComponent,
    MultiSelectorComponent,
    HeaderComponent,
    FooterComponent,
    SideBarComponent,
    LoaderComponent,
    DateTimePipe,
    NumberDirective,
    TooltipDirective,
    TooltipComponent,
    DonutGraphComponent,
    PaymentBottomBarComponent,
    SearchPipe,
    TermsAndConditionsComponent,
    SubmenuPaymentMethodsComponent,
    ContactUsComponent,
    ContactUsWrapperComponent,
    FaqComponent,
    WebChatComponent,
    SurveyMonkeyComponent,
    InlineToastComponent,
    ErrorPageComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule
  ],
  exports: [
    SingleSelectComponent,
    IgxMaskDirective,
    AlertComponent,
    ToasterComponent,
    MultiSelectorComponent,
    HeaderComponent,
    FooterComponent,
    SideBarComponent,
    LoaderComponent,
    DateTimePipe,
    NumberDirective,
    TooltipDirective,
    TooltipComponent,
    DonutGraphComponent,
    PaymentBottomBarComponent,
    SearchPipe,
    TermsAndConditionsComponent,
    SubmenuPaymentMethodsComponent,
    ContactUsComponent,
    FaqComponent,
    WebChatComponent,
    SurveyMonkeyComponent,
    InlineToastComponent,
    ErrorPageComponent
  ],
  providers:[
    CookieService,
    RoleGuardService
  ]
})
export class SharedModule { }
