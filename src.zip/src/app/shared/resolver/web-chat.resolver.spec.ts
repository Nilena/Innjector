import { TestBed } from '@angular/core/testing';

import { WebChatResolver } from './web-chat.resolver';

describe('WebChatResolver', () => {
  let resolver: WebChatResolver;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    resolver = TestBed.inject(WebChatResolver);
  });

  it('should be created', () => {
    expect(resolver).toBeTruthy();
  });
});
