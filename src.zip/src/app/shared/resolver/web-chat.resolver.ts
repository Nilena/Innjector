import { Injectable } from '@angular/core';
import {
  Router, Resolve,
  RouterStateSnapshot,
  ActivatedRouteSnapshot
} from '@angular/router';
import { from, Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { UtilityService } from '../services/utility.service';

@Injectable({
  providedIn: 'root'
})
export class WebChatResolver implements Resolve<boolean> {
  constructor(private utility: UtilityService) {}
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    let hideChatIcon = false;
    return from(this.utility.hideChatIcon$.pipe(map(status => !status)));
    // return of(true);
  }
}
