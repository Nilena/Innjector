import { Injectable } from '@angular/core';
import {
  Router, Resolve,
  RouterStateSnapshot,
  ActivatedRouteSnapshot
} from '@angular/router';
import { Observable, of } from 'rxjs';
import { UtilityService } from '../services/utility.service';

@Injectable({
  providedIn: 'root'
})
export class TempResolver implements Resolve<boolean> {
  constructor(private utility: UtilityService, private router: Router) { }
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    let headerId = route.paramMap.get('headerId');
    let tempId = this.utility.getTempData('tempId');
    if (tempId || headerId) {
      return of(true);
    }
    this.router.navigate(['/dashboard']);
    return of(false);
  }
}
