import { TestBed } from '@angular/core/testing';

import { TempResolver } from './temp.resolver';

describe('TempResolver', () => {
  let resolver: TempResolver;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    resolver = TestBed.inject(TempResolver);
  });

  it('should be created', () => {
    expect(resolver).toBeTruthy();
  });
});
