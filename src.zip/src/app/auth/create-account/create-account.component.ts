import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild, ElementRef, NgZone } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { ApiResponse, RegisterPayload } from 'src/app/core/models/auth';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { CustomValidation } from 'src/app/shared/utilities/custom-validator';
import { UserService } from '../services/user.service';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { Subscription } from 'rxjs';
import { REGCONSTANTS } from '../../core/constants/regex-constants';



@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent implements OnInit {

  public registerForm: FormGroup;
  public registerInProgress: boolean = false;
  public registerSubmitted: boolean = false;
  public showPassword: boolean = false;
  public get controls() { return this.registerForm.controls };
  public clientToken: string | null;
  public errorMessage: string | null = null;
  public hint: string | null = null;
  private subscriptionMap: { [key: string]: Subscription } = {};
  public hideChatIcon: boolean = false;

  @ViewChild('firstName') firstName! : ElementRef;

  constructor(
    private userService: UserService,
    private utility: UtilityService,
    private http: HttpClient,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private ngZone: NgZone
  ) { 
    this.clientToken = this.activatedRoute.snapshot.paramMap.get('clientToken');
    this.hint = CONSTANTS.PASSWORD_HINT.PSWD_HINT;
    this.registerForm = new FormGroup({
      FirstName: new FormControl(null, Validators.compose([Validators.required, CustomValidation.noSpaceOnly, Validators.pattern(REGCONSTANTS.nameValidation)])),
      LastName: new FormControl(null, Validators.compose([Validators.required, CustomValidation.noSpaceOnly, Validators.pattern(REGCONSTANTS.nameValidation)])),
      Email: new FormControl(null, {validators:Validators.compose([Validators.required, CustomValidation.email]),updateOn: 'blur'}),
      ConfirmEmail: new FormControl(null,{validators:Validators.compose([Validators.required]),updateOn: 'blur'}),
      UserName: new FormControl(null, Validators.compose([Validators.required, CustomValidation.noSpaceOnly])),
      Password: new FormControl(null, Validators.compose([Validators.required, Validators.maxLength(50), Validators.minLength(8), CustomValidation.PasswordRule])),
      ConfirmPassword: new FormControl(null,{validators: Validators.compose([Validators.required, Validators.maxLength(50), Validators.minLength(8), CustomValidation.PasswordRule]),updateOn: 'blur'})
    },{ validators: Validators.compose([this.confirmEmailValidation(), this.confirmPasswordValidation()]) })
  }

  ngOnInit(): void {
    this.subscriptionMap['chatIconToggle'] = this.utility.hideChatIcon$.subscribe(status => {
      this.ngZone.run(() => {
        this.hideChatIcon = status;
      })
    })
  }

  ngAfterViewInit(){
    this.firstName.nativeElement.focus();
  }

  private confirmEmailValidation(): ValidatorFn {
    return (formGroup: AbstractControl): ValidationErrors | null => {
      let email: string = formGroup.get('Email')?.value;
      let confirmEmail: string = formGroup.get('ConfirmEmail')?.value;
      if (email && confirmEmail && email.toLocaleLowerCase() != confirmEmail.toLocaleLowerCase()) {
        return { confirmEmailNotMatching: true }
      }
      return null;
    }
  }
  private confirmPasswordValidation(): ValidatorFn {
    return (formGroup: AbstractControl): ValidationErrors | null => {
      let password = formGroup.get('Password')?.value;
      let confirmPassword = formGroup.get('ConfirmPassword')?.value;
      if (password && confirmPassword && password != confirmPassword) {
        return { confirmPasswordNotMatching: true }
      }
      return null;
    }
  }

  gotoChat() {
    if (this.hideChatIcon) {
      this.router.navigate(['/web-chat']);
    } else {
      this.router.navigate(['/web-chat/2']);
    }
  }
  

  emailToUsername() {

    if (!this.registerForm.controls.Email.invalid) {
      this.registerForm.controls.UserName.setValue(this.registerForm.controls.Email.value);
    }
  }

  public register(): void {
    this.registerSubmitted = true;
    this.errorMessage = null;
    if (this.registerForm.valid) {
      this.registerInProgress = true;
      let endpoint = getApiUrl(apiList.auth.register);
      let payload = this.registerForm.value as RegisterPayload;
      payload.PersonalData = {
        IsGuarantor: false,
        EncString: this.clientToken,
        DOB: null
      }
      this.http.post<ApiResponse>(endpoint, payload).subscribe((response) => {
        if (response.Status == true) {
          this.userService.setRegistrationDetails(payload);
          this.utility.setTempData('creataeccount', 'creataeccount');
          // localStorage.setItem('creataeccount','creataeccount');
          if (this.clientToken)
            this.router.navigate(['/regristation/' + this.clientToken]);
          else
            this.router.navigate(['/regristation/undefined']);
        } else {
          // this.utility.alert.toast({ title: loginResponse.Message, type: 'error' });
          this.errorMessage = response.Message;
        }
        this.registerInProgress = false;
      }, (err: HttpErrorResponse) => {
        console.log(err);
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
        this.registerInProgress = false;
      })
    }
  }
  /*
  author : Nilena Alexander
  desc   : to go back 
  */
  cancel() {
    history.back();
  }
}
