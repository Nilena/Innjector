import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiResponse } from 'src/app/core/models/auth';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-mho-login',
  templateUrl: './mho-login.component.html',
  styleUrls: ['./mho-login.component.css']
})
export class MhoLoginComponent implements OnInit {

  constructor(private router: ActivatedRoute,
    private https: HttpClient,
    private utility: UtilityService) {
  }

  ngOnInit(): void {
    this.utility.saveToLocalStorage(CONSTANTS.APP_CONFIG.FIRST_TIME_LOADING, "true");
    this.router.params.subscribe(params => {
      // this.routeSub = params['id'];
      let data = {
        facility_id: params['facility'],
        type: params['keywords?'],
      }
      this.getGuid(data);
    });
    ///mho-redirect/9776/MHO
  }

  /*
     author : Nilena Alexander
     desc   : to get getGuid Details
     */
  getGuid(data: any) {
    let payload = data;
    let endpoint = getApiUrl(apiList.sso.getFacilityGUID) + '?facilityId=' + data.facility_id;
    this.https.get<ApiResponse>(endpoint).subscribe(data => {
      this.utility.setTempData('Guid', data.Data);
      let redUrl = environment.mhoRedirectionUrl + "?facility_id=" + payload.facility_id + '&type=' + payload.type;
      window.location.replace(redUrl);
    },
      (err: HttpErrorResponse) => {
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      })
  }

}
