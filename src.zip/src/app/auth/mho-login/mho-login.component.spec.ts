import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MhoLoginComponent } from './mho-login.component';

describe('MhoLoginComponent', () => {
  let component: MhoLoginComponent;
  let fixture: ComponentFixture<MhoLoginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MhoLoginComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MhoLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
