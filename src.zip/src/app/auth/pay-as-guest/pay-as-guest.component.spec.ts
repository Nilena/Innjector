import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PayAsGuestComponent } from './pay-as-guest.component';

describe('PayAsGuestComponent', () => {
  let component: PayAsGuestComponent;
  let fixture: ComponentFixture<PayAsGuestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PayAsGuestComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PayAsGuestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
