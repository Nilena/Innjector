import { Component, OnInit, Input, Output, EventEmitter, ElementRef, NgZone, ViewChild, HostListener } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UserService } from '../services/user.service';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { LoginResponse, RegisterPayload, ApiResponse } from 'src/app/core/models/auth';
import { CustomValidation } from 'src/app/shared/utilities/custom-validator';
import { forkJoin } from 'rxjs';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { loginApiUrl } from '../../core/constants/api-list';
import { Subscription } from 'rxjs';
import { REGCONSTANTS } from '../../core/constants/regex-constants';


@Component({
  selector: 'app-pay-as-guest',
  templateUrl: './pay-as-guest.component.html',
  styleUrls: ['./pay-as-guest.component.css']
})
export class PayAsGuestComponent implements OnInit {
  termsAndConditions: string = ""
  accountDetails: boolean = false
  loader: boolean = false
  submitted: boolean = false
  tabOpen: boolean = false
  endpoint: boolean = false
  checkBoxEnable: boolean = false
  loaderHospData: boolean = false
  public guestLogin: FormGroup;
  hospitalList: any = []
  emittedCheckedvalue: boolean = false
  public clientToken: string | null;
  public selectedHospital: string = " ";
  regData: RegisterPayload | null;
  customMsg: any = ''
  errorMessage: string | null = null;
  termsPopup: boolean = false;
  public hideChatIcon: boolean = false;

  private subscriptionMap: { [key: string]: Subscription } = {};

  @ViewChild('person') personTab! : ElementRef; 
  @ViewChild('responsibleparty') responsibleparty! : ElementRef;

  @HostListener('keydown', ['$event'])
  clickarrowx(event: any) {
    if(event.code == 'Enter' || event.key == 'Enter'){
        let X =(document.activeElement?.lastChild?.textContent)
        if(X==='Responsible Party'){
          this.tabOpen = true;
          this.checkBoxEnable = false;
          this.emittedCheckedvalue=false;
        }
    }
  }

  public get controls() {
    return this.guestLogin.controls;
  }

  constructor(private userService: UserService,
    private utility: UtilityService,
    private http: HttpClient,
    private router: Router,
    private elementRef: ElementRef,
    private activatedRoute: ActivatedRoute,
    private userServices: UserService,
    private ngZone: NgZone) {
    this.clientToken = this.activatedRoute.snapshot.paramMap.get('clientToken');
    if ((this.clientToken == 'undefined' || this.clientToken == 'null' || this.clientToken == null)) {
      let value = this.utility.getTempData(CONSTANTS.SESSION.COM_MHO_EMAIL)
      this.clientToken = value?.ClientGuid ? value.ClientGuid : null;
    }
    // if(this.clientToken == null) {
    //   let value = this.utility.getTempData(CONSTANTS.SESSION.COM_MHO_EMAIL)
    //   this.clientToken = value?.ClientGuid ?value.ClientGuid:null;
    // }
    this.regData = this.userServices.getRegistrationDetails();
    if (this.utility.getTempData('creataeccount') && !this.regData) {
      if (this.clientToken)
        this.router.navigate(['/create-account/' + this.clientToken])
      else
        this.router.navigate(['/create-account'])
    }

    this.guestLogin = new FormGroup({
      AccountNo: new FormControl(null, [
        Validators.required,
        CustomValidation.noSpaceOnly,
        // Validators.pattern('[-_a-zA-Z0-9]*'),
        Validators.pattern(REGCONSTANTS.accountNoPattern),
        Validators.minLength(4)
      ]),
      // AccountNo: new FormControl(null, [Validators.required, CustomValidation.noSpaceOnly, Validators.minLength(4)]),

      DOB: new FormControl(null, [Validators.required, CustomValidation.futureDate, CustomValidation.validDate, CustomValidation.noSpaceOnly, CustomValidation.OldDate]),
      EmailId: new FormControl(null),
      EncString: new FormControl(null),
      EncodedData: new FormControl(null),
      ExternalLoginId: new FormControl(null),
      Guid: new FormControl(null, [Validators.required]),
      IsGuarantor: new FormControl(this.tabOpen, [Validators.required]),
      LastFourSSN: new FormControl(null, Validators.compose([Validators.required, CustomValidation.noSpaceOnly, Validators.minLength(4)])),
      MHOUserName: new FormControl(null),
      PersonalData: new FormControl({}),
    })
  }

  ngOnInit(): void {
    this.utility.setTempData(CONSTANTS.APP_CONFIG.login_config, JSON.stringify({ guid: "/" + this.clientToken, token: null, unique: "1" }));
    this.subscriptionMap['chatIconToggle'] = this.utility.hideChatIcon$.subscribe(status => {
      this.ngZone.run(() => {
        this.hideChatIcon = status;
      })
    })
    this.GetAllApiDetails();
  }

  ngAfterViewInit(){
    this.personTab.nativeElement.focus();
  }

  /*
    author : Nilena Alexander
    desc   : to get all data from intial ai calls
    */
  GetAllApiDetails() {
    // this.utility.loader.next(true);
    this.loaderHospData = true;
    let payload = { "EncString": "clinic" };
    let endpoint = getApiUrl(apiList.auth.TermsAndConditon);
    let endpoint1 = getApiUrl(apiList.auth.getCustomMessageByName) + 'messageKey=AccountNoLeadZero';
    let peopleId = this.utility.getTempData(CONSTANTS.SESSION.SSO_EMAIL_PPLID);
    let endpoint2: any;
    if (this.utility.getTempData(CONSTANTS.SESSION.SSO_LOGIN)) {
      let mhoCookie = this.utility.getTempData(CONSTANTS.SESSION.SSO_LOGIN);

      if (mhoCookie)
        endpoint2 = getApiUrl(apiList.auth.loadMhoHospital) + peopleId;

    }
    else {
      peopleId = peopleId ? peopleId : 0;
      endpoint2 = getApiUrl(apiList.auth.loadHospital) + peopleId;
    }


    forkJoin([
      this.http.post<ApiResponse>(endpoint, payload), this.http.get<ApiResponse>(endpoint1), this.http.get<ApiResponse>(endpoint2)
    ]).subscribe((response: any[]) => {
      this.termsAndConditions = response[0].Data;
      this.getCustomMessage(response[1]);
      this.loaderHospData = true;
      this.loadHospitalList(response[2]);

      // this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      this.loaderHospData = false;
      console.log(err)
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }
  gotoChat() {
    if (this.hideChatIcon) {
      this.router.navigate(['/web-chat']);
    } else {
      this.router.navigate(['/web-chat/2']);
    }
  }
  /*
author : Nilena Alexander
desc   : to bind hospital data
params :
*/
  selectedHospitalData(event: any) {
    if (event) {
      let found = this.hospitalList?.Data.find((el: any) => el.ClientCode == event)
      if (found) {
        this.selectedHospital = found.ClientCode;
        this.guestLogin.patchValue({ "Guid": found.Guid });
      }
    }

  }
  /*
	author : Nilena Alexander
	desc   : to get custom messages
  */
  getCustomMessage(data: any) {
    if (data.Status == true) {
      this.customMsg = data.Data;
      this.utility.loader.next(false);
    } else {
      this.utility.loader.next(false);
      this.utility.alert.toast({ title: data.Message, type: 'error' });
    }
  }
  /*
author : Nilena Alexander
desc   : tocheck aagree or not 
*/
  checkEnable() {
    // this.emittedCheckedvalue = this.emittedCheckedvalue;
    // this.checkBoxEnable = true
    this.emittedCheckedvalue = false;
    this.termsPopup = true;
  }


  checkValue(event: boolean) {
    if (event == true) {
      this.emittedCheckedvalue = true;
      this.checkBoxEnable = true
    } else {
      this.emittedCheckedvalue = false
      this.checkBoxEnable = false
    }
    this.termsPopup = false;
  }
  /*
	author : Nilena Alexander
	desc   : to list hospital list
	params :
  */
  loadHospitalList(data: any) {
    if (data.Status == true) {
      this.hospitalList = data;
      this.loaderHospData = false;
    } else {
      this.utility.alert.toast({ title: data.Message, type: 'error' });
      this.loaderHospData = false;
    }
  }
  /*
	author : Nilena Alexander
	desc   : to take checkbox data
	params :
  */
  checkBoxChanges() {
    if (this.checkBoxEnable) {
      this.emittedCheckedvalue = false;
      this.termsPopup = true;
    }
    else
    this.emittedCheckedvalue = false;
  }

  private gtmLog(title: string, category: string) {
    let data: any = {};
    let user = this.userService.getUserInfo();
    data.event_title = title;
    data.data_object = {
      login_type: "guest"
    }
    data.event_interactive = true;
    data.event_logged_in = user ? true : false;
    data.event_category = category;
    data.event_registration_type = user ? (user.IsGuest ? 'guest' : user.FromMHO ? 'mho' : 'epay') : null;
    data.event_facility = user ? user.ClientCode : null;
    data.event_user_id = user ? user.UserID : null;
    data.event_user_type = user ? 'patient' : null;
    data.event_success = true;
    data.event_session_id = user ? user.RequestToken : null;
    this.utility.googleTrack(data);
  }

  /*
	author : Nilena Alexander
	desc   : to submit email
	params :
  */
  public submit(): void {
    this.submitted = true;
    this.errorMessage = null;
    if (this.clientToken) {
      this.guestLogin.controls['Guid'].clearValidators();
      this.guestLogin.controls['Guid'].setErrors(null);
    }
    if (this.emittedCheckedvalue && this.guestLogin.valid) {
      this.gtmLog('Log In Start', 'Log In');
      this.loader = true;
      let endpoint = getApiUrl(apiList.auth.userRegistration);
      this.guestLogin.patchValue({ "IsGuarantor": this.tabOpen });

      let payload = this.guestLogin.value;
      if (this.clientToken) {
        payload['EncString'] = this.clientToken;
        payload['Guid'] = this.clientToken;
      }
      else
        payload['EncString'] = this.guestLogin.value.Guid;
      if (this.regData) {
        let newPayload = this.regData;
        newPayload.Guid = this.guestLogin.value.Guid;
        newPayload.PersonalData.AccountNo = this.guestLogin.value.AccountNo;
        newPayload.PersonalData.DOB = this.guestLogin.value.DOB;
        newPayload.PersonalData.LastFourSSN = this.guestLogin.value.LastFourSSN;
        newPayload.PersonalData.IsGuarantor = (this.guestLogin.value.IsGuarantor).toString();
        newPayload.PersonalData.EncString = this.guestLogin.value.Guid;

        this.http.post<LoginResponse>(endpoint, newPayload).subscribe((data) => {
          if (data.Status == true) {
            this.userService.setUserInfo(data.Data);
            this.router.navigate(['/resend-email']);
          } else {
            this.errorMessage = data.Message;
          }
          this.loader = false;
        }, (err: HttpErrorResponse) => {
          console.log(err);
          this.loader = false
          this.submitted = false
          this.errorMessage = err?.error?.message;
          this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
        })
      } else {
        let value = this.utility.getTempData(CONSTANTS.SESSION.COM_MHO_EMAIL)
        payload['EmailId'] = value?.mhoEmail ? value.mhoEmail : null;
        payload['MHOUserName'] = value?.mhoUsername ? value.mhoUsername : null;
        payload['ExternalLoginId'] = value?.ExternalLoginId ? value.ExternalLoginId : null;

        let endpoint = loginApiUrl(apiList.auth.guestLogin);
        this.http.post<LoginResponse>(endpoint, payload).subscribe((data) => {
          if (data.Status == true) {
            this.userService.setUserInfo(data.Data);
            this.gtmLog('Log In Completed', 'Log In');
            this.router.navigate(['/dashboard']);
          } else {
            this.errorMessage = data.Message;
          }
          this.loader = false;
        }, (err: HttpErrorResponse) => {
          console.log(err);
          this.submitted = false;
          this.loader = false;
          this.errorMessage = err?.error?.message;
          this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
        })
      }

    }
    // else {
    //  endpoint = null;
    // }
  }

  ngOnDestroy() {
    this.utility.setTempData('creataeccount', null);
  }
}
