import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { forkJoin } from 'rxjs';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { UtilityService } from 'src/app/shared/services/utility.service';

@Component({
  selector: 'app-ach-confirmation',
  templateUrl: './ach-confirmation.component.html',
  styleUrls: ['./ach-confirmation.component.css']
})
export class AchConfirmationComponent implements OnInit {

  public key: any;
  public planStatus: any;
  public custom_message: string = '';
  public reason: string = '';
  public showAgree: boolean = false;
  public achKey: string | null = '';
  public showSuccess: boolean = false;
  public showError: boolean = false;
  public loadingInProgress: boolean = false;

  constructor(
    private utility: UtilityService,
    private http: HttpClient,
    private activatedRoute: ActivatedRoute,
    private router: Router
  ) {
    this.achKey = this.activatedRoute.snapshot.paramMap.get('achKey');
    try {
      let achKey = atob(this.achKey as  string);
      this.achKey = btoa(achKey)
    } catch{
      console.log('InvalidToken')
    }
  }

  ngOnInit(): void {
    this.init();
  }

  gotoLogin() {
    this.router.navigate(['/email-login/' + this.achKey])
  }
  public agree() {

    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.auth.achActivationAgree + '?encodedData=' + this.achKey);
    // let payload = {encodedData : this.achKey}
    this.http.post<any>(endpoint, null).subscribe((response) => {
      if (response.Status) {
        this.showSuccess = true;
      } else {
        // this.reason = response.Message
        this.showError = true;
        this.utility.alert.toast({ title: response.Message, type: 'error' });
      }
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.utility.loader.next(false);
    })
  };

  public getCustomMessage() {
    let guidAN = this.utility.getTempData('guid');
    let key = {
      EncString: guidAN,
      key: this.key
    };
    this.getResoureData();
  }

  getResoureData() {
    //this.fetchingInProgress = true;
    this.utility.loader.next(true);
    this.loadingInProgress = true;
    let endpoint2 = getApiUrl(apiList.common.planStatus);
    let endpoint = getApiUrl(apiList.common.getCustomMessage + this.key);
    forkJoin([
      this.http.post<any>(endpoint2, { Mode: 'S', encodedData: this.achKey }),
      this.http.get<any>(endpoint)
    ]).subscribe((response) => {
      if (response[1].Data) {
        this.custom_message = response[1].Data;
        for (let i = 0; i < response[1].Data.length; i++) {
          if (response[1].Data[i].Key == "msg_Plan_Activation_Not_Allowed") {
            this.custom_message = response[1].Data[i].Value;
          }
        }
      } else {
        this.utility.alert.toast({ title: response[1].Message, type: 'error' });
      }
      if (response[0].Status) {
        this.planStatus = response[0].Data;
        if (this.planStatus) {
          this.planStatus = this.planStatus.planStatus;
          this.reason = this.planStatus.reason || '';
          let sn = this.reason.split(',');
          if (this.planStatus == 'S' && sn.length > 1) {
            for (let i = 0; i < sn.length; i++) {
              if ((sn[i] == 'PPV') || (sn[i] == 'PPR') || (sn[i] == 'PPREV')) {
                this.showError = true;
                break;
              } else {
                // this.showAgree = true;
                this.showError = false;
              }
            }
          } else {
            if (this.planStatus == 'S' && this.reason != 'PSU' && this.reason != 'IPRF' && this.reason != 'PPV' && this.reason != 'PPR' && this.reason != 'PPREV') {
              // this.showAgree = true;
              this.showError = false;
            } else {
              // this.showAgree = false;
              this.showError = true;
            }
          }
        } else {
          // this.showAgree = false;
          this.showError = true;
        }
      } else {
        this.showError = true;
        this.utility.alert.toast({ title: response[0].Message, type: 'error' });
      }
      this.loadingInProgress = false;
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.utility.loader.next(false);
      this.loadingInProgress = false;
    })
  }

  public init() {
    this.key = 26;
    this.getCustomMessage();
  }

}
