import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AchConfirmationComponent } from './ach-confirmation.component';

describe('AchConfirmationComponent', () => {
  let component: AchConfirmationComponent;
  let fixture: ComponentFixture<AchConfirmationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AchConfirmationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AchConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
