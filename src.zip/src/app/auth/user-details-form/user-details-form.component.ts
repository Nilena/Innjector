import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-details-form',
  templateUrl: './user-details-form.component.html',
  styleUrls: ['./user-details-form.component.css']
})
export class UserDetailsFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
