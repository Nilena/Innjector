import { Component, OnDestroy, OnInit, Renderer2 } from '@angular/core';
import { Router } from '@angular/router';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { UtilityService } from 'src/app/shared/services/utility.service';

@Component({
  selector: 'app-get-started',
  templateUrl: './get-started.component.html',
  styleUrls: ['./get-started.component.css']
})
export class GetStartedComponent implements OnInit, OnDestroy {

  constructor(
    private renderer: Renderer2,
    private utility: UtilityService,
    private router: Router
  ) {
    if (!this.utility.isFirstTimeLoading()) {
      this.router.navigate(['/user-login']);
    }
    this.utility.saveToLocalStorage(CONSTANTS.APP_CONFIG.FIRST_TIME_LOADING, "true");
  }

  ngOnInit(): void {
    this.renderer.addClass(document.body, 'body-bg');
  }

  ngOnDestroy(): void {
    this.renderer.removeClass(document.body, 'body-bg');
  }

}
