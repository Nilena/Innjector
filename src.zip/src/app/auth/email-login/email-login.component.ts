import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { forkJoin } from 'rxjs';
import { getApiUrl, apiList } from 'src/app/core/constants/api-list';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { ApiResponse, LoginResponse, Profile } from 'src/app/core/models/auth';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { UserService } from '../services/user.service';
import { CustomValidation } from 'src/app/shared/utilities/custom-validator';
import { CookieService } from 'ngx-cookie-service';
import { loginApiUrl } from '../../core/constants/api-list';
import { environment } from 'src/environments/environment';


@Component({
  selector: 'app-email-login',
  templateUrl: './email-login.component.html',
  styleUrls: ['./email-login.component.css']
})
export class EmailLoginComponent implements OnInit {
  public loginForm: FormGroup;
  public guestForm: FormGroup;
  public loginInProgress: boolean = false;
  public loginSubmitted: boolean = false;
  public guestLoginInProgress: boolean = false;
  public guestLoginSubmitted: boolean = false;
  public showPassword: boolean = false;
  public get controls() { return this.loginForm.controls };
  public get guestControls() { return this.guestForm.controls };
  // public clientToken: string | null;
  public errorMessage: string | null = null;
  public guestErrorMessage: string | null = null;

  userDetails: Profile | null = null;

  isMho: any;
  emailKey: any;
  guid: any = '';
  payload: any;
  userDetailsResponse: any;

  constructor(
    private userService: UserService,
    private utility: UtilityService,
    private http: HttpClient,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private cookieService: CookieService
  ) {
    this.userService.removeSession(false);
    this.emailKey = this.activatedRoute.snapshot.paramMap.get('clientToken');
    try {
      let emailKey = atob(this.emailKey as string);
      this.emailKey = btoa(emailKey)
    } catch{
      console.log('InvalidToken')
    }
    this.utility.setTempData('emailKey', this.emailKey);
    this.loginForm = new FormGroup({
      username: new FormControl(null, Validators.compose([Validators.required])),
      password: new FormControl(null, Validators.compose([Validators.required]))//, Validators.maxLength(50), Validators.minLength(6)
    })
    this.guestForm = new FormGroup({
      // LastFourSSN: new FormControl(null, Validators.compose([Validators.required, CustomValidation.noSpaceOnly, Validators.minLength(4)])),
      // ssn: new FormControl(null, Validators.compose([Validators.required])),
      ssn: new FormControl(null, Validators.compose([Validators.required, CustomValidation.noSpaceOnly, Validators.minLength(4)])),
      DateOfBirth: new FormControl(null, [Validators.required, CustomValidation.futureDate, CustomValidation.validDate, CustomValidation.noSpaceOnly, CustomValidation.OldDate]),
      // DateOfBirth: new FormControl(null, Validators.compose([Validators.required]))//, Validators.maxLength(50), Validators.minLength(6)
      // DOB: new FormControl(null, [Validators.required, CustomValidation.futureDate, CustomValidation.validDate, CustomValidation.noSpaceOnly]),
    })
  }

  ngOnInit(): void {
    this.utility.saveToLocalStorage(CONSTANTS.APP_CONFIG.FIRST_TIME_LOADING, "true");
    this.init();
  }

  public init() {
    this.utility.loader.next(true);
    let endpoint = getApiUrl(`${apiList.auth.getGUID}?encodedData=${this.emailKey}`);
    forkJoin([
      this.http.get<ApiResponse>(endpoint),
      this.http.get<ApiResponse>(getApiUrl(`${apiList.auth.getPeaopleId}?encodedData=${this.emailKey}`))
    ]).subscribe((data) => {
      if (data[0].Status == true) {
        this.guid = data[0].Data;
      } else {
        this.utility.alert.toast({ title: data[0].Message, type: 'error' });
      }
      if (data[1].Status == true) {
        this.isMho = data[1].Data.isMHO;
        this.utility.setTempData(CONSTANTS.SESSION.SSO_EMAIL_PPLID, data[1].Data.peopleId)
      } else {
        this.utility.alert.toast({ title: data[1].Message, type: 'error' });
      }
      this.userService.removeSession(true);
      this.utility.setTempData('emailKey', this.emailKey);
      this.utility.setTempData(CONSTANTS.APP_CONFIG.login_config, { facilityid: this.guid && this.guid, guid: "/" + this.guid, token: "/" + this.emailKey, eLogin: 1, unique: "1" })
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      //this.loader = false;
      this.utility.loader.next(false);
    })
  }

  getGuestPayload(title: string, category: string) {
    let data = {
      event_title: title,
      event_category: category,
      data_object: { login_type: "email" },

      event_interactive: true,
      event_logged_in: this.userDetailsResponse ? true : false,
      event_registration_type: this.userDetailsResponse ? 'guest' : null,
      event_facility: this.userDetailsResponse ? this.userDetailsResponse.re : null,
      event_user_id: this.userDetailsResponse ? this.userDetailsResponse.UserID : null,
      event_user_type: this.userDetailsResponse ? 'patient' : null,
      event_success: true,
      event_session_id: this.userDetailsResponse ? this.userDetailsResponse.RequestToken : null,
    }
    this.utility.googleTrack(data);
  }
  getLoginPayload(title: string, category: string) {
    let data = {
      event_title: title,
      event_category: category,
      data_object: { login_type: "email" },

      event_interactive: true,
      event_logged_in: this.userDetailsResponse ? true : false,
      event_registration_type: this.userDetailsResponse ? (this.userDetailsResponse.FromMHO ? 'mho' : 'epay') : null,
      event_facility: this.userDetailsResponse ? this.userDetailsResponse.ClientCode : null,
      event_user_id: this.userDetailsResponse ? this.userDetailsResponse.UserID : null,
      event_user_type: this.userDetailsResponse ? 'patient' : null,
      event_success: true,
      event_session_id: this.userDetailsResponse ? this.userDetailsResponse.RequestToken : null,
    }
    this.utility.googleTrack(data);
  }

  public guestLogin(): void {
    this.guestLoginSubmitted = true;
    this.guestErrorMessage = null;
    if (this.guestForm.valid) {
      this.guestLoginInProgress = true;
      this.getGuestPayload('Log In Start', 'Log In');
      this.utility.setTempData(CONSTANTS.SESSION.SHOW_RMEX_POP, 'T');
      let endpoint = loginApiUrl(apiList.auth.emailGuestLogin);
      let payload = this.guestForm.value;
      payload['EncodedData'] = this.emailKey;
      this.http.post<LoginResponse>(endpoint, payload).subscribe((loginResponse) => {
        if (loginResponse.Status == true) {
          this.userDetailsResponse = loginResponse.Data;
          this.getGuestPayload('Log In Completed', 'Log In');
          // this.checkIsactive(loginResponse);
          if (!loginResponse.Data.Locked) {
            this.saveToCookies(loginResponse.Data);
          }
          else if (loginResponse.Message)
            this.guestErrorMessage = loginResponse.Message;
        } else {
          // this.utility.alert.toast({ title: loginResponse.Message, type: 'error' });
          this.guestErrorMessage = loginResponse.Message;
        }
        this.guestLoginInProgress = false;
      }, (err: HttpErrorResponse) => {
        console.log(err);
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
        this.guestLoginInProgress = false;
      })
    }
  }

  public login(): void {
    this.loginSubmitted = true;
    this.errorMessage = null;
    if (this.loginForm.valid) {
      this.loginInProgress = true;
      this.getLoginPayload('Log In Start', 'Log In');
      let endpoint = loginApiUrl(apiList.auth.emailLogin);
      let payload = this.loginForm.value;
      payload['EncodedData'] = this.emailKey;
      this.http.post<LoginResponse>(endpoint, payload).subscribe((loginResponse) => {
        if (loginResponse.Status == true) {
          this.userDetailsResponse = loginResponse.Data;
          this.getLoginPayload('Log In Completed', 'Log In');
          this.checkIsactive(loginResponse);
        } else {
          // this.utility.alert.toast({ title: loginResponse.Message, type: 'error' });
          this.errorMessage = loginResponse.Message;
        }
        this.loginInProgress = false;
      }, (err: HttpErrorResponse) => {
        console.log(err);
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
        this.loginInProgress = false;
      })
    }
  }

  private checkIsactive(result: any) {
    if (result.Status && !result.Data.Locked && result.Data.IsActive) {
      this.saveToCookies(result.Data);
    }
    else if (result.Status && !result.Data.Locked && result.Data.IsActive == false) {
      this.userService.setUserInfo(result.Data);
    }
    else
      this.errorMessage = result.Message;
  }

  private saveToCookies(data: any) {
    if (data) {
      // common.googleTrack(data);
      this.userService.setUserInfo(data);
      // $rootScope.$broadcast(CONSTANTS.EVENTS.HEADER.SSO_LOGIN_SUCCESS, { isLoggedIn: false });
      this.utility.setTempData(CONSTANTS.SESSION.SHOW_RMEX_POP, 'T');
      this.navigation(data)

    } else {
      this.userService.removeSession(true);
    }
  };
  private navigation(o: any) {
    let navPath = this.navigationPath(o.LogSourceDetails);
    this.router.navigate([navPath]);
    // $timeout(function () { $location.path(navPath) }, 1000);
  }
  private navigationPath(sourceDetails: any) {
    let result = sourceDetails.SourceData ? JSON.parse(sourceDetails.SourceData) : null;
    switch (sourceDetails.ActionName) {
      case "SendReceipt":
      case "PaymentPlanReceipttemplate": {
        let keyData = { PaymentTransactionId: result && result[0] && result[0].RefID }
        return '/payment-history' + sourceDetails.NextUrl + "/" + btoa(JSON.stringify(keyData));
      }
      case "PaymentPlanACHConfirmation":
      case "PaymentPlanEnrollment":
      case "PaymentMethodUpdatetemplate":
      case "PlanCompleted":
      case "PaymentPlanWithdrawtemplate":
      case "PaymentPlanUpdatetemplate":
      case "PlanScheduledPaymentSuccesstemplate":
      case "PlanScheduledPaymentDuetemplate":
      case "PaymentPlanCompleted":
      case "PaymentPlanEnrollmentResend":
      case "PaymentPlanFollowtemplate":
      case "MultipleInstallmentDue":
      case "CreditCardExpiry":
      case "PaymentPlanCompletionZeroBalance": {
        let keyData = result && result[0] && result[0].RefID
        return '/dashboard' + sourceDetails.NextUrl + "/" + btoa(JSON.stringify(keyData));
      }
      case "PPlanRedistribution": {
        let keyData = result && result[0] && result[0].RefID
        return sourceDetails.NextUrl;
      }
    }
  };
  public loginWithMho() {
    let reg_type = 'mho';
    this.getLoginPayload('Log In Start', 'Log In');
    this.utility.setTempData(CONSTANTS.SESSION.SSO_EMAIL_NAV, this.emailKey);
    if (document.referrer) {
      this.utility.setTempData(CONSTANTS.SESSION.SPLASH_REFERROR, document.referrer);
    }
    this.utility.setTempData(CONSTANTS.APP_CONFIG.login_config, JSON.stringify({ guid: '/null', token: "/" + this.emailKey, eLogin: 1, unique: "1" }));
    // let mhoData = this.utility.parseJSON(this.cookieService.get('sso_data'));
    // if (mhoData) {
    //   this.guid = this.guid ? this.guid : this.cookieService.get('data_sso_guid');
    //   window.location.href = "Home/mhoCheck?facility_id=" + this.guid + '&type=' + reg_type;
    // }

    this.mhoLogin();
    this.getLoginPayload('Log In Completed', 'Log In');
  }
  mhoLogin() {
    let url = environment.mhoDomain;
    window.location.replace(url);
  }
  // public gtmObjectCommon(title: any, category: any) {
  //   let data: any = {};
  //   data.event_title = title;
  //   data.event_category = category;
  //   data.data_object =  { login_type: "email" };
  //   this.gtmLog(data);
  // }
  // private gtmLog(data: any) {
  //   data.event_interactive = true;
  //   data.event_logged_in = this.userDetails ? true : false;
  //   data.event_registration_type = this.userDetails ? 'guest' : null;
  //   data.event_facility = this.userDetails ? this.userDetails.ClientCode : null;
  //   data.event_user_id = this.userDetails ? this.userDetails.UserID : null;
  //   data.event_user_type =this.userDetails ? 'patient' : null;
  //   data.event_success = true;
  //   data.event_session_id = this.userDetails ? this.userDetails.RequestToken : null;
  //   this.utility.googleTrack(data);
  // }
}
