import { Component, OnInit, NgZone, OnDestroy } from '@angular/core';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { ApiResponse } from 'src/app/core/models/auth';
import { CookieService } from 'ngx-cookie-service';
import { UserService } from '../services/user.service';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { loginApiUrl } from '../../core/constants/api-list';

@Component({
  selector: 'app-second-redirect-hit',
  templateUrl: './second-redirect-hit.component.html',
  styleUrls: ['./second-redirect-hit.component.css']
})
export class SecondRedirectHitComponent implements OnInit, OnDestroy {
  routeSub: any = {};
  encodedString: string | null = null;
  GuidFromCookie: string | null = null;
  mhOne: any = [];

  constructor(private utility: UtilityService,
    private actRouter: ActivatedRoute,
    private https: HttpClient,
    private cookieService: CookieService,
    private router: Router,
    private userService: UserService,
    private ngZone: NgZone) {
  }
  

  ngOnInit(): void {
    this.utility.ssoLoader.next(true);
    this.actRouter.params.subscribe(params => {
      this.routeSub = params['clientKey?'];
    });
    // for test code

    // this.cookieService.set('data_sso_guid', '85B50973-2E58-4837-8A2D-FB7DBD0B7B3B');

    // original code

    if (this.cookieService.get('sso_guid')) {
      this.GuidFromCookie = this.cookieService.get('sso_guid');
      this.utility.setTempData('Guid', this.GuidFromCookie);
    }

    if (this.cookieService.get('sso_email_nav')) {
      this.encodedString = this.cookieService.get('sso_email_nav');
    }
    this.intialData();

  }

  intialData() {
    this.routeSub = (this.routeSub && (this.routeSub != 'undefined') && (this.routeSub != 'null')) ? this.routeSub : this.GuidFromCookie;
    this.utility.setTempData('Guid', this.routeSub);
    var data: any = {};
    data.ExternalLoginId = null;
    data.EncodedData = this.encodedString ? this.utility.deepCopy(this.encodedString) : null;
    data.MHOUserName = null;
    if (this.routeSub == 'null' || this.routeSub == 'undefined') {
      data.ClientGuid = null;
    } else {
      data.ClientGuid = this.routeSub;
    }
    this.ssoLoginAuthentication(data)


  }

  /**
  * @desc  : navigate to email login
  * @author: Nilena Alexander
  */
  emailNavigation(o: any) {
    let navPath = this.navigationPath(o.LogSourceDetails);
    this.router.navigate([navPath]);
  };
  navigation(path: any) {
    path.LogSourceDetails ? this.emailNavigation(path) : this.regNavigation(path);
  }

  /**
   * @desc  : navigate to guest mhOne page
   * @author: Nilena Alexander
  */
  regNavigation(path: any) {
    let routeSub = this.routeSub ? this.routeSub : "";
    let endpoint = getApiUrl(apiList.sso.GUIDValid) + '?guid=' + routeSub;
    this.https.get<ApiResponse>(endpoint).subscribe(response => {
      if (response.Data) {
        if (path == "guest") {
          this.router.navigate(['/guest-login/' + routeSub]);
        } else {
          this.router.navigate(['/dashboard']);
        }
      } else if (path.UserID && (this.encodedString || this.routeSub)) {
        this.router.navigate(['/dashboard']);
      } else {
        this.router.navigate(['/guest-login']);
      }
    })
  }

  /**
   * @desc  : to get SSo auth Details
   * @author: Nilena Alexander
   */

  ssoLoginAuthentication(data: any) {
    let endpoint = loginApiUrl(apiList.sso.mhoAuth);
    this.https.post<ApiResponse>(endpoint, data).subscribe(response => {
      // let response: any = {
      //   "Data": {
      //     "ExternalLoginId": "",
      //     "ClientGuid": "85B50973-2E58-4837-8A2D-FB7DBD0B7B3B",
      //     "EncodedData": null,
      //     "EmailAddress": "",
      //     "MHOUserName": "",
      //     "LogId": 0
      //   },
      //   "Status": false,
      //   "Message": null,
      //   "IsException": false
      // }

      if (response.Data != null) {
        if (response.Status && response.Data.IsActive && !response.Data.Locked) {
          this.saveToCookies(response.Data);
        }
        else if (!response.Status && !response.IsException && response.Data.ClientGuid != null) {
          let data: any = {};
          data.mhoEmail = response.Data.EmailAddress;
          data.mhoUsername = response.Data.MHOUserName;
          data.ClientGuid = response.Data.ClientGuid;
          (data.ClientGuid) ? (this.routeSub = response.Data.ClientGuid) : (this.routeSub = null);
          if (this.routeSub)
            this.utility.setTempData('Guid', this.routeSub);

          data.EncodedData = response.Data.EncodedData;
          data.ExternalLoginId = response.Data.ExternalLoginId;
          this.utility.setTempData(CONSTANTS.SESSION.COM_MHO_EMAIL, data);
          this.navigation('guest');
        }
        else if ((!response.Status && response.Data == 0) || (!response.IsException && response.Data == 1)) {
          this.navigation('guest');
        }
        else if (response.Data.Locked) {
          this.utility.setTempData(CONSTANTS.SESSION.MHO_BLOCK_MSG, response.Message);
          this.navigation('guest');
        }
        else if (!response.Status && (response.Data == 2 || response.Data == 3)) {
          this.utility.setTempData(CONSTANTS.SESSION.MHO_BLOCK_MSG, response.Message);
          this.logoutUser();
        }
        else {
          (response.IsException ? this.utility.alert.toast({ title: response.Message, type: 'error' })
            : this.bindMessage(response));
        }
      } else {
        this.navigation('guest');
      }
    },
      (err: HttpErrorResponse) => {
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      })
  }
  /**
   * @desc  : response extractor
   * @author: Nilena Alexander
   */
  mhoResponseExtrator(mhOne: any) {
    // let x = $cookies.getObject(CONSTANTS.SESSION.USER_DATA);
    if (this.mhOne.length > 1) {
      this.mhOne.forEach((value: any) => {
        if (value.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier") {
          this.mhOne.mhomhOneToken = value.Value;
        }
        if (value.Type && value.Type.toUpperCase() == "EMAILADDRESS") {
          this.mhOne.mhoEmail = value.Value;
        }
        if (value.Type && value.Type.toUpperCase() == "USERNAME") {
          this.mhOne.mhoUsername = value.Value;
        }
        let data: any = {};
        data.mhoEmail = this.mhOne.mhoEmail;
        data.mhoUsername = this.mhOne.mhoUsername;
        this.utility.setTempData(CONSTANTS.SESSION.COM_MHO_EMAIL, data);
      });

      let data: any = {};
      data.ExternalLoginId = this.mhOne.mhomhOneToken ? this.mhOne.mhomhOneToken : null;
      data.EncodedData = this.encodedString ? this.utility.deepCopy(this.encodedString) : '';
      data.MHOUserName = this.mhOne.mhoUsername ? this.mhOne.mhoUsername : '';
      if (this.routeSub == 'null' || this.routeSub == 'undefined') {
        data.ClientGuid = "";
      } else {
        data.ClientGuid = this.routeSub;
      }
      this.utility.setTempData(CONSTANTS.SESSION.SSO_LOGIN, this.mhOne.mhomhOneToken);
      // $timeout(function () { $rootScope.$broadcast(CONSTANTS.EVENTS.HEADER.SSO_LOGIN_SUCCESS, { isLoggedIn: true }) }, 200);

      this.ssoLoginAuthentication(data);
    }
  }

  /**
   * @desc  : bind message
   * @author: Nilena alexander
  */
  bindMessage(data: any) {
    if (data.Status && !data.Data.IsActive) {
      // this.utility.setTempData(CONSTANTS.SESSION.USER_DATA, data.Data);
      this.utility.alert.toast({ title: data.Message, type: 'success' });
      this.userService.setUserInfo(data.Data);
      let obj: any = {
        Email: data.Data.EmailId
      }
      let val = btoa(JSON.stringify(obj));
      this.router.navigate(['/resend-email/' + this.routeSub + '/' + val])
      //cation.path(CONSTANTS.ROUTE_KEYS._RESEND_EMAIL + angular.fromJson(window.name).guid + "/" + $base64.encode(angular.toJson({ Email: data.Data.EmailId }))) }, 200)) 
    }
    else {
      this.userService.removeSession(true);
      this.utility.alert.toast({ title: data.Message, type: 'error' });
      this.router.navigate(['/user-login'])
    }

  }

  /**
  * @desc  : logout functionlity
  * @author: Nilena Alexander
  */
  logoutUser() {
    let res = this.userService.removeSession(true);
    if (res)
      this.router.navigate(['/user-login']);
  }

  /**
    * @desc  : update header values (profile)- not used in our mbo application copied frm hca
    * @author: Nilena Alexander
  */
  updateHeader() {
    // $rootScope.$broadcast(CONSTANTS.EVENTS.HEADER.UPDATE_USER_INFO);
  };

  /**
* @desc: save token in cookies
* @author:Nilena Alexander
*/
  saveToCookies(data: any) {
    if (data) {
      this.userService.setUserInfo(data);
      // mhOne.updateHeader(),
      this.navigation(data);
    }
    else
      this.userService.removeSession(true);
  };
  /**
   * @desc  : 
   * @author:Nilena Alexander
  */
  private navigationPath(sourceDetails: any) {
    let result = sourceDetails.SourceData ? JSON.parse(sourceDetails.SourceData) : null;
    switch (sourceDetails.ActionName) {
      case "SendReceipt":
      case "PaymentPlanReceipttemplate": {
        let keyData = { PaymentTransactionId: result && result[0] && result[0].RefID }
        return '/payment-history' + sourceDetails.NextUrl + "/" + btoa(JSON.stringify(keyData));
      }
      case "PaymentPlanACHConfirmation":
      case "PaymentPlanEnrollment":
      case "PaymentMethodUpdatetemplate":
      case "PlanCompleted":
      case "PaymentPlanWithdrawtemplate":
      case "PaymentPlanUpdatetemplate":
      case "PlanScheduledPaymentSuccesstemplate":
      case "PlanScheduledPaymentDuetemplate":
      case "PaymentPlanCompleted":
      case "PaymentPlanEnrollmentResend":
      case "PaymentPlanFollowtemplate":
      case "MultipleInstallmentDue":
      case "CreditCardExpiry":
      case "PaymentPlanCompletionZeroBalance": {
        let keyData = result && result[0] && result[0].RefID
        return '/dashboard' + sourceDetails.NextUrl + "/" + btoa(JSON.stringify(keyData));
      }
      case "PPlanRedistribution": {
        let keyData = result && result[0] && result[0].RefID
        return sourceDetails.NextUrl;
      }
    }
  };

  ngOnDestroy(): void {
    this.ngZone.run(() => {
      // throw new Error("Method not implemented.");
      this.utility.resetLoader.next(true);
    })
  }

}
