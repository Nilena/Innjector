import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SecondRedirectHitComponent } from './second-redirect-hit.component';

describe('SecondRedirectHitComponent', () => {
  let component: SecondRedirectHitComponent;
  let fixture: ComponentFixture<SecondRedirectHitComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SecondRedirectHitComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SecondRedirectHitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
