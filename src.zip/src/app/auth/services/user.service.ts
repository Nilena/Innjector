import { Injectable } from '@angular/core';
import { Profile, RegisterPayload } from 'src/app/core/models/auth';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { CookieService } from 'ngx-cookie-service';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { PaymentService } from 'src/app/payment/services/payment.service';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private userProfile: any = null;
  private registrationDetails: RegisterPayload | null = null;

  constructor(
    private utility: UtilityService,
    private http: HttpClient,
    private cookieService: CookieService,
    private paymentService: PaymentService,
    private router: Router
  ) { }
  /*
    author : Arun
    desc   : to get user profile data
  */
  public getUserInfo(reFetch: boolean = false): Profile {
    if (reFetch) this.userProfile = null;
    try {
      if (!this.userProfile) {
        let profile = this.utility.getFromLocalStorage('profile');
        this.userProfile = profile ? JSON.parse(profile) : null;
      }
    } catch(err) {
      console.error('Something went wrong with storage!');
    }
    return this.userProfile;
  }
  public refetchUserDetails(callBack?: Function) {
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.auth.updateUserDetails);
    this.http.get<any>(endpoint).subscribe((response) => {
      if (response.Status == true) {
        let userInfo = this.getUserInfo();
        userInfo.UserPaymentDetails.BalanceRequiringAction = response.Data.BalanceRequiringAction;
        userInfo.UserPaymentDetails.ScheduledPayments = response.Data.ScheduledPayments;
        userInfo.UserPaymentDetails.TotalBalance = response.Data.TotalBalance;
        this.setUserInfo(userInfo);
        if (callBack) callBack();
      } else {
        this.utility.alert.toast({ title: response.Message, type: 'error' });
      }
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      // this.fetchingInProgress = false;
      this.utility.loader.next(false);
    })
  }
  /*
    author : Arun
    desc   : to set user profile data
  */
  public setUserInfo(userInfo: Profile) {
    this.userProfile = userInfo;
    this.utility.saveToLocalStorage('profile', JSON.stringify(userInfo));
  }
  /*
  author : Arun
  desc   : to get token for current profile 
  */
  public getAuthToken(): string {
    const profile: Profile = this.getUserInfo();
    return profile ? profile.RequestToken : '';
  }
  /*
  author : Arun
  desc   : to set registration details
  */
  public setRegistrationDetails(value: RegisterPayload) {
    this.registrationDetails = value;
  }
  /*
  author : Arun
  desc   : to string value
  param  : passing req data
*/
  public getRegistrationDetails(): RegisterPayload | null {
    let data = this.utility.deepCopy(this.registrationDetails);
    this.registrationDetails = null;
    return data;
  }

  /*
    author : Nilena Alexander
    desc   :for clear local storage
    param  : passing boolean 'true' as arg to remove localstorage
  */
  public removeSession(removeCookie: boolean) {
    try {
      if (removeCookie) this.cookieService.deleteAll();
      this.userProfile = null;
      this.utility.clearTemp();
      this.paymentService.setSelectedPaymentOption(1);
      localStorage.removeItem('tempData');
      localStorage.removeItem('profile');
    } catch (err) {
      console.error('Something went wrong with storage!');
    }
    return true;
  }
  /*
     author : Nilena Alexander
     desc   : for clear local storage
   */
  logout() {
    try {
      let loginConfig = this.utility.getTempData(CONSTANTS.APP_CONFIG.login_config);
      let encString = this.utility.getTempData('EncString');
      this.utility.saveToLocalStorage(CONSTANTS.APP_CONFIG.FIRST_TIME_LOADING, "true");
      this.removeSession(true);
      if (loginConfig && loginConfig.eLogin == 1) {
        this.router.navigate(['/email-login' + loginConfig.token]);
      } else if (loginConfig && loginConfig.eLogin == 2) {
        this.router.navigate(['/text-login' + loginConfig.token]);
      } else {
        if (encString) {
          this.router.navigate(['/user-login/' + encString]);
        } else {
          this.router.navigate(['/user-login']);
        }
      }
    } catch (err) {
      this.router.navigate(['/user-login']);
    }
  }
  private gtmTrigger() {
    let data: any = {};
    data.event_title = 'Log In Again Click';
    data.event_category = 'Log Out';
    data.data_object = {};
    data.event_interactive = true;
    data.event_logged_in = false;
    data.event_registration_type = null;
    data.event_facility = null;
    data.event_user_id = null;
    data.event_user_type = null;
    data.event_success = true;
    data.event_session_id = null;
    this.utility.googleTrack(data);
  }
}
