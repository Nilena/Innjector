import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpClient, HttpErrorResponse } from '@angular/common/http'
import { UserService } from '../services/user.service';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { ApiResponse, LoginResponse, Profile } from 'src/app/core/models/auth';
import { Observable } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { loginApiUrl } from '../../core/constants/api-list';
import { environment } from 'src/environments/environment';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  @ViewChild('iconplaypause') iconplaypause!: ElementRef;
  @ViewChild('video') video!: ElementRef;
  videoPlay: boolean = false;
  videosection: boolean = true;

  public itemizedBill: any;
  public loginPageCardInfo: any;
  public loginForm: FormGroup;
  public loginInProgress: boolean = false;
  public loginSubmitted: boolean = false;
  public showPassword: boolean = false;
  public get controls() { return this.loginForm.controls };
  public clientToken: string | null;
  public errorMessage: string | null = null;
  reg_type: string = 'mho';
  userDetails: Profile | null = null;
  samlUrl: string = '';
  public inputFocused: boolean = false;
  public encString: string = '';
  @ViewChild('username', { static: true }) private usrname: ElementRef | null = null;

  public login_image_url: string = "";
  public login_video_url: string|null = "";
  public login_video_background_url: string = "";
  public defaultLoginImageUrl = "assets/images/place-holders/login.png";
  public defaultBackgroundUrl = "assets/images/place-holders/login-bg.png";
  // public defaultLoginVideoUrl = "https://demo.loyale.us/HCA/HCA_API/Content/video/MBFPO.mp4";
  public settingsKey = "";
  public showVideoBackgroundUrl : boolean = false;

  constructor(
    private userService: UserService,
    private utility: UtilityService,
    private http: HttpClient,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {
    this.clientToken = this.activatedRoute.snapshot.paramMap.get('clientToken');
    if (this.utility.isFirstTimeLoading() && (this.clientToken == 'undefined' || this.clientToken == 'null' || this.clientToken == null || this.clientToken == "")) {
      this.router.navigate(['/get-started']);
    }
    else if (navigator.cookieEnabled) {
      this.utility.saveToLocalStorage(CONSTANTS.APP_CONFIG.FIRST_TIME_LOADING, "true");
    }
    this.loginForm = new FormGroup({
      username: new FormControl(null, Validators.compose([Validators.required])),
      password: new FormControl(null, Validators.compose([Validators.required]))//, Validators.maxLength(50), Validators.minLength(6)
    })
  }

  ngOnInit(): void {
    this.utility.setTempData('EncString', this.clientToken);
    this.utility.setTempData(CONSTANTS.APP_CONFIG.login_config, null);
    // this.showClientSettingsData();
    this.setFocus();
    
  }
  
  ngAfterViewInit(): void {
    this.showClientSettingsData();  
  }
  setFocus() {
    this.usrname?.nativeElement.focus();
  }

 
  showClientSettingsData(): void {
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.common.getClientSettings);

    if (this.clientToken) {
      this.encString = this.clientToken;
      this.settingsKey = "login_image_url,login_video_url,login_video_background_url,view_recentbill_url,login_page_card_info";
    } else {
      this.encString = "clinic";
      this.settingsKey = "login_video_url,login_video_background_url";
    }
    

    let payload = {
      "EncString": this.encString,
      "SettingsKey": this.settingsKey
    }

    this.http.post<ApiResponse>(endpoint, payload).subscribe((response) => {
      if (response.Status == true) {
        this.loginPageCardInfo = response.Data.filter((item: any) => {
        if (item.Key == 'login_page_card_info')
          return item.Value;
        })

        let itemizedBill = response.Data.filter((item: any) => {
          if (item.Key == 'view_recentbill_url')
            return item.Value;
        })

        if (itemizedBill.length > 0) {
          this.itemizedBill = itemizedBill[0].Value;
        }

        this.loginPageCardInfo = (this.loginPageCardInfo.length) ? this.loginPageCardInfo[0].Value : null;

        // Image and video fetch
        this.login_image_url = (response.Data.find((el: any) => el.Key == 'login_image_url'))?.Value;
        this.login_video_url = (response.Data.find((el: any) => el.Key == 'login_video_url'))?.Value;

        if(!this.login_image_url && !this.login_video_url){
          this.showVideoBackgroundUrl = true;
        }
        if (!this.login_image_url) {
          this.login_image_url = this.defaultLoginImageUrl;
        }
        
        if(this.login_image_url && !this.login_video_url){
          this.login_video_url = null;
        }


      } else {
        this.login_image_url = this.defaultLoginImageUrl;
        this.utility.alert.toast({ title: 'Video failed to load', type: 'error' });
        this.utility.loader.next(false);

      }
      this.utility.loader.next(false);

    }, (err: HttpErrorResponse) => {
      this.utility.loader.next(false);
      this.showVideoBackgroundUrl = true;
      this.login_image_url = this.defaultLoginImageUrl;
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });

    })
  }


  videoplaypause() {
    if (this.videoPlay == false) {
      // console.log("play pause");
      this.video.nativeElement.load();
      this.video.nativeElement.play();
      this.iconplaypause.nativeElement.innerHTML = "pause_circle_outline";
      this.videoPlay = true;
      this.videosection = false;
    }
  }


  public login(): void {
    this.loginSubmitted = true;
    this.errorMessage = null;
    if (this.loginForm.valid) {
      this.gtmObjectCommon('Log In Start', 'Log In');
      this.loginInProgress = true;
      let endpoint = loginApiUrl(apiList.auth.login);
      let payload = this.loginForm.value;
      if (this.clientToken) payload['EncString'] = this.clientToken;
      this.http.post<LoginResponse>(endpoint, payload).subscribe((loginResponse) => {
        if (loginResponse.Status == true) {
          this.userDetails = loginResponse.Data;
          if (loginResponse.Status && !loginResponse.Data.IsActive) {
            this.router.navigate(['resend/' + this.clientToken + '/'])
            let obj: any = {
              Email: loginResponse.Data.EmailId
            }
            let val = btoa(JSON.stringify(obj));
            this.userService.setUserInfo(loginResponse.Data);
            this.router.navigate(['/resend-email/' + this.clientToken + '/' + val])
          }
          //   else if (!loginResponse.Data.Locked) {
          //   this.userService.setUserInfo(loginResponse.Data);
          // }
          else if (loginResponse.Message && loginResponse.Data.Locked)
            this.errorMessage = loginResponse.Message;
          else {
            this.userService.setUserInfo(loginResponse.Data);
            this.getSurveyStatus(loginResponse.Data);
            this.gtmObjectCommon('Log In Completed', 'Log In');
            this.router.navigate(['/dashboard']);
          }
        } else {
          // this.utility.alert.toast({ title: loginResponse.Message, type: 'error' });
          this.errorMessage = loginResponse.Message;
        }
        this.loginInProgress = false;
      }, (err: HttpErrorResponse) => {
        console.log(err);
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
        this.loginInProgress = false;
      })
    }
  }
  public gtmObjectCommon(title: any, category: any) {
    let data: any = {};
    data.event_title = title;
    data.event_category = category;
    data.data_object = { login_type: "epay" };
    this.gtmLog(data);
  }
  private gtmLog(data: any) {
    data.event_interactive = true;
    data.event_logged_in = this.userDetails ? true : false;
    data.event_registration_type = this.userDetails ? (this.userDetails.FromMHO ? 'mho' : 'epay') : null;
    data.event_facility = this.userDetails ? this.userDetails.ClientCode : null;
    data.event_user_id = this.userDetails ? this.userDetails.UserID : null;
    data.event_user_type = data.event_title == "Log In Completed" ? 'patient' : null;
    data.event_success = true;
    data.event_session_id = this.userDetails ? this.userDetails.RequestToken : null;
    this.utility.googleTrack(data);
  }

  payAsGuest() {
    if (!this.clientToken)
      this.router.navigate(['/guest-login'])
    else
      this.router.navigate(['/guest-login/' + this.clientToken])
  }
  createAccount() {
    this.gtmObjectCommon('Reg1 - Create Account', 'Register');
    if (!this.clientToken)
      this.router.navigate(['/create-account']);
    else
      this.router.navigate(['/create-account/' + this.clientToken])
  }

  public getSurveyStatus(profile: Profile) {
    let endpoint = getApiUrl(apiList.auth.surveySettings);
    let payload = {
      people_id: profile.PeopleID,
      client_group_code: profile.ClientCode
    }
    this.http.post<ApiResponse>(endpoint, payload).subscribe((response) => {
      if (response.Status == true) {
        let surveyCount, surveyCountSession, responseTime, popupDelay;
        response.Data.forEach((item: any) => {
          if (item.settings_key == "survey_count") {
            surveyCount = item.settings_value
          }
          if (item.settings_key == "survey_session_count") {
            surveyCountSession = item.settings_value
          }
          if (item.settings_key == "survey_respond_time") {
            responseTime = item.settings_value
          }
          if (item.settings_key == "survey_popup_display_delay") {
            popupDelay = item.settings_value
          }
        })
        this.utility.setTempData(CONSTANTS.SESSION.SURVEY_DATA, { surveyCount, surveyCountSession, responseTime, popupDelay, loginMode: 'userLogin' });
      } else {
        // this.utility.alert.toast({ title: loginResponse.Message, type: 'error' });
      }
      this.loginInProgress = false;
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.loginInProgress = false;
    })
  }
  mhoLogin() {
    let url = environment.mhoDomain;
    window.location.replace(url);
  }
}
