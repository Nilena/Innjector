import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { UserService } from '../services/user.service';
import { LoginResponse } from 'src/app/core/models/auth';
import { CustomValidation } from 'src/app/shared/utilities/custom-validator';
import { REGCONSTANTS } from '../../core/constants/regex-constants';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  loader: boolean = false
  submitted: boolean = false
  public forgotPasswrdForm: FormGroup;
  errorMessage: string | null = null
  showSucess: boolean = false
  email: string | null = null
 
  // @ViewChild('username')
  @ViewChild('username') username! : ElementRef;

  public get controls() { return this.forgotPasswrdForm.controls };
  constructor(private userService: UserService,
    private utility: UtilityService,
    private http: HttpClient,
    private router: Router,
    ) {

    // let useName = "^[a-zA-Z0-9._@]+$";
    this.forgotPasswrdForm = new FormGroup({
      Username: new FormControl(null, Validators.compose([Validators.required, Validators.pattern(REGCONSTANTS.userName),CustomValidation.cannotContainSpace])),
      Email: new FormControl(null, Validators.compose([Validators.required, CustomValidation.email])),
    })
  }

  ngOnInit(): void {
  }

  
  /*
	author : Nilena Alexander
	desc   : to setFocus intially
  */
 ngAfterViewInit(){
   this.username.nativeElement.focus();
 }
  // setFocus() {
  //   this.inputField?.nativeElement.focus();
  // }


  /*
	author : Nilena Alexander
	desc   : to submit email
  */
  public submit(): void {
    this.submitted = true;
    this.errorMessage = null;
    if (this.forgotPasswrdForm.valid) {
      this.loader = true;
      let endpoint = getApiUrl(apiList.auth.resetPasswrd);
      let payload = this.forgotPasswrdForm.value;
      if (this.utility.getTempData('PeopleID'))
        payload['PeopleID'] = this.utility.getTempData('PeopleID');
      if (this.utility.getTempData('emailKey'))
        payload['LogID'] = atob(this.utility.getTempData('emailKey'));

      this.http.post<LoginResponse>(endpoint, payload).subscribe((forgotPassword) => {
        if (forgotPassword.Status == true) {
          this.showSucess = true;
          this.email = this.forgotPasswrdForm.value.Email;
        } else {
          this.errorMessage = forgotPassword.Message;
        }
        this.loader = false;
      }, (err: HttpErrorResponse) => {
        console.log(err);
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
        this.loader = false;
      })
    }
  }

  /*
   author : Nilena Alexander
   desc   : to resendemail 
   */
  reSendEmail(): void {
    this.loader = true;
    let endpoint = getApiUrl(apiList.auth.resetPasswrd);
    let payload = this.forgotPasswrdForm.value;
    if (this.utility.getTempData('PeopleID'))
      payload['PeopleID'] = this.utility.getTempData('PeopleID');
    this.http.post<LoginResponse>(endpoint, payload).subscribe((forgotPassword) => {
      if (forgotPassword.Status == true) {
        this.showSucess = true;
        this.email = this.forgotPasswrdForm.value.Email;
        this.utility.alert.toast({ title: forgotPassword.Message, type: 'success' });
      } else {
        this.errorMessage = forgotPassword.Message;
      }
      this.loader = false;
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.loader = false;
    })
  }
  /*
    author : Nilena Alexander
    desc   : to go back 
    */
  cancel() {
    history.back();
  }
}
