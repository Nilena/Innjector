import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { UserService } from '../services/user.service';
import { UtilityService } from '../../shared/services/utility.service';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { getApiUrl, apiList } from '../../core/constants/api-list';
import { ApiResponse } from '../../core/models/auth';
import { CustomValidation } from 'src/app/shared/utilities/custom-validator';


@Component({
  selector: 'app-forgot-username',
  templateUrl: './forgot-username.component.html',
  styleUrls: ['./forgot-username.component.css']
})
export class ForgotUsernameComponent implements OnInit {
  errorMessage: string | null = null
  loader: boolean = false
  submitted: boolean = false
  public forgotUsernameForm: FormGroup;
  endpoint: boolean = false;
  // @ViewChild('chosenSearch', { static: true }) private inputField: ElementRef | null = null;
  @ViewChild('emailid') emailid! : ElementRef;

  showSucess: boolean = false
  email: string | null = null
  public get controls() { return this.forgotUsernameForm.controls };
  constructor(private userService: UserService,
    private utility: UtilityService,
    private http: HttpClient,
    private router: Router) {

    this.forgotUsernameForm = new FormGroup({
      emailId: new FormControl(null, Validators.compose([Validators.required, CustomValidation.email])),
    })
  }

  ngOnInit(): void {
  }

  ngAfterViewInit(){
    this.setFocus();
  }

  /*
	author : Nilena Alexander
	desc   : to setFocus
  */
  setFocus(): void {
    this.emailid.nativeElement.focus();
  }
  /*
	author : Nilena Alexander
	desc   : to submit email and username
  */
  public submit(): void {
    this.submitted = true;
    this.errorMessage = null;

    if (this.forgotUsernameForm.valid) {
      this.loader = true;
      let endpoint = getApiUrl(apiList.auth.forgotUserName) + this.forgotUsernameForm.value.emailId;
      this.http.get<ApiResponse>(endpoint).subscribe((data) => {
        if (data.Status == true) {
          this.showSucess = true;
          this.email = data.Data.Key
        } else {
          this.errorMessage = data.Message;
          this.submitted = false
        }
        this.endpoint = false;
        this.loader = false

      }, (err: HttpErrorResponse) => {
        console.log(err);
        this.endpoint = false;
        this.loader = false
        this.submitted = false
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });

      })
    }
  }

  /*
   author : Nilena Alexander
   desc   : to resendemail 
   */
  reSendEmail() {
    this.loader = true
    let endpoint = getApiUrl(apiList.auth.forgotUserName) + this.forgotUsernameForm.value.emailId;
    this.http.get<ApiResponse>(endpoint).subscribe((data) => {
      if (data.Status == true) {
        this.showSucess = true;
        this.email = data.Data.Key;
        this.utility.alert.toast({ title: data.Message, type: 'success' });
      } else {
        this.errorMessage = data.Message;
        this.submitted = false
      }
      this.endpoint = false;
      this.loader = false

    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.endpoint = false;
      this.loader = false
      this.submitted = false
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }
  /*
  author : Nilena Alexander
  desc   : to go back 
  */
  cancel() {
    history.back();
  }
}
