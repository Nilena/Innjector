import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { ApiResponse, Profile } from 'src/app/core/models/auth';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { CustomValidation } from 'src/app/shared/utilities/custom-validator';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-resend-email',
  templateUrl: './resend-email.component.html',
  styleUrls: ['./resend-email.component.css']
})
export class ResendEmailComponent implements OnInit {

  public payload: Profile | null = null;
  public resendEmailInProgress: boolean = false;
  public changeEmailForm: FormGroup;
  public newEmail: FormControl;
  public newEmailFormSubmitted: boolean = false;
  public emailChangeInProgress: boolean = false;
  public activeView: number = 1;

  constructor(
    private utility: UtilityService,
    private http: HttpClient,
    private userService: UserService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {
    this.newEmail = new FormControl('', Validators.compose([Validators.required, CustomValidation.email]));
    this.changeEmailForm = new FormGroup({
      newEmail: this.newEmail
    })

    this.payload = this.userService.getUserInfo();



  }

  ngOnInit(): void {
    if (this.activatedRoute.snapshot.params.key) {
      try {
        let encEmail = this.activatedRoute.snapshot.params.key;
        let client = this.activatedRoute.snapshot.params.clientKey;
        let emailx = JSON.parse(atob(encEmail));
        let email = emailx.Email;
        (email && this.payload && !this.payload.EmailId) ? (this.payload.EmailId = email) : this.payload?.EmailId;
        // this.payload.EmailId = this.payload.EmailId || email;
        if (this.payload?.EmailId == undefined || this.payload.EmailId == null || this.payload.EmailId == '')
          this.router.navigate(['/user-login']);
      } catch (error) {
        console.log(error)
      }
    }
  }

  public resendEmail() {
    this.resendEmailInProgress = true;
    let endpoint = getApiUrl(apiList.auth.resendEmailVerification);
    this.http.post<any>(endpoint, this.payload).subscribe((response: ApiResponse) => {
      if (response.Status == true) {
        // this.router.navigate(['/regristation/client']);
        this.utility.alert.toast({ title: response.Message, type: 'success' });
      } else {
        this.utility.alert.toast({ title: response.Message, type: 'error' });
      }
      this.resendEmailInProgress = false;
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.resendEmailInProgress = false;
    })
  }

  public saveNewEmail() {
    this.newEmailFormSubmitted = true;
    this.emailChangeInProgress = true;
    let newEmail = this.newEmail.value;
    let endpoint = getApiUrl(apiList.auth.emailChange);
    let payload = {
      "UserID": this.payload?.UserID,
      "ClientGroupID": this.payload?.ClientGroupID,
      "PeopleID": this.payload?.PeopleID,
      "ClientCode": this.payload?.ClientCode,
      "EmailId": newEmail,
      "UserType": this.payload?.UserType
    }
    this.http.post<any>(endpoint, payload).subscribe((response: ApiResponse) => {
      if (response.Status == true) {
        if (this.payload) {
          this.payload.EmailId = newEmail;
          this.userService.setUserInfo(this.payload);
        }
        this.activeView = 1;
        this.utility.alert.toast({ title: 'Email updated successfully', type: 'success' });
      } else {
        this.utility.alert.toast({ title: response.Message, type: 'error' });
      }
      this.emailChangeInProgress = false;
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.emailChangeInProgress = false;
    })
  }
  logoutUser() {
    let res = this.userService.removeSession(true);
    if (res)
      this.router.navigate(['/user-login']);
  }

}
