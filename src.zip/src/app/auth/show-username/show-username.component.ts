import { UtilityService } from 'src/app/shared/services/utility.service';
import { Component, OnInit, ElementRef } from '@angular/core';
import { UserService } from '../services/user.service';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { LoginResponse, ApiResponse } from 'src/app/core/models/auth';
@Component({
  selector: 'app-show-username',
  templateUrl: './show-username.component.html',
  styleUrls: ['./show-username.component.css']
})
export class ShowUsernameComponent implements OnInit {
  clientToken: string | null;
  userName: string | {} = ''
  userNameArray: any
  endpoint: boolean = false
  clientEmail: string = ""
  showMultiple: boolean = false
  constructor(
    private utility: UtilityService,
    private http: HttpClient,
    private router: Router,
    private userService: UserService,
    private activatedRoute: ActivatedRoute) {
    this.clientToken = this.activatedRoute.snapshot.paramMap.get('clientToken');
  }

  ngOnInit(): void {
    if(this.clientToken){
      try {
        this.clientEmail = atob(this.clientToken)
      } catch (err) {
        console.error('Invalid token');
      }
      this.showUname();
    }
  }

  showUname() {
    let endpoint;
    if (this.clientToken) {
      this.utility.loader.next(true);
      endpoint = getApiUrl(apiList.auth.showUsername) + 'emailId=' + this.clientEmail;
      this.http.get<ApiResponse>(endpoint).subscribe((data) => {

        if (data.Status == true) {

          this.userName = data.Data[0].UserName;


          if (data.Data.length > 1) {
            this.showMultiple = true;
            this.userNameArray = data.Data.map((item: any) => {

              return item.UserName;
            })
          }


        }
        else {
          this.utility.alert.toast({ title: data.Message, type: 'error' });
        }
        this.endpoint = false;
        this.utility.loader.next(false);
      }, (err: HttpErrorResponse) => {
        console.log(err);
        // this.utility.alert.toast({ title: err.error.message, type: 'error' });
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
        this.endpoint = false;
        this.utility.loader.next(false);

      })
    }
  }
  login() {
    let res = this.userService.removeSession(true)
    if (res)
      this.router.navigate(['/user-login'])
  }

}
