import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowUsernameComponent } from './show-username.component';

describe('ShowUsernameComponent', () => {
  let component: ShowUsernameComponent;
  let fixture: ComponentFixture<ShowUsernameComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowUsernameComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowUsernameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
