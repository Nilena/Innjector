import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormControl, FormGroup, Validators, ValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { UserService } from '../services/user.service';
import { LoginResponse } from 'src/app/core/models/auth';
import { CustomValidation } from 'src/app/shared/utilities/custom-validator';
import { CONSTANTS } from 'src/app/core/constants/constants';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {


  loader: boolean = false
  submitted: boolean = false
  public forgotPasswrdForm: FormGroup;
  endpoint: boolean = false;
  errorMessage: string | null = null
  @ViewChild('chosenSearch', { static: true }) private inputField: ElementRef | null = null;
  clientToken: string | null;
  showPassword: boolean = false;
  showCPassword: boolean = false;
  showSuccess: boolean = false;
  public hint: string | null = null;

  public get controls() { return this.forgotPasswrdForm.controls };
  constructor(private userService: UserService,
    private utility: UtilityService,
    private http: HttpClient,
    private router: Router,
    private elementRef: ElementRef,
    private activatedRoute: ActivatedRoute) {
    this.clientToken = this.activatedRoute.snapshot.paramMap.get('clientToken');
    try {
      let clientToken = atob(this.clientToken as string);
      this.clientToken = btoa(clientToken)
    } catch{
      console.log('InvalidToken')
    }
    this.hint =CONSTANTS.PASSWORD_HINT.PSWD_HINT;
    this.forgotPasswrdForm= new FormGroup({
      UserName: new FormControl(null, Validators.compose([CustomValidation.noSpaceOnly])),
      Password: new FormControl(null, Validators.compose([Validators.required, CustomValidation.PasswordRule])),
      ConfirmPassword: new FormControl(null, Validators.compose([Validators.required]))
    }, Validators.compose([this.confirmPasswordValidation()])
    )
  }

  private confirmPasswordValidation(): ValidatorFn {
    return (formGroup: AbstractControl): ValidationErrors | null => {
      let password = formGroup.get('Password')?.value;
      let confirmPassword = formGroup.get('ConfirmPassword')?.value;
      if (password && confirmPassword && password != confirmPassword) {
        return { confirmPasswordNotMatching: true }
      }
      return null;
    }
  }




  ngOnInit(): void {
  }
  /*
	author : Nilena Alexander
	desc   : to setFocus intially
	params :
  */
  setFocus() {
    this.inputField?.nativeElement.focus();
  }
  /*
	author : Nilena Alexander
	desc   : to submit email
	params :
  */
  public submit(): void {
    this.submitted = true;
    this.errorMessage = null;
    if (this.forgotPasswrdForm.valid) {
      this.loader = true;
      let endpoint = getApiUrl(apiList.auth.resetPasswrdFromMail);
      let payload: any = {}
      if (this.clientToken) {
        payload.ConfirmPassword = this.forgotPasswrdForm.value.ConfirmPassword;
        payload.NewPassword = this.forgotPasswrdForm.value.Password;
        payload.EmailToken = this.clientToken;
      } else {
        payload = this.forgotPasswrdForm.value;
      }

      this.http.post<LoginResponse>(endpoint, payload).subscribe((forgotPassword) => {
        if (forgotPassword.Status == true) {
          if (this.clientToken)
            this.showSuccess = true
          else
            this.router.navigate(['/user-login']);


        } else {
          this.errorMessage = forgotPassword.Message;
          this.submitted = false
        }
        this.endpoint = false;
        this.loader = false
      }, (err: HttpErrorResponse) => {
        console.log(err);
        this.endpoint = false;
        this.loader = false
        this.submitted = false
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
        // this.utility.alert.toast({ title: err.error.message, type: 'error' });
      })
    }
  }
}

