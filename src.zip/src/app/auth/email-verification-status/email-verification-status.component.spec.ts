import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmailVerificationStatusComponent } from './email-verification-status.component';

describe('EmailVerificationStatusComponent', () => {
  let component: EmailVerificationStatusComponent;
  let fixture: ComponentFixture<EmailVerificationStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmailVerificationStatusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmailVerificationStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
