import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { ApiResponse } from 'src/app/core/models/auth';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-email-verification-status',
  templateUrl: './email-verification-status.component.html',
  styleUrls: ['./email-verification-status.component.css']
})
export class EmailVerificationStatusComponent implements OnInit {

  private activationId: string | null;
  public checkingStatus: boolean = false;
  public statusMessage: string = 'Please wait...';

  constructor(
    private utility: UtilityService,
    private http: HttpClient,
    private userService: UserService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {
    this.activationId = this.activatedRoute.snapshot.paramMap.get('id');
    try {
      let activationIdNew = atob(this.activationId as  string);
      this.activationId = btoa(activationIdNew)
    } catch{
      console.log('InvalidToken')
    }
  }

  ngOnInit(): void {
    if (this.activationId) {
      this.checkActivationStatus();
    } else {
      this.router.navigate(['/user-login']);
    }
  }

  public checkActivationStatus() {
    //this.checkingStatus = true;
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.auth.accountActivation + this.activationId);
    this.http.get<ApiResponse>(endpoint).subscribe((response) => {
      if (response.Status == true) {
        this.statusMessage = response.Message;
        // this.utility.alert.toast({ title: response.Message, type: 'success' });
      } else {
        this.statusMessage = response.Message;
        // this.utility.alert.toast({ title: response.Message, type: 'error' });
      }
      //this.checkingStatus = false;
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.statusMessage = err?.error?.message;
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.checkingStatus = false;
      this.utility.loader.next(false);
    })
  }

}
