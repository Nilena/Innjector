import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { LoginGuard } from '../core/guards/login.guard';
import { SharedModule } from '../shared/shared.module';

import { LoginComponent } from './login/login.component';
import { ForgotUsernameComponent } from './forgot-username/forgot-username.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { PayAsGuestComponent } from './pay-as-guest/pay-as-guest.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { UserDetailsFormComponent } from './user-details-form/user-details-form.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { ShowUsernameComponent } from './show-username/show-username.component';
import { ResendEmailComponent } from './resend-email/resend-email.component';
import { EmailVerificationStatusComponent } from './email-verification-status/email-verification-status.component';
import { MhoLoginComponent } from './mho-login/mho-login.component';
import { SecondRedirectHitComponent } from './second-redirect-hit/second-redirect-hit.component';
import { EmailLoginComponent } from './email-login/email-login.component';
import { FaqComponent } from '../shared/components/faq/faq.component'
import { ContactUsWrapperComponent } from '../shared/components/contact-us-wrapper/contact-us-wrapper.component';
import { GetStartedComponent } from './get-started/get-started.component';
import { TextLoginComponent } from './text-login/text-login.component';
import { WebChatResolver } from '../shared/resolver/web-chat.resolver';
import { AchConfirmationComponent } from './ach-confirmation/ach-confirmation.component';
import { ErrorPageComponent } from '../shared/components/error-page/error-page.component';
import { ErrorGuard } from '../core/guards/error.guard';

export const routes: Routes = [
  {
    path: 'error', component: ErrorPageComponent, canActivate: [ErrorGuard]
  },
  {
    path: 'get-started', component: GetStartedComponent, canActivate: [LoginGuard]
  },
  {
    path: 'user-login', component: LoginComponent, canActivate: [LoginGuard]
  },
  {
    path: 'user-login/:clientToken', component: LoginComponent, canActivate: [LoginGuard]
  },
  {
    path: 'email-login/:clientToken', component: EmailLoginComponent
  },
  {
    path: 'create-account', component: CreateAccountComponent, canActivate: [LoginGuard]
  },
  {
    path: 'create-account/:clientToken', component: CreateAccountComponent, canActivate: [LoginGuard]
  },
  {
    path: 'reset-username', component: ForgotUsernameComponent, canActivate: [LoginGuard]
  },
  {
    path: 'forgot-password', component: ForgotPasswordComponent, canActivate: [LoginGuard]
  },
  {
    path: 'guest-login', component: PayAsGuestComponent, canActivate: [LoginGuard]
  },
  {
    path: 'guest-login/:clientToken', component: PayAsGuestComponent, canActivate: [LoginGuard]
  },
  {
    path: 'regristation/:clientToken', component: PayAsGuestComponent, canActivate: [LoginGuard]
  },
  {
    path: 'password-reset/:clientToken', component: ResetPasswordComponent
  },
  {
    path: 'change-password', component: ResetPasswordComponent, canActivate: [LoginGuard]
  },
  {
    path: 'forgot-username/:clientToken', component: ShowUsernameComponent,
  },
  {
    path: 'resend-email', component: ResendEmailComponent,
  },
  {
    path: 'resend-email/:clientKey/:key', component: ResendEmailComponent,
  },
  {
    path: 'mho-redirect/:facility/:keywords?', component: MhoLoginComponent,
  },
  {
    path: 'mh-one/:clientKey?', component: SecondRedirectHitComponent,
  },
  {
    path: 'mh-one', component: SecondRedirectHitComponent,
  },
  {
    path: 'account-activation/:id', component: EmailVerificationStatusComponent,
  },
  {
    path: 'faq', component: FaqComponent,
  },
  {
    path: 'web-chat', component: ContactUsWrapperComponent
  },
  { path: 'web-chat/:id', component: ContactUsWrapperComponent },
  { path: 'text-login/:clientToken', component: TextLoginComponent },
  {
    path: 'ach-confirmation/:achKey', component: AchConfirmationComponent
  }

]




@NgModule({
  declarations: [
    LoginComponent,
    ForgotUsernameComponent,
    ForgotPasswordComponent,
    PayAsGuestComponent,
    CreateAccountComponent,
    UserDetailsFormComponent,
    ResetPasswordComponent,
    ShowUsernameComponent,
    ResendEmailComponent,
    EmailVerificationStatusComponent,
    MhoLoginComponent,
    SecondRedirectHitComponent,
    EmailLoginComponent,
    GetStartedComponent,
    TextLoginComponent,
    AchConfirmationComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    SharedModule,
    BrowserAnimationsModule,
    RouterModule.forChild(routes)
  ],
  exports: [

  ]
})
export class AuthModule { }
