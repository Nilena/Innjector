import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { forkJoin } from 'rxjs';
import { getApiUrl, apiList } from 'src/app/core/constants/api-list';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { ApiResponse, LoginResponse } from 'src/app/core/models/auth';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { UserService } from '../services/user.service';
import { CustomValidation } from 'src/app/shared/utilities/custom-validator';
import { environment } from 'src/environments/environment';
import { InlineToaster } from 'src/app/shared/components/inline-toast/inline-toast.component';

@Component({
  selector: 'app-text-login',
  templateUrl: './text-login.component.html',
  styleUrls: ['./text-login.component.css']
})
export class TextLoginComponent implements OnInit {

  public loginForm: FormGroup;
  public guestForm: FormGroup;
  public loginInProgress: boolean = false;
  public loginSubmitted: boolean = false;
  public guestLoginInProgress: boolean = false;
  public guestLoginSubmitted: boolean = false;
  public showPassword: boolean = false;
  public termsPopup: boolean = false;
  emittedCheckedvalue: boolean = false;
  termsAndConditions: string = "";

  public get controls() { return this.loginForm.controls };
  public get guestControls() { return this.guestForm.controls };
  // public clientToken: string | null;
  public errorMessage: string | null = null;
  public guestErrorMessage: string | null = null;
  @ViewChild('topToastMessage') public topToastMessage?: InlineToaster;

  isMho: any;
  emailKey: any;
  guid: any = '';
  payload: any;
  firstItem: boolean = false;
  ssN: boolean = false;
  dob: boolean = false;
  dataArr: any = [];
  mainArr: any = [];
  mhoShow: boolean = false;
  peopleID: number | null = null;
  inValidMessageShow: boolean = false;
  inValidMessage: string | null = null;
  checkBoxEnable: boolean = false;
  @ViewChild('text') text! : ElementRef;
  constructor(
    private userService: UserService,
    private utility: UtilityService,
    private http: HttpClient,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {
    this.emailKey = this.activatedRoute.snapshot.paramMap.get('clientToken');
    try {
      let emailKey = atob(this.emailKey)
      this.emailKey = btoa(emailKey)
    } catch{
      console.log('InvalidToken')
    }
    this.loginForm = new FormGroup({
      username: new FormControl(null, Validators.compose([Validators.required])),
      password: new FormControl(null, Validators.compose([Validators.required]))//, Validators.maxLength(50), Validators.minLength(6)
    })
    this.guestForm = new FormGroup({
      accNo: new FormControl(null),
      first: new FormControl(null, Validators.compose([Validators.required, CustomValidation.noSpaceOnly])),
      ssn: new FormControl(null, Validators.compose([Validators.required, CustomValidation.noSpaceOnly, Validators.minLength(4)])),
      DateOfBirth: new FormControl(null, [Validators.required, CustomValidation.futureDate, CustomValidation.validDate, CustomValidation.noSpaceOnly, CustomValidation.OldDate])
    })
  }

  ngOnInit(): void {
    this.userService.removeSession(true);
    this.utility.saveToLocalStorage(CONSTANTS.APP_CONFIG.FIRST_TIME_LOADING, "true");
    this.init();
    let payload = { "EncString": "clinic" };
    let endpoint = getApiUrl(apiList.auth.TermsAndConditon);
    this.http.post<ApiResponse>(endpoint, payload).subscribe((response) => {
      this.termsAndConditions = response.Data;
    })
  }
  ngAfterViewInit(){
    this.text?.nativeElement.focus();
  }
  /*
  author : Nilena Alexander
  desc   : to intital api call to get guid and accno
  */
  public init() {
    this.utility.loader.next(true);
    let endpoint = getApiUrl(`${apiList.auth.ValidateTextLinkURL}EncodedData=${this.emailKey}`);
    this.http.get<ApiResponse>(endpoint).subscribe((data) => {
      if (data.Status == true) {
        this.mainArr = data.Data;
        this.guid = data.Data.guid;
        this.mhoShow = data.Data.IsMHO;
        this.peopleID = data.Data.PeopleID;
        this.utility.setTempData('Guid', data.Data.guid);
        this.guestForm.controls['accNo'].setValue(data.Data.AccountNumber);
        let configData: any = {};
        configData = {
          Module: 'Login',
          Form: 'TextLinkLogin',
          guid: data.Data.guid
        };
        this.getAuthConfig(configData);

      } else {
        // this.router.navigate(['/user-login']);
        let configData = {
          Module: 'Login',
          Form: "TextLinkLogin",
          guid: 'clinic'
        };
        this.inValidMessageShow = true;
        this.topToastMessage?.inlineToast({ type: 'error', title: data.Message, __disableAutoClose: true });

        // this.utility.alert.toast({ title: data.Message, type: 'error', __disableAutoClose: true, __clearAll: true });
        this.inValidMessage = data.Message;
        this.getAuthConfig(configData);

        // this.utility.alert.toast({ title: data.Message, type: 'error' });
      }
      this.userService.removeSession(true);
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      console.log(err);
      // this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.topToastMessage?.inlineToast({ type: 'error', title: err?.error?.message });
      this.utility.loader.next(false);
    })
  }
  checkValue(event: boolean) {
    if (event == true) {
      this.emittedCheckedvalue = true;
      this.checkBoxEnable = true
    } else {
      this.emittedCheckedvalue = false
      this.checkBoxEnable = false
    }
    this.termsPopup = false;
  }
  getAuthConfig(configData: object) {
    let endpoint = (getApiUrl(`${apiList.auth.GetAuthConfig}`));
    this.http.post<ApiResponse>(endpoint, configData).subscribe((data1) => {
      this.dataArr = data1.Data;
      if (data1.Status == true) {
        if (data1.Data[0].Options !== 'H') {
          this.firstItem = true;
          if (data1.Data[0].Options == 'O') {
            this.guestForm.controls['first'].setValidators(null);
            this.guestForm.controls['first'].updateValueAndValidity();
          }
        }
        if (data1.Data[0].Options == 'H') {
          this.firstItem = false;
          this.guestForm.controls['first'].setValidators(null);
          this.guestForm.controls['first'].updateValueAndValidity();
        }
        if (data1.Data[1].Options !== 'H') {
          this.ssN = true;
          if (data1.Data[1].Options == 'O') {
            this.guestForm.controls['ssn'].setValidators(null);
            this.guestForm.controls['ssn'].updateValueAndValidity();
          }
        }
        if (data1.Data[1].Options == 'H') {
          this.ssN = false;
          this.guestForm.controls['ssn'].setValidators(null);
          this.guestForm.controls['ssn'].updateValueAndValidity();
        }
        for (let i = 0; i < data1.Data.length; i++) {
          if (data1.Data[i].AuthFactorCode == 'DATEOFBIRTH' && data1.Data[i].Options !== 'H') {
            this.dob = true;
            if (data1.Data[i].Options == 'O') {
              this.guestForm.controls['DateOfBirth'].setValidators(null);
              this.guestForm.controls['DateOfBirth'].updateValueAndValidity();
            }
          }
          if (data1.Data[i].AuthFactorCode == 'DATEOFBIRTH' && data1.Data[i].Options == 'H') {
            this.dob = false;
            this.guestForm.controls['DateOfBirth'].setValidators(null);
            this.guestForm.controls['DateOfBirth'].updateValueAndValidity();
          }
        }
      }
    }, (err: HttpErrorResponse) => {
      console.log(err);
      // this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.topToastMessage?.inlineToast({ type: 'error', title: err?.error?.message });
      this.utility.loader.next(false);
    })
  }
  /*
 author : Nilena Alexander
 desc   : navigate to forgot password
 */
  forgotPassword() {
    this.utility.setTempData('PeopleID', this.peopleID);
    this.router.navigate(['/forgot-password']);
  }

  checkBoxChanges() {
    if (this.checkBoxEnable) {
      this.emittedCheckedvalue = false;
      this.termsPopup = true;
    }
    else
      this.emittedCheckedvalue = false;
  }

  /*
author : Nilena Alexander
desc   : tocheck aagree or not 
*/
  checkEnable() {
    this.emittedCheckedvalue = false;
    this.termsPopup = true;
  }


  /*
 author : Nilena Alexander
 desc   : navigate to create  acc
 */
  createAcc() {
    this.router.navigate(['/create-account/' + this.guid]);
  }
  /*
  author : Nilena Alexander
  desc   : guest login submit
  */
  public guestLogin(): void {
    if (this.inValidMessage)
      // this.utility.alert.toast({ title: this.inValidMessage, type: 'error', __disableAutoClose: true, __clearAll: true });
      this.topToastMessage?.inlineToast({ title: this.inValidMessage, type: 'error', __disableAutoClose: true, __clearAll: true });
    else {
      this.guestLoginSubmitted = true;
      this.guestErrorMessage = null;
      if (this.guestForm.valid && this.emittedCheckedvalue) {
        this.guestLoginInProgress = true;
        this.utility.setTempData(CONSTANTS.SESSION.SHOW_RMEX_POP, 'T');
        let endpoint = getApiUrl(apiList.auth.TextLinkGuestLogin);
        let payload = {
          'AccountNo': this.mainArr.AccountNumber,
          'UrlType': "Not Login",
          'ClientGroupID': this.mainArr.ClientGroupId,
          'FacilityID': this.mainArr.FacilityId,
          'DateOfBirth': this.guestForm.value.DateOfBirth,
          'ssn': (this.guestForm.value.ssn) ? (this.guestForm.value.ssn) : null,
          'LastName': (this.guestForm.value.first) ? (this.guestForm.value.firstItem) : undefined,
        }
        this.http.post<LoginResponse>(endpoint, payload).subscribe((loginResponse) => {
          if (loginResponse.Status == true) {
            this.userService.setUserInfo(loginResponse.Data);
            this.router.navigate(['/dashboard']);
            this.utility.setTempData(CONSTANTS.APP_CONFIG.login_config, { facilityid: this.guid && this.guid, guid: "/" + this.guid, token: "/" + this.emailKey, eLogin: 2, unique: "1" });
          } else
            this.guestErrorMessage = loginResponse.Message;
          this.guestLoginInProgress = false;
        }, (err: HttpErrorResponse) => {
          console.log(err);
          // this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
          this.topToastMessage?.inlineToast({ type: 'error', title: err?.error?.message });
          this.guestLoginInProgress = false;
        })
      }
    }


  }
  /*
  author : Nilena Alexander
  desc   :  login submit
  */
  public login(): void {
    if (this.inValidMessage)
      this.topToastMessage?.inlineToast({ title: this.inValidMessage, type: 'error', __disableAutoClose: true, __clearAll: true });
    // this.utility.alert.toast({ title: this.inValidMessage, type: 'error', __disableAutoClose: true, __clearAll: true });
    else {
      this.loginSubmitted = true;
      this.errorMessage = null;
      if (this.loginForm.valid) {
        this.loginInProgress = true;
        let endpoint = getApiUrl(apiList.auth.AuthenticateTextLinkLogin);
        let payload =
        {
          'AccountNo': this.mainArr.AccountNumber,
          'UrlType': "Login",
          'ClientGroupID': this.mainArr.ClientGroupId,
          'FacilityID': this.mainArr.FacilityId,
          'UserName': this.loginForm.value.username,
          'PassWord': this.loginForm.value.password
        }
        this.http.post<LoginResponse>(endpoint, payload).subscribe((loginResponse) => {
          if (loginResponse.Status == true) {
            this.userService.setUserInfo(loginResponse.Data);
            this.router.navigate(['/dashboard']);
            this.utility.setTempData(CONSTANTS.APP_CONFIG.login_config, { facilityid: this.guid && this.guid, guid: "/" + this.guid, token: "/" + this.emailKey, eLogin: 2, unique: "1" });
          } else {
            this.errorMessage = loginResponse.Message;
          }
          this.loginInProgress = false;
        }, (err: HttpErrorResponse) => {
          console.log(err);
          this.topToastMessage?.inlineToast({ type: 'error', title: err?.error?.message });
          // this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
          this.loginInProgress = false;
        })
      }
    }
  }

  public loginWithMho() {
    let reg_type = 'mho';
    this.getLoginPayload('Log In Start', 'Log In');
    this.utility.setTempData(CONSTANTS.SESSION.SSO_EMAIL_NAV, this.emailKey);
    if (document.referrer) {
      this.utility.setTempData(CONSTANTS.SESSION.SPLASH_REFERROR, document.referrer);
    }
    this.utility.setTempData(CONSTANTS.APP_CONFIG.login_config, JSON.stringify({ guid: '/null', token: "/" + this.emailKey, eLogin: 1, unique: "1" }));
    this.mhoLogin();
    this.getLoginPayload('Log In Completed', 'Log In');
  }
  mhoLogin() {
    let url = environment.mhoDomain;
    window.location.replace(url);
  }

  getLoginPayload(title: string, category: string) {
    let userInfo = this.userService.getUserInfo();
    let data = {
      event_title: title,
      event_category: category,
      data_object: { login_type: "email" },

      event_interactive: true,
      event_logged_in: userInfo ? true : false,
      event_registration_type: userInfo ? (userInfo.FromMHO ? 'mho' : 'epay') : null,
      event_facility: userInfo ? userInfo.ClientCode : null,
      event_user_id: userInfo ? userInfo.UserID : null,
      event_user_type: userInfo ? 'patient' : null,
      event_success: true,
      event_session_id: userInfo ? userInfo.RequestToken : null,
    }
    this.utility.googleTrack(data);
  }

}
