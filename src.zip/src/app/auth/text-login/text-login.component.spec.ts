import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TextLoginComponent } from './text-login.component';

describe('TextLoginComponent', () => {
  let component: TextLoginComponent;
  let fixture: ComponentFixture<TextLoginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TextLoginComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TextLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
