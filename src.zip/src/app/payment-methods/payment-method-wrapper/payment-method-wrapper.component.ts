import { Component, OnInit, ViewChild, ElementRef, HostListener } from '@angular/core';

import { getApiUrl, apiList } from 'src/app/core/constants/api-list';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { Router, NavigationEnd } from '@angular/router';
import { timer, interval, forkJoin } from 'rxjs';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ApiResponse, Profile, TempData, CardItem, TempDataResponse, AddPaymentResponse, PayData, paymentData } from 'src/app/core/models/auth';
import { UserService } from 'src/app/auth/services/user.service';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-payment-method-wrapper',
  templateUrl: './payment-method-wrapper.component.html',
  styleUrls: ['./payment-method-wrapper.component.css']
})
export class PaymentMethodWrapperComponent implements OnInit {

  userInfo: Profile | null = null;
  activeView: number = 1;
  enableApplePay: boolean = false;
  enaleSettingsApple: boolean = false;
  detailedData: TempDataResponse | null = null;
  processorType: string = '';
  @ViewChild('methods') methods! : ElementRef;
  tempData: any = [];
  constructor(
    private http: HttpClient,
    private utility: UtilityService,
    private userService: UserService
  ) { }
  @HostListener('keydown', ['$event'])
  clickarrowx(event: any) {
    if(event.code == 'Enter' || event.key == 'Enter'){
        if(document.activeElement?.lastChild?.textContent==='Credit Card'){
         this.activeView = 2;
        }
        if(document.activeElement?.lastChild?.textContent==='Apple pay'){
          this.activeView = 3;
         }
    }
  }
  ngOnInit(): void {

    if (this.utility.getTempData('tempId')) {
      this.userInfo = this.userService.getUserInfo();
      let id = this.utility.getTempData('tempId');
      this.GetAllApiDetails(id);
    }
  }
  ngAfterViewInit(){
    this.methods.nativeElement.focus();
  }

  /*
     author : Nilena Alexander
     desc   : to get all data from intial ai calls
     */
  GetAllApiDetails(id: string) {
    this.utility.loader.next(true);
    let payload = {
      SettingsKey: "MerchantIdentifier,IsApplepayEnabled"
    }
    let endpoint = getApiUrl(apiList.payment.GetSettings)
    // let endpoint1 = getApiUrl(apiList.paymentMethods.getPatientProcessorType) + '?peopleID=' + this.userInfo?.PeopleID;
    let endpoint2 = getApiUrl(apiList.temp.get) + id;

    forkJoin([
      this.http.post<ApiResponse>(endpoint, payload), this.http.get<ApiResponse>(endpoint2)
    ]).subscribe((response: any[]) => {
      this.getSettings(response[0]);
      // this.getPatientProcessorType(response[1]);
      this.getData(response[1]);
      this.applePaychecker();
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      this.utility.loader.next(false);
      console.log(err)
      this.utility.alert.toast({ title: err.error.message, type: 'error' });
    })
  }
  /*
    author : Nilena Alexander
    desc   : tocheck processor type
    */
  checkProcessor() {
    if (this.tempData && this.tempData.BillData) {
      for (let i = 0; i < this.tempData.BillData.length; i++) {
        if (this.tempData.BillData[i].ProcessorType == "FD") {
          this.processorType = "FD";
        } else {
          this.processorType = "HPS";
          break;
        }
      }
      this.applePaychecker();
    }
  }

  /*
author : Nilena Alexander
desc   : to show apple pay icon
*/
  applePaychecker() {
    if ((window as any).ApplePaySession && this.processorType == "FD" && this.detailedData?.Key == CONSTANTS.PAY_MODES.NOW && this.enaleSettingsApple) {
      this.enableApplePay = true;
    } else
      this.enableApplePay = false;
  }

  /*
    author : Nilena Alexander
    desc   : toget tempDetails
    */
  getData(data: any) {
    if (data.Status == true) {
      this.detailedData = data.Data as TempDataResponse;
      this.tempData = JSON.parse(this.detailedData?.Value)
      this.checkProcessor();
    } else {
      this.utility.alert.toast({ title: data.Message, type: 'error' });
    }
  }

  
  /*
  author : Nilena Alexander
  desc   : toget settingDetails for applepay
  */
  getSettings(data: any) {
    if (data.Status == true) {
      if (data.Data[2].Key == 'IsApplepayEnabled' && data.Data[2].Value == '1') {
        this.enaleSettingsApple = true;
        this.applePaychecker();
      }
    } else {
      this.enaleSettingsApple = false;
      this.utility.alert.toast({ title: data.Message, type: 'error' });
    }
  }
}

