import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentMethodWrapperComponent } from './payment-method-wrapper.component';

describe('PaymentMethodWrapperComponent', () => {
  let component: PaymentMethodWrapperComponent;
  let fixture: ComponentFixture<PaymentMethodWrapperComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaymentMethodWrapperComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentMethodWrapperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
