import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConfigurePaymentMethodsComponent } from './configure-payment-methods/configure-payment-methods.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../shared/shared.module';
import { ElectronicCheckComponent } from './electronic-check/electronic-check.component';
import { AddCreditCardComponent } from './add-credit-card/add-credit-card.component';
import { ApplePayComponent } from './apple-pay/apple-pay.component';
import { RoleGuardService } from '../shared/services/role-guard.service';
import { TempResolver } from '../shared/resolver/temp.resolver';
import { PaymentMethodWrapperComponent } from './payment-method-wrapper/payment-method-wrapper.component';
const routes: Routes = [{
  path: 'configure-payment',
  component: ConfigurePaymentMethodsComponent,
  canActivate: [RoleGuardService]
},
{
  path: 'electronic-check',
  component: ElectronicCheckComponent, 
  resolve: { temp: TempResolver} ,
},
{
  path: 'apple-pay',
  component: ApplePayComponent,
},
{
  path: 'credit-card',
  component: AddCreditCardComponent,
},
{
  path: 'add-payment-method',
  component: PaymentMethodWrapperComponent,
},
]

@NgModule({
  declarations: [
    ConfigurePaymentMethodsComponent,
    ElectronicCheckComponent,
    AddCreditCardComponent,
    ApplePayComponent,
    PaymentMethodWrapperComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    RouterModule.forChild(routes)
  ]
})
export class PaymentMethodsModule { }
