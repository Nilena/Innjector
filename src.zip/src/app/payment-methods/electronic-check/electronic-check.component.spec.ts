import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ElectronicCheckComponent } from './electronic-check.component';

describe('ElectronicCheckComponent', () => {
  let component: ElectronicCheckComponent;
  let fixture: ComponentFixture<ElectronicCheckComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ElectronicCheckComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ElectronicCheckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
