import { Component, OnInit } from '@angular/core';
import { FormGroup, AbstractControl, FormControl, Validators, ValidationErrors, ValidatorFn } from '@angular/forms';
import { CustomValidation } from 'src/app/shared/utilities/custom-validator';
import { Router } from '@angular/router';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ApiResponse, Profile, TempData, CardItem, TempDataResponse, AddPaymentResponse, PayData, paymentData } from 'src/app/core/models/auth';
import { getApiUrl, apiList } from 'src/app/core/constants/api-list';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { UserService } from 'src/app/auth/services/user.service';
import { timer, interval, forkJoin } from 'rxjs';
import { LPG, LpgTokenResponse } from 'src/app/core/models/lpg';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { PatientprocessorType } from '../../core/models/payment';
import { REGCONSTANTS } from '../../core/constants/regex-constants';


@Component({
  selector: 'app-electronic-check',
  templateUrl: './electronic-check.component.html',
  styleUrls: ['./electronic-check.component.css']
})
export class ElectronicCheckComponent implements OnInit {
  public paymentType: string = ""
  public hasRmexPlans: boolean = false;
  public electronicCheckForm: FormGroup;
  errorRouting: string = '';
  showEc: boolean = false;
  nickNameSet: string = ''
  emittedCheckedvalue: boolean = false;
  submitted: boolean = false;
  disabledCheckBox: boolean = false;
  checkBox: boolean = false;
  agreeEnable: boolean = false;
  pageType: boolean = false;
  loader: boolean = false;
  rotingInProgress: boolean = false;
  nickNameInProgress: boolean = false;
  routingInProgress: boolean = false;
  routingTSNo: any | null = null;
  bankAccNo: number | null = null;
  userInfo: Profile | null = null;
  detailedData: TempDataResponse | null = null;
  tempData: TempData | null = null;
  detailTemp: CardItem | null = null;
  PatientprocessorType: PatientprocessorType | null = null
  termsAndCondtions: any;
  processorType: string = '';
  openMenu: boolean = false;
  nickName: any = null;
  private merchantIds: string = '';
  errorNcikName: string = '';
  loaderSubmit: boolean = false;
  alreadySubmitted: boolean = false;
  payload: any = {};
  termsPopup: boolean = false;
  public showAccountnumber: boolean = false;
  public get controls() {
    return this.electronicCheckForm.controls;
  }
  constructor(private router: Router,
    private http: HttpClient,
    private UserService: UserService,
    private utility: UtilityService) {

    this.electronicCheckForm = new FormGroup({
      bankAccount: new FormControl(null, Validators.compose([CustomValidation.noSpaceOnly, Validators.required, CustomValidation.onlyNumber,
      Validators.minLength(4), Validators.maxLength(17)])),
      confirmAccNumber: new FormControl(null, Validators.compose([CustomValidation.noSpaceOnly, Validators.required, CustomValidation.onlyNumber,
      Validators.minLength(4), Validators.maxLength(17)])),
      accName: new FormControl(null, [
        Validators.required,
        Validators.pattern(REGCONSTANTS.nameValidation)
      ]),
      accountType: new FormControl(null, Validators.compose([Validators.required])),
      routingTransitNo: new FormControl(null, Validators.compose([Validators.required, CustomValidation.noSpaceOnly])),
      EmailAddress: new FormControl(this.userInfo?.EmailId, Validators.compose([Validators.required, CustomValidation.email])),
      paymentMethod: new FormControl(null, [Validators.required, CustomValidation.noSpaceOnly])
    }, Validators.compose([this.confirmACCNOValidation()]))
  }
  private confirmACCNOValidation(): ValidatorFn {
    return (formGroup: AbstractControl): ValidationErrors | null => {
      let bankAccount = formGroup.get('bankAccount')?.value;
      let confirmAccNumber = formGroup.get('confirmAccNumber')?.value;
      if (bankAccount && confirmAccNumber && bankAccount != confirmAccNumber) {
        return { NotMatching: true }
      }
      return null;
    }
  }
  ngOnChanges() {

  }

  ngOnInit(): void {
    this.userInfo = this.UserService.getUserInfo();
    this.hasRmexPlans = this.utility.hasRmexPlans;
    if (this.userInfo?.EmailId) {
      this.electronicCheckForm.controls['EmailAddress'].setValue(this.userInfo?.EmailId);
    }
    if (this.utility.getTempData('tempId')) {
      let id: any = this.utility.getTempData('tempId')
      this.GetAllApiDetails(id);
    }
    // Checking if user is guest and removing the validation for email
    if (this.userInfo.IsGuest) {
      this.electronicCheckForm.controls.EmailAddress?.setValidators(CustomValidation.email);
    }
    if (this.utility.hasRmexPlans) {
      this.electronicCheckForm.controls.EmailAddress?.setValidators(CustomValidation.email);
    }

  }
  /*
     author : Nilena Alexander
     desc   : to get all data from intial ai calls
     */
  GetAllApiDetails(id: string) {
    this.loader = true;
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.paymentMethods.GetTermsAndConditionForPayment);
    // let endpoint1 = getApiUrl(apiList.paymentMethods.getPatientProcessorType) + '?peopleID=' + this.userInfo?.PeopleID;
    let endpoint2 = getApiUrl(apiList.temp.get) + id;

    forkJoin([
      this.http.get<ApiResponse>(endpoint), this.http.get<ApiResponse>(endpoint2)
    ]).subscribe((response: any[]) => {
      this.getTermsAndConditions(response[0]);
      // Storing payment type
      this.paymentType = response[1].Data.Key
      if (response[1].Data.Key == 'payNow') {
        this.electronicCheckForm.controls.EmailAddress?.setValidators(CustomValidation.email);
      }
      this.getTempData(response[1]);
      this.utility.loader.next(false);
      this.loader = false;
    }, (err: HttpErrorResponse) => {
      this.loader = false;
      this.utility.loader.next(false);
      console.log(err)
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }
  /*
    author : Nilena Alexander
    desc   : tocheck processor type
    */
  checkProcessor() {
    if (this.detailedData?.Key == "addMethod") {
      if (this.tempData?.Mode == 'Edit') {
        if (this.detailTemp?.ProcessorType == "FD") {
          this.processorType = "FD";
        } else {
          if (this.detailTemp?.AccountType == "Electronic Check" && this.detailTemp?.IsAssociated)
            this.getProcessorType(this.detailTemp);
          else
            this.getPatientProcessorType();
        }
      } else {
        this.getPatientProcessorType();
      }
    } else if (this.detailedData?.Key == "attachPlan") {

      if (this.detailTemp?.ProcessorType == "FD") {
        this.processorType = "FD";
      } else {
        this.processorType = "HPS";
      }

    } else {
      if (this.tempData) {
        for (let i = 0; i < this.tempData.BillData.length; i++) {
          if (this.tempData.BillData[i].ProcessorType == "FD") {
            this.processorType = "FD";
          } else {
            this.processorType = "HPS";
            break;
          }
        }
      }

    }
  }
  /*
   author : Nilena Alexander
   desc   : to get temparory Data from db
   */
  getTempData(data: ApiResponse) {
    if (data.Status == true) {
      this.detailedData = data.Data as TempDataResponse;
      if (this.detailedData.Value)
        this.tempData = JSON.parse(this.detailedData.Value);
      if (this.detailedData.Key !== 'payNow') {
        this.checkBox = true
        this.disabledCheckBox = true;
      }
      else
        this.disabledCheckBox = false;
      this.detailTemp = (this.tempData?.CardData as CardItem) || null;
      if (this.tempData && this.tempData.Mode === 'Edit') {
        this.pageType = true;
        if (this.detailTemp?.AccountType === 'Electronic Check') {
          this.electronicCheckForm.controls['paymentMethod'].setValue(this.detailTemp.Nickname);
          this.nickName = this.detailTemp.Nickname;
        }
      } else {
        this.pageType = false;
      }
      this.checkProcessor();
    }
  }
  /*
  author : Nilena Alexander
  desc   : to get terms and condtions
  params :
  */
  getTermsAndConditions(data: ApiResponse) {
    if (data.Status == true)
      this.termsAndCondtions = data.Data;
    else
      this.utility.alert.toast({ title: data.Message, type: 'error' });
  }
  /*
    author : Nilena Alexander
    desc   : to get patient details
    */
  getPatientProcessorType() {
    this.loader = true;
    let endpoint1 = getApiUrl(apiList.paymentMethods.getPatientProcessorType) + '?peopleID=' + this.userInfo?.PeopleID;
    this.http.get<ApiResponse>(endpoint1).subscribe(data => {
      if (data.Status == true) {
        this.PatientprocessorType = data.Data as PatientprocessorType;
        let processorData = data.Data.ProcessorTypes;
        this.merchantIds = data.Data.MerchantIds;
        if (this.PatientprocessorType && this.PatientprocessorType.ProcessorTypes && this.PatientprocessorType.ProcessorTypes.length) {
          for (let i = 0; i < processorData.length; i++) {
            if (processorData[i] == "HPS") {
              this.processorType = "HPS";
              break;
            } else
              this.processorType = "FD";
          }
        }
        this.loader = false;
      }
      else {
        this.loader = false;
        this.utility.alert.toast({ title: data.Message, type: 'error' });

      }
    }, (err: HttpErrorResponse) => {
      this.loader = false;
      console.log(err)
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }

  /*
  author : Nilena Alexander
  modified: Arun Lalithambaran
  desc   : to open side menu
  */
  menuData(event: boolean | string) {
    this.openMenu = !!event;
  }



  /*
      author : Nilena Alexander
      desc   : to get checkbox data from terms and condtions
      params :
      */

  checkBoxChanges() {
    if (this.agreeEnable) {
      this.emittedCheckedvalue = false;
      this.termsPopup = true;
    }else{
      this.emittedCheckedvalue = false;
    }
  }

  checkEnable() {
    // this.emittedCheckedvalue = this.emittedCheckedvalue;
    // this.agreeEnable = true
    this.emittedCheckedvalue = false;
    this.termsPopup = true;
  }

  /*
   author : Nilena Alexander
   desc   : tocheck aagree or not
   */
  checkValue(event: boolean) {
    if (event == true) {
      this.emittedCheckedvalue = true;
      this.agreeEnable = true
    } else {
      this.emittedCheckedvalue = false
      this.agreeEnable = false
    }
    this.termsPopup = false;
  }


  getProcessorType(Data: CardItem | null): void {
    let endpoint: string = '';
    if (Data)
      endpoint = getApiUrl(apiList.paymentMethods.getProcessorTypeByTokenId) + 'tokenId=' + Data.TokenId;
    this.http.get<ApiResponse>(endpoint).subscribe((data) => {
      if (data.Status == true) {
        this.processorType = data.Data;
      }
      else {
      }
    }, (err: HttpErrorResponse) => {
      console.log(err)
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }
  /*
   author : Nilena Alexander
   desc   : to set  bankAcc and nickname or payment method for add when bankacc adds.
  */
  paymentMethodSet() {
    if (!this.bankAccNo) {
      return;
    }

      let string = (this.bankAccNo) + '';
      this.electronicCheckForm.controls['bankAccount'].setValue(this.bankAccNo);
      if (!this.userInfo?.IsGuest) {
      if (this.pageType && this.detailTemp) {
        if (this.pageType && (this.detailTemp.AccountType !== 'Electronic Check')) {
          let strLength = null;
          strLength = this.length(string);
          if (strLength > 3) {
            if (this.userInfo) {
              let info = this.userInfo.UserHeader.LastName.toString() +
                "-CK-" +
                this.electronicCheckForm.value.bankAccount.toString().substr(-4);
              this.electronicCheckForm.controls['paymentMethod'].setValue(info);
              this.paymentMethodExist();
            }
          }
        }
      } else if (!this.pageType) {
        let strLength = null;
        strLength = this.length(string);
        if (strLength > 3) {
          if (this.userInfo) {
            let info = this.userInfo.UserHeader.LastName.toString() +
              "-CK-" +
              this.electronicCheckForm.value.bankAccount.toString().substr(-4);
            this.electronicCheckForm.controls['paymentMethod'].setValue(info);
            this.nickName = info;
            this.paymentMethodExist();
          }
        }
      }
    }
    

  }
  /*
   author : Nilena Alexander
   desc   : to set nickname or payment method from payment method form.
  */
  NickNameChanges() {
    this.electronicCheckForm.controls['paymentMethod'].setValue(this.nickName);
    if (this.nickName && this.nickName.trim()) {
      this.paymentMethodExist();
    }

  }
  saveForFuture() {
    if (!this.disabledCheckBox && this.checkBox) {
      if (this.electronicCheckForm.value['paymentMethod'] == '' || this.electronicCheckForm.value['paymentMethod'] == null || this.electronicCheckForm.value['paymentMethod'] == undefined) {
        this.electronicCheckForm.controls['paymentMethod'].setValidators(Validators.required);
        this.electronicCheckForm.controls['paymentMethod'].updateValueAndValidity();
        // this.nickName = null;
        this.paymentMethodSet();
      }
    } else if (!this.disabledCheckBox && !this.checkBox) {
      if (this.electronicCheckForm.value['paymentMethod'] == '' || this.electronicCheckForm.value['paymentMethod'] == null || this.electronicCheckForm.value['paymentMethod'] == undefined) {
        this.electronicCheckForm.controls['paymentMethod'].setValidators(null);
        this.electronicCheckForm.controls['paymentMethod'].updateValueAndValidity();
        // this.nickName = null;
      }
    }
  }
  /*
   author : Nilena Alexander
   desc   : to check wether is nickname exist or not.
  */
  paymentMethodExist(): void {
    this.nickNameInProgress = true;
    let endpoint = getApiUrl(apiList.paymentMethods.CheckNickNameExist) + 'isUpdate=' + this.pageType + '&nickName=' + (this.electronicCheckForm.value['paymentMethod']).trim();
    this.http.get<ApiResponse>(endpoint).subscribe((response) => {
      if (response.Status == true && response.Data) {
        this.errorNcikName = '';
        if (response.Data !== true) {
          this.electronicCheckForm.controls['paymentMethod'].setValue(response.Data);
          this.nickName = response.Data;
          this.electronicCheckForm.controls['paymentMethod'].setValidators(null);
        }
        this.nickNameInProgress = false;
      } else if (!response.Status && response.Data == null && response.Message) {
        this.errorNcikName = response.Message;
        this.electronicCheckForm.controls['paymentMethod'].setErrors({ required: null });
        this.electronicCheckForm.controls['paymentMethod'].setErrors({ customError: true });
        this.nickNameInProgress = false;
      }
      else {
        this.errorNcikName = '';
        this.nickNameInProgress = false;
      }
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.nickNameInProgress = false;
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }

  /*
  author : Nilena Alexander
  desc   : to get length of a string
 */
  public length(value: string): number {
    return value.length;
  }

  /*
     author : Nilena Alexander
     desc   : for savePayment
     */
  savePayment(payload: {}, type: string): void {
    this.loaderSubmit = true;
    let endpoint = getApiUrl(apiList.paymentMethods.savepmtmethod);
    this.http.post<AddPaymentResponse>(endpoint, this.payload).subscribe((data) => {
      if (data.Status == true) {
        if (type !== 'add') {
          this.loaderSubmit = true;
          let newTokenid = data.Data as paymentData;
          let payload = {}
          payload = {
            Mode: (type !== 'add') ? 'PMU' : 'D',
            NewTokenId: newTokenid.attribute2,
            ParentTokenId: this.tempData?.CardData?.ParentTokenId,
            TokenId: this.tempData?.CardData?.TokenId,
          }
          this.alreadySubmitted = true;
          this.updatePayment(payload);
        }
        this.utility.alert.toast({ title: data.Message, type: 'success' });
        this.updateEmailAddess();
        if (this.detailedData?.Key == CONSTANTS.PAY_MODES.ADD)
          this.router.navigate(['/payment-methods/configure-payment']);
        else if (this.detailedData?.Key == CONSTANTS.PAY_MODES.ATTACH)
          this.router.navigate(['/dashboard/scheduled-payment-confirmation']);
        else if (this.detailedData?.Key == CONSTANTS.PAY_MODES.NOW)
          this.router.navigate(['/payment/confirm-payment']);
        else if ((this.detailedData?.Key == CONSTANTS.PAY_MODES.THIRTY) || (this.detailedData?.Key == CONSTANTS.PAY_MODES.HALF))
          this.router.navigate(['/payment/confirm-pay']);
        else if (this.detailedData?.Key == CONSTANTS.PAY_MODES.OTHERS)
          this.router.navigate(['/payment/confirm-other-payment']);
      }
      else {
        this.loaderSubmit = false;
        this.utility.alert.toast({ title: data.Message, type: 'error' });
      }
    }, (err: HttpErrorResponse) => {
      console.log(err)
      this.loaderSubmit = false;
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }

  cancel() {
    window.history.back();
  }
  /*
  author : Nilena Alexander
  desc   : for updatePayment
  */
  updatePayment(payload: {}): void {
    let endpoint = getApiUrl(apiList.paymentMethods.updatePaymentMethod);
    this.http.post<AddPaymentResponse>(endpoint, payload).subscribe((data) => {
      if (data.Status == true) {
        // this.utility.alert.toast({ title: data.Message, type: 'success' });
        this.payload = {};
        this.payload = {
          PaymentInfoList:
            [{
              AccountName: this.electronicCheckForm.value.accName,
              AccountNo: this.electronicCheckForm.value.bankAccount,
              AccountType: this.electronicCheckForm.value.accountType,
              CardType: "ACH",
              CcType: "ACH",
              Email: this.electronicCheckForm.value.bankAccount,
              LastFourDigits: this.electronicCheckForm.value.bankAccount.toString().substr(-4),
              Nickname: this.electronicCheckForm.value.paymentMethod,
              PaymentType: "ACH",
              ProcessorType: this.processorType,
              RoutingTransitNo: this.electronicCheckForm.value.routingTransitNo,
              SaveStatus: this.checkBox,
              agreeCondition: this.agreeEnable,
              confirmAccountNo: this.electronicCheckForm.value.confirmAccNumber,
              OldTokenID: null,
            }],
          Transaction: {
            Email: this.electronicCheckForm.value.EmailAddress,
            InstrumentType: "ACH",
            Nickname: this.electronicCheckForm.value.paymentMethod,
            PaymentMethod: "ACH",
          }
        };
        if (this.detailedData?.Key == CONSTANTS.PAY_MODES.ATTACH) {
          this.makePlanObject();
        }
        if (!this.alreadySubmitted)
          this.savePayment(this.payload, 'edit');
      }
      else {
        this.alreadySubmitted = false;
      }
    }, (err: HttpErrorResponse) => {
      console.log(err)
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }

  makePlanObject() {
    this.payload.PaymentInfoList[0].PlanHeaderID = this.tempData ? this.tempData?.HeaderID : null,
      this.payload.PaymentInfoList[0].SaveType = "Plan"
  }
  checkTypeofSubmit(): void {
    this.submitted = true;
    if (this.routingTSNo == "" || this.routingTSNo == null || this.routingTSNo == undefined)
      this.electronicCheckForm.controls['routingTransitNo'].setValue(this.routingTSNo)

    if (!this.agreeEnable) {
      return;
    }
    if (!this.disabledCheckBox && !this.checkBox) {
      if (this.electronicCheckForm.value['paymentMethod'] == '' || this.electronicCheckForm.value['paymentMethod'] == null || this.electronicCheckForm.value['paymentMethod'] == undefined) {
        this.electronicCheckForm.controls['paymentMethod'].setValidators(null);
        this.electronicCheckForm.controls['paymentMethod'].updateValueAndValidity();
        // this.nickName = null;
      }
    }
    if (!this.disabledCheckBox && this.checkBox) {
      if (this.electronicCheckForm.value['paymentMethod'] == "" || this.electronicCheckForm.value['paymentMethod'] == '' || this.electronicCheckForm.value['paymentMethod'] == null || this.electronicCheckForm.value['paymentMethod'] == undefined) {
        this.electronicCheckForm.controls['paymentMethod'].setValidators(Validators.required);
        this.electronicCheckForm.controls['paymentMethod'].updateValueAndValidity();
      }
    }
    else if (this.disabledCheckBox && this.checkBox) {
      if (this.electronicCheckForm.value['paymentMethod'] == "" || this.electronicCheckForm.value['paymentMethod'] == '' || this.electronicCheckForm.value['paymentMethod'] == null || this.electronicCheckForm.value['paymentMethod'] == undefined) {
        this.electronicCheckForm.controls['paymentMethod'].setValidators(Validators.required);
        this.electronicCheckForm.controls['paymentMethod'].updateValueAndValidity();
      }
    }

    if (this.electronicCheckForm.valid && this.agreeEnable) {
      this.loaderSubmit = true;
      ((this.detailedData?.Key == 'addMethod') || (this.detailedData?.Key == 'attachPlan')) ? this.submit() : this.saveToTemp();
    }
    else {
      this.loaderSubmit = false;
    }
  }

  saveToTemp() {
    let forDigits = this.electronicCheckForm.value.bankAccount.substr(-4);
    let tempArray = {
      AccountName: this.electronicCheckForm.value.accName,
      AccountNo: this.electronicCheckForm.value.bankAccount,
      AccountType: this.electronicCheckForm.value.accountType,
      CardType: "ACH",
      CcType: "ACH",
      Email: this.electronicCheckForm.value.EmailAddress,
      LastFourDigits: forDigits,
      Nickname: this.electronicCheckForm.value.paymentMethod,
      PaymentType: "ACH",
      RoutingTransitNo: this.electronicCheckForm.value.routingTransitNo ? ((this.electronicCheckForm.value.routingTransitNo).trim()) : null,
      SaveStatus: this.checkBox,
      agreeCondition: this.agreeEnable,
      confirmAccountNo: this.electronicCheckForm.value.confirmAccNumber,
      formattedCard: this.getACHFormatted(forDigits),
      TokenId: null,
      ccChosen: false
    }
    let payload: any = {};
    payload = {
      'BillData': this.tempData?.BillData,
      'Total': this.tempData?.Total,
      'CardData': [tempArray],
      'facilities': this.tempData?.facilities,
      'paymentProcessor': this.processorType,
    }
    if (this.detailedData) {
      if (this.detailedData?.Key == 'othersPayment')
        payload['selectedOption'] = this.tempData?.selectedOption
    }
    if (this.detailedData) {
      this.detailedData.Value = JSON.stringify(payload);
    }
    let endpoint = getApiUrl(apiList.temp.save);
    this.http.post<ApiResponse>(endpoint, this.detailedData).subscribe((data) => {
      if (data.Status == true) {
        this.updateEmailAddess();
        if (this.detailedData?.Key == 'addMethod') {
          this.utility.alert.toast({ title: 'Payment method added successfully', type: 'success' });
          this.router.navigate(['/payment-methods/configure-payment']);
        }
        else if (this.detailedData?.Key == 'attachPlan')
          this.router.navigate(['/dashboard/scheduled-payment-confirmation']);
        else if (this.detailedData?.Key == 'payNow')
          this.router.navigate(['/payment/confirm-payment']);
        else if ((this.detailedData?.Key == 'payInThirty') || (this.detailedData?.Key == 'payInHalf'))
          this.router.navigate(['/payment/confirm-pay']);
        else if (this.detailedData?.Key == 'othersPayment')
          this.router.navigate(['/payment/confirm-other-payment']);
      }
      else {
        this.utility.alert.toast({ title: data.Message, type: 'error' });
      }
    }, (err: HttpErrorResponse) => {
      console.log(err)
      this.loaderSubmit = false;
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }
  /*
    author : Nilena Alexander
    desc   : for submit
    */
  submit(): void {
    this.loaderSubmit = true;
    if (this.detailTemp == null) {
      this.payload = {};
      this.payload = {
        PaymentInfoList:
          [{
            AccountName: this.electronicCheckForm.value.accName,
            AccountNo: this.electronicCheckForm.value.bankAccount,
            AccountType: this.electronicCheckForm.value.accountType,
            CardType: "ACH",
            CcType: "ACH",
            Email: this.electronicCheckForm.value.EmailAddress,
            LastFourDigits: this.electronicCheckForm.value.bankAccount.toString().substr(-4),
            Nickname: this.electronicCheckForm.value.paymentMethod,
            PaymentType: "ACH",
            ProcessorType: this.processorType,
            RoutingTransitNo: this.electronicCheckForm.value.routingTransitNo,
            SaveStatus: this.checkBox,
            agreeCondition: this.agreeEnable,
            confirmAccountNo: this.electronicCheckForm.value.confirmAccNumber,
            OldTokenID: null,
          }],
        Transaction: {
          Email: this.electronicCheckForm.value.EmailAddress,
          InstrumentType: "ACH",
          Nickname: this.electronicCheckForm.value.paymentMethod,
          PaymentMethod: "ACH",
        }
      }
      if (this.detailedData?.Key == 'attachPlan') {
        this.makePlanObject();
      }
      this.savePayment(this.payload, 'add');
    } else {
      let payload = {};
      payload = {
        AccountName: this.electronicCheckForm.value.accName,
        AccountType: (this.detailTemp?.AccountType === 'Electronic Check') ? this.electronicCheckForm.value.accountType : this.detailTemp?.AccountType,
        CardStatus: this.detailTemp?.CardStatus,
        Email: this.electronicCheckForm.value.EmailAddress,
        IsAssociated: this.detailTemp?.IsAssociated,
        LastFourDigits: this.detailTemp?.LastFourDigits,
        Mode: 'U',
        Nickname: this.electronicCheckForm.value.paymentMethod,
        ParentTokenId: this.detailTemp?.ParentTokenId,
        PaymentType: this.detailTemp?.PaymentType,
        PeopleId: this.userInfo?.PeopleID,
        ProcessorType: this.processorType,
        RoutingTransistNumber: this.electronicCheckForm.value.routingTransitNo,
        RoutingTransitNo: (this.detailTemp?.AccountType === 'Electronic Check') ? this.electronicCheckForm.value.routingTransitNo : this.detailTemp?.RoutingTransitNo,
        SaveStatus: this.checkBox,
        Token: this.detailTemp?.Token,
        TokenId: this.detailTemp?.TokenId,
        agreeCondition: this.agreeEnable,
        formattedCard: this.detailTemp?.formattedCard,
        confirmAccountNo: this.electronicCheckForm.value.confirmAccNumber,
      };
      this.updatePayment(payload);
    }
  }
  /*
     author : Nilena Alexander
     desc   : to update Email Address
  */
  updateEmailAddess() {
    let userDetails = this.UserService.getUserInfo();
    if (!userDetails.EmailId) {
      userDetails.EmailId = this.electronicCheckForm.value.EmailAddress;
      this.UserService.setUserInfo(userDetails);
    }
  }
  /*
    author : Nilena Alexander
    desc   : to get routing number is valid or not
    */
  getACHFormatted(input: any) {
    return "XXXX XXXX XXXX " + (input ? input.substring(input.length - 4) : '');
  };
  /*
     author : Nilena Alexander
     desc   : to get routing number is valid or not
     */
  checkValidTransitNo(value: string) {
    if (this.routingTSNo && this.routingTSNo.trim()) {
      this.rotingInProgress = true;
      let endpoint = getApiUrl(apiList.paymentMethods.RoutingNumCheck) + 'routingNo=' + this.routingTSNo;
      this.http.get<ApiResponse>(endpoint).subscribe((data) => {
        if (data.Status && data.Data) {
          this.errorRouting = '';
          data.Data == true ? this.electronicCheckForm.controls[value].setValue(this.routingTSNo) : this.electronicCheckForm.controls[value].setValue(data.Data);
          this.electronicCheckForm.controls[value].setErrors({ customError: null });
          this.electronicCheckForm.controls[value].updateValueAndValidity();
          this.rotingInProgress = false;
        }
        else {
          this.errorRouting = data.Message;
          this.routingTSNo = null;
          data.Data == true ? this.electronicCheckForm.controls[value].setValue(this.routingTSNo) : this.electronicCheckForm.controls[value].setValue(data.Data);
          this.electronicCheckForm.controls[value].setErrors({ required: null });
          this.electronicCheckForm.controls[value].setErrors({ customError: true });
          this.rotingInProgress = false;
        }
      }, (err: HttpErrorResponse) => {
        console.log(err)
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
        this.rotingInProgress = false;
      })
    }
  }

}

