import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';
import { getApiUrl, apiList } from 'src/app/core/constants/api-list';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { Router, NavigationEnd } from '@angular/router';
import { timer, interval, forkJoin } from 'rxjs';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ApiResponse, Profile, TempData, CardItem, TempDataResponse, AddPaymentResponse, PayData, paymentData } from 'src/app/core/models/auth';
import { UserService } from 'src/app/auth/services/user.service';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { PatientprocessorType } from 'src/app/core/models/payment';
@Component({
  selector: 'app-submenu-payment-methods',
  templateUrl: './submenu-payment-methods.component.html',
  styleUrls: ['./submenu-payment-methods.component.css']
})
export class SubmenuPaymentMethodsComponent implements OnInit {
  enableApplePay: boolean = false;
  userInfo: Profile | null = null;
  detailedData: TempDataResponse | null = null;
  tempData: any = [];
  detailTemp: CardItem | null = null;
  PatientprocessorType: PatientprocessorType | null = null;
  enaleSettingsApple: boolean = false;
  activeClass: boolean = false;
  @Input() type: boolean = false;
  processorType: string = '';
  previousUrl: string = '';
  @Output() selectedValue = new EventEmitter();

  constructor(private http: HttpClient,
    private utility: UtilityService,
    private router: Router,
    private userService: UserService) {

  }


  ngOnInit(): void {
    window.scrollTo({ top: 0, behavior: "smooth" });
    if (this.utility.getTempData('tempId')) {
      this.userInfo = this.userService.getUserInfo();
      let id = this.utility.getTempData('tempId');
      this.GetAllApiDetails(id);
    }


    if (this.router.url === '/payment-methods/electronic-check')
      this.activeClass = true;
    else
      this.activeClass = false;
  }

  /*
   author : Nilena Alexander
   desc   : to get all data from intial ai calls
   */
  GetAllApiDetails(id: string) {
    this.utility.loader.next(true);
    let payload = {
      SettingsKey: "MerchantIdentifier,IsApplepayEnabled"
    }
    let endpoint = getApiUrl(apiList.payment.GetSettings)
    // let endpoint1 = getApiUrl(apiList.paymentMethods.getPatientProcessorType) + '?peopleID=' + this.userInfo?.PeopleID;
    let endpoint2 = getApiUrl(apiList.temp.get) + id;

    forkJoin([
      this.http.post<ApiResponse>(endpoint, payload), this.http.get<ApiResponse>(endpoint2)
    ]).subscribe((response: any[]) => {
      this.getSettings(response[0]);
      // this.getPatientProcessorType(response[1]);
      this.getData(response[1]);
      this.applePaychecker();
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      this.utility.loader.next(false);
      console.log(err)
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }
  /*
    author : Nilena Alexander
    desc   : tocheck processor type
    */
  checkProcessor() {
    if (this.tempData && this.tempData.BillData) {
      for (let i = 0; i < this.tempData.BillData.length; i++) {
        if (this.tempData.BillData[i].ProcessorType == "FD") {
          this.processorType = "FD";
        } else {
          this.processorType = "HPS";
          break;
        }
      }
      this.applePaychecker();
    }
  }

  /*
author : Nilena Alexander
desc   : to show apple pay icon
*/
  applePaychecker() {
    if ((window as any).ApplePaySession && this.processorType == "FD" && this.detailedData?.Key == CONSTANTS.PAY_MODES.NOW && this.enaleSettingsApple) {
      this.enableApplePay = true;
    } else
      this.enableApplePay = false;
  }
  /*
      author : Nilena Alexander
      desc   : check previous route is credit if crdit card it is not redirecting
      */
  goToCreditCard() {
    if (this.router.url !== '/payment-methods/credit-card') {
      this.router.navigate(['/payment-methods/credit-card'])
    }
  }
  /*
    author : Nilena Alexander
    desc   : toget tempDetails
    */
  getData(data: any) {
    if (data.Status == true) {
      this.detailedData = data.Data as TempDataResponse;
      this.tempData = JSON.parse(this.detailedData?.Value)
      this.checkProcessor();
    } else {
      this.utility.alert.toast({ title: data.Message, type: 'error' });
    }
  }
  /*
  author : Nilena Alexander
  desc   : toget settingDetails for applepay
  */
  getSettings(data: any) {
    if (data.Status == true) {
      let applePayEnabled = data.Data.find((el: any) => el.Key == 'IsApplepayEnabled');
      if (applePayEnabled && applePayEnabled.Key == 'IsApplepayEnabled' && applePayEnabled.Value == '1') {
        this.enaleSettingsApple = true;
        this.applePaychecker();
      }
    } else {
      this.enaleSettingsApple = false;
      this.utility.alert.toast({ title: data.Message, type: 'error' });
    }
  }
  /*
    author : Nilena Alexander
    desc   : toclose menu
    */
  emitValue(value: any = false) {
    this.selectedValue.emit(value);

  }
  /**
 * @ desc   : for redirecting to add payment
 * @ author  : Nilena Alexander
*/
  addPaymentMethod() {
    if (!this.activeClass) {
      this.utility.loader.next(true);
      if (this.utility.getTempData('tempId'))
        this.router.navigate(['/payment-methods/electronic-check']);
      else {
        let endpoint = getApiUrl(apiList.temp.save);
        let payload = {
          Key: CONSTANTS.PAY_MODES.ADD,
          Value: JSON.stringify({ BillData: [], Total: { balance: 0, paid: 0 } })
        };
        this.http.post<ApiResponse>(endpoint, payload).subscribe((data) => {
          if (data.Status == true) {
            this.utility.setTempData('tempId', data.Data);
            this.router.navigate(['/payment-methods/electronic-check'])
          } else {
            this.utility.loader.next(false);
            this.utility.alert.toast({ title: data.Message, type: 'error' });
          }
        }, (err: HttpErrorResponse) => {
          console.log(err);
          this.utility.loader.next(false);
          this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
        })
      }
    }
  }

 }

