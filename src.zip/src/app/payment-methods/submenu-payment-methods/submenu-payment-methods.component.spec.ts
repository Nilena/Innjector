import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubmenuPaymentMethodsComponent } from './submenu-payment-methods.component';

describe('SubmenuPaymentMethodsComponent', () => {
  let component: SubmenuPaymentMethodsComponent;
  let fixture: ComponentFixture<SubmenuPaymentMethodsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SubmenuPaymentMethodsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SubmenuPaymentMethodsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
