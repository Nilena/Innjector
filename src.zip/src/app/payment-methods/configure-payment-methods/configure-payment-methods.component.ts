import { Component, OnInit, ViewChild, ElementRef, HostListener } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { PaymentResponse, ApiResponse, PayData } from 'src/app/core/models/auth';
import { getApiUrl, apiList } from 'src/app/core/constants/api-list';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { Router } from '@angular/router';
import { CONSTANTS } from 'src/app/core/constants/constants';

@Component({
  selector: 'app-configure-payment-methods',
  templateUrl: './configure-payment-methods.component.html',
  styleUrls: ['./configure-payment-methods.component.css']
})
export class ConfigurePaymentMethodsComponent implements OnInit {
  loader: boolean = false;
  deleteBtnLoader: boolean = false;
  radioBtnLoader: boolean = false;
  scrollBottom: boolean = false;
  searchD: string = '';
  paymentData: PayData[] = [];

  @ViewChild('addPaymentMeth') addPaymentMeth! : ElementRef;

  @ViewChild('foc', { static: true }) private inputField: ElementRef | null = null;
  constructor(private http: HttpClient,
    private utility: UtilityService,
    private router: Router) {
  }

  ngOnInit(): void {
    this.utility.headerText$.next('');
    this.clearTempData()
    this.fetchPaymentData()
  }
  
  ngAfterViewInit(){
    this.setFocus();
  }

  @HostListener('keydown', ['$event'])
  clickarrowx(e: any) {
    if((e.keyCode == 32 ||e.code == 'Enter') && e.target == document.body) {
      e.preventDefault();
    }
  }
  
  /**
   * @ desc   : To implement search
   * @ author  : Nilena Alexander
 */

setFocus() {
  // this.inputField?.nativeElement.focus();
  this.addPaymentMeth?.nativeElement.focus();
}


  /**
     * @ desc   : To clear temp
     * @ author  : Nilena Alexander
     *
    */
  clearTempData(): void {
    this.utility.setTempData('tempId', null);
    let endpoint = getApiUrl(apiList.temp.clear)
    this.http.get<PaymentResponse>(endpoint).subscribe((data) => {
    }, (err: HttpErrorResponse) => {
      console.log(err);
      //this.loader = false
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }
  /**
   * @ desc   : To get details of payments
   * @ author  : Nilena Alexander
   * ClearTempTable
  */
  fetchPaymentData(): void {
    //this.loader = true
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.paymentMethods.configurePayment)
    this.http.get<PaymentResponse>(endpoint).subscribe((data) => {
      if (data.success == true) {
        this.paymentData = data.Data as PayData[];
        this.paymentData.reverse();
      }
      //this.loader = false
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      console.log(err);
      //this.loader = false
      this.utility.loader.next(false);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }

  scrollView(index: number, event: any) {
    if (index == (this.paymentData.length - 1)) {
      this.paymentData[index].scrollBottom = true;
      // var headerOffset = 300;
      // var elementPosition = event.target.getBoundingClientRect().bottom;
      // var offsetPosition = elementPosition - headerOffset;
      // // this.scroll.nativeElement.scrollIntoView();
      setTimeout(() => {
        window.scrollTo(0, document.body.scrollHeight);
      }, 50)

    } else {
      this.paymentData[index].scrollBottom = false;
    }
    event.target.scrollIntoView({
      behavior: "smooth",
      block: "center",
      inline: "start"
    });
  }



  /**
   * @ desc   : To update default and delete
   * @ author  : Nilena Alexander
  */
  update(payload: any, value: string, index: number) {
    // this.utility.alert.confirm({ title: err?.error?.message, type: 'error' });
    payload['Mode'] = value;
    let endpoint = getApiUrl(apiList.paymentMethods.updatePaymentMethod)
    if (value == 'X') {
      this.paymentData[index].deleteBtnLoader = false
      this.utility.alert.confirm({
        title: 'Confirmation',
        text: "Are you sure you want to drop this record from list?",
        type: 'warning',
        okText: 'Yes, delete it!',
        cancelText: "Don't Delete"
      }).then((res) => {
        if (res) {
          this.http.post<ApiResponse>(endpoint, payload).subscribe((data) => {
            if (data.Status == true) {
              this.utility.alert.toast({ title: 'Payment method deleted successfully', type: 'success' });
              this.fetchPaymentData()
            } else {
              this.utility.alert.toast({ title: data.Message, type: 'error' });
            }
            this.paymentData[index].deleteBtnLoader = false
            this.paymentData[index].radioBtnLoader = false
          }, (err: HttpErrorResponse) => {
            console.log(err);
            this.paymentData[index].deleteBtnLoader = false
            this.paymentData[index].radioBtnLoader = false
          })
        }
      })
    } else {
      this.http.post<ApiResponse>(endpoint, payload).subscribe((data) => {
        if (data.Status == true) {
          this.utility.alert.toast({ title: 'Payment method status updated successfully', type: 'success' });
          this.fetchPaymentData()
        } else {
          this.utility.alert.toast({ title: data.Message, type: 'error' });
        }
        this.radioBtnLoader = false
        this.deleteBtnLoader = false
      }, (err: HttpErrorResponse) => {
        console.log(err);
        this.radioBtnLoader = false
        this.deleteBtnLoader = false
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      })
    }
  }

  /**
   * @ desc   : for redirecting to add payment
   * @ author  : Nilena Alexander
  */
  addPaymentMethod() {
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.temp.save)
    let payload = {
      Key: CONSTANTS.PAY_MODES.ADD,
      Value: JSON.stringify({ BillData: [], Total: { balance: 0, paid: 0 } })
    };
    this.http.post<ApiResponse>(endpoint, payload).subscribe((data) => {

      if (data.Status == true) {
        this.utility.setTempData('tempId', data.Data);
        if (this.utility.isMobile()) {
          // if its mobile this will excecute
          this.router.navigate(['/payment-methods/electronic-check'])
        } else {
          //if desktop
          this.router.navigate(['/payment-methods/add-payment-method'])
        }



      } else {
        this.utility.loader.next(false);
        this.utility.alert.toast({ title: data.Message, type: 'error' });
      }
    }, (err: HttpErrorResponse) => {
      this.utility.loader.next(false);
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })

  }
  EditDetails(item: PayData) {
    let tempArray = {}
    tempArray = {
      Mode: 'Edit',
      BillData: [],
      CardData: {
        LastFourDigits: this.extractLastFourDigit(item.AccountNo),
        AccountName: item.AccountHolderName,
        AccountNo: item.AccountNo,
        AccountType: item.AccountType,
        Email: item.Email,
        Nickname: item.MethodName,
        RoutingTransitNo: item.RoutingTransistNumber,
        TokenId: item.TokenId,
        formattedCard: (item.AccountNo),
        PaymentType: item.PaymentType,
        IsAssociated: item.IsAssociated,
        SaveStatus: true,
        ParentTokenId: item.ParentTokenId,
        ProcessorType: item.ProcessorType,
        Token: item.Token,
        CardStatus: item.CardStatus
      },
      Total: { balance: 0, paid: 0 }
    }

    let endpoint = getApiUrl(apiList.temp.save)
    let payload = {
      Key: CONSTANTS.PAY_MODES.ADD,
      Value: JSON.stringify(tempArray)
    };
    this.http.post<ApiResponse>(endpoint, payload).subscribe((data) => {
      if (data.Status == true) {
        this.utility.setTempData('tempId', data.Data);
      } else {
        this.utility.alert.toast({ title: data.Message, type: 'error' });
      }
      if(this.utility.isMobile()){
        this.router.navigate(['/payment-methods/electronic-check'])
      }else{
        this.router.navigate(['/payment-methods/add-payment-method'])
      }
     
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })

  }
  /**
    * @ desc   : for redirecting to edit payment
    * @ author  : Nilena Alexander
   */
  editPaymentmMethod(item: PayData) {
    if (item.IsAssociated) {
      this.utility.alert.confirm({
        title: 'Confirmation',
        text: "The payment method is associated with a payment plan. Modifying the payment method details will also update the payment plan payment method details.Do you want to continue?",
        type: 'warning',
        okText: 'Continue',
        cancelText: 'Cancel'
      }).then((res) => {
        if (res) {
          this.EditDetails(item);
        }
      })

    } else
      this.EditDetails(item);
  }

  /**
    * @ desc   : forextracting Last four digits
    * @ author  : Nilena Alexander
   */
  extractLastFourDigit(value: string) {
    return value.toString().substr(-4);
  }


}
