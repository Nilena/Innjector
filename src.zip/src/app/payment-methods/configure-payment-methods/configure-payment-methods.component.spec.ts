import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigurePaymentMethodsComponent } from './configure-payment-methods.component';

describe('ConfigurePaymentMethodsComponent', () => {
  let component: ConfigurePaymentMethodsComponent;
  let fixture: ComponentFixture<ConfigurePaymentMethodsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfigurePaymentMethodsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigurePaymentMethodsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
