import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, NgZone, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { forkJoin } from 'rxjs';
import { UserService } from 'src/app/auth/services/user.service';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { PaymentService } from 'src/app/payment/services/payment.service';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { AlertType } from 'src/app/core/models/utility';

@Component({
  selector: 'app-add-credit-card',
  templateUrl: './add-credit-card.component.html',
  styleUrls: ['./add-credit-card.component.css']
})
export class AddCreditCardComponent implements OnInit {

  private ccChosen: any = false;
  private paymentACH: any = {};
  public paymentCC: any = {};
  private common: any = {};
  private applePay: any = {};
  private tempKey: any = {};
  private paymentKey: any = null;
  private danger: any = "error";
  private success: any = "success";
  private tempData: any = null;
  private jsonDATA: any = null;
  private paymentModes: any = {
    CC: "CC",
    ACH: "ACH",
    APP: "APP"
  };
  public termsAndCondition: any = null;
  private userDetails: any;
  private accountInfo: any;
  private today: any;
  private dateToday: any;
  private data: any = {};
  private processor: any;
  private isMulti: boolean = false;
  private paymentType: string = 'CC';
  private loader(state: boolean) {
    // this.utility.loader.next(state);
  }
  public showiFrameCC: boolean = false;

  constructor(
    private router: Router,
    private http: HttpClient,
    private userService: UserService,
    private utility: UtilityService,
    private paymentService: PaymentService,
    private sanitizer: DomSanitizer,
    private ngZone: NgZone
  ) {

  }

  ngOnInit(): void {
    let tempId: any = this.utility.getTempData('tempId');
    this.getTempData(tempId);
  }

  /**
     * @desc:  
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
  alert = (message: string, mode: AlertType) => {
    this.utility.alert.toast({ type: mode, title: message });
  };

  agreeTermsAndCondition(status: any) {
    if (status) {
      this.showTermsAndCondition = false;
      this.init();
    } else {
      this.showTermsAndCondition = false;
      history.back();
    }
  }
  public showTermsAndCondition: boolean = false;
  public getTempData(tempId: any) {
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.temp.get + tempId);
    let tc_endpoint = getApiUrl(apiList.paymentMethods.GetTermsAndConditionForPayment);
    forkJoin([
      this.http.get<any>(endpoint),
      this.http.get<any>(tc_endpoint)
    ]).subscribe((response) => {
      if (response[0].Status == true) {
        this.data = response[0].Data;
        this.paymentKey = response[0].Data.Key;
        this.data.Value = JSON.parse(this.data.Value);
        if (response[1].Data) {
          this.termsAndCondition = response[1].Data;
          this.showTermsAndCondition = true;
        } else {
          this.init();
        }
      } else {
        this.utility.alert.toast({ title: response[0].Message, type: 'error' });
      }
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.utility.loader.next(false);
    })
  }

  private init() {
    this.common.callStatus = !1;
    this.common.extractLastFourDigit = (input: any) => {
      return (input ? input.substring(input.length - 4) : '');
    };

    /**
     * @desc:
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    this.common.setDefaultTab = () => {
      this.common.tabName = this.paymentModes.CC;
      // setTimeout( () =>{
      //   $('#Account').focus()
      // }, 50);
    };


    /**
     * @desc:
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    this.common.getCreditCardFormatted = (input: any) => {
      return "XXXX XXXX XXXX " + input;
    };


    /**
     * @desc:
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    this.common.getACHFormatted = (input: any) => {
      return "XXXX XXXX XXXX " + (input ? input.substring(input.length - 4) : '');
    };

    /**
     * @desc  : 
     * @name  : 
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    this.common.back = () => {
      if (this.ccChosen) {
        window.history.go(-2);
      } else {
        window.history.back();
      }
    };

    /**
     * @desc  : 
     * @name  : 
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    this.common.submitNavigation = (data: any) => {
      this.ngZone.run(() => {
        CONSTANTS.PAY_MODES.ADD != this.paymentKey ?
          CONSTANTS.PAY_MODES.THIRTY == this.paymentKey ? this.router.navigate(['/payment/confirm-pay']) :
            CONSTANTS.PAY_MODES.OTHERS == this.paymentKey ? this.router.navigate(['/payment/confirm-other-payment']) :
              CONSTANTS.PAY_MODES.HALF == this.paymentKey ? this.router.navigate(['/payment/confirm-pay']) :
                CONSTANTS.PAY_MODES.ATTACH == this.paymentKey ? this.router.navigate(['/dashboard/scheduled-payment-confirmation']) :
                  CONSTANTS.PAY_MODES.NOW == this.paymentKey && this.router.navigate(['/payment/confirm-payment']) :
          this.router.navigate(['/payment-methods/configure-payment'])
      })
    };

    /**
     * @desc: loader 
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    this.common.loader = (t: any) => {
      this.loader(t);
      // t && (this.common.callStatus = t),
      //   $timeout(() => {
      //     this.common.callStatus = t
      //   }, 1000);
    };


    this.common.gtmObjectFD = (arg: any) => {
      let data: any = {};
      data.event_title = "FD Credit Card";
      data.data_object = {
        item_selected: arg
      };
      this.common.gtmFinal(data);
    }


    /**
     * @desc: creating objects for gooogle tag manager
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    this.common.gtmObjectPlan = (arg: any) => {
      let data: any = {};
      data.event_title = "Payment Option";
      data.data_object = {
        item_selected: arg
      };
      this.common.gtmFinal(data);
    }

    /**
     * @desc: fire event to google tag manager config
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    this.common.gtmFinal = (data: any) => {
      data.event_interactive = true;
      data.event_logged_in = true;
      data.event_category = "Payment Plans";
      data.event_registration_type = this.userDetails ? (this.userDetails.IsGuest ? 'guest' : this.userDetails.FromMHO ? 'mho' : 'epay') : null;
      data.event_facility = this.userDetails ? this.userDetails.ClientCode : null;
      data.event_user_id = this.userDetails ? this.userDetails.UserID : null;
      data.event_user_type = 'patient';
      data.event_success = true;
      data.event_session_id = this.userDetails ? this.userDetails.RequestToken : null;
      // $rootthis.$broadcast(CONSTANTS.EVENTS.TRACK_ACTION, data); EVENT-EMIT
    }


    /**
     * @desc: Check payment processor
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    this.common.checkProcessor = () => {
      return new Promise((resolve, reject) => {
        let peopleID = this.userDetails.PeopleID;
        if (this.paymentKey == CONSTANTS.PAY_MODES.ADD) {
          if ((this.jsonDATA?.Mode || '').toLocaleLowerCase() == "edit") {
            if (this.jsonDATA?.CardData.ProcessorType == "FD") {
              this.processor = "FD";
              this.loader(!1);
              resolve({});
            } else {
              if (this.jsonDATA?.CardData.AccountType == "Electronic Check" && this.jsonDATA?.CardData.IsAssociated) {

                this.paymentService.getProcessorWithToken(this.jsonDATA?.CardData.ParentTokenId, (response: any) => {
                  this.common.tokenProcessor = response.Data;
                  if (this.common.tokenProcessor == "FD") {
                    this.processor = "FD";
                    resolve({});
                  } else {
                    this.processor = "HPS";
                    this.common.getCCUrl().then((res: any) => {
                      resolve({});
                    })
                  }
                })


              } else {

                this.paymentService.getProcessorType(peopleID, (response: any) => {
                  let processorData = response.Data.ProcessorTypes;
                  let mercData = response.Data.MerchantIds;

                  this.common.multiArray = mercData.split(",");

                  if (processorData) {
                    for (let i = 0; i < processorData.length; i++) {
                      if (processorData[i] == "HPS") {
                        this.processor = "HPS";
                        this.common.getCCUrl()
                        break;
                      } else {
                        this.processor = "FD";
                      }
                    }
                    resolve({});
                  }
                });
                // this.processor = "HPS";
                // this.common.getCCUrl();
              }

            }
          } else {
            this.paymentService.getProcessorType(peopleID, (response: any) => {
              let processorData = response.Data.ProcessorTypes;
              let mercData = response.Data.MerchantIds;

              this.common.multiArray = mercData.split(",");

              if (processorData) {
                for (let i = 0; i < processorData.length; i++) {
                  if (processorData[i] == "HPS") {
                    this.processor = "HPS";
                    this.common.getCCUrl();
                    break;
                  } else {
                    this.processor = "FD";
                  }
                }
                resolve({});
              }
            });
          }
        } else if (this.paymentKey == CONSTANTS.PAY_MODES.ATTACH) {

          if (this.jsonDATA?.ProcessorType == "FD") {
            this.processor = "FD";
          } else {
            this.processor = "HPS";
            this.common.getCCUrl();
          }
          resolve({});
        } else {
          for (let i = 0; i < this.jsonDATA?.BillData.length; i++) {
            if (this.jsonDATA?.BillData[i].ProcessorType == "FD") {
              this.processor = "FD";
            } else {
              this.processor = "HPS";
              this.common.getCCUrl();
              break;
            }
          }
          resolve({});
        }
      })
    }


    /**
     * @desc: check is multi merchant or not
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    this.common.multiChecker = () => {
      return new Promise((resolve, reject) => {
        let peopleID = this.userDetails.PeopleID;
        this.paymentService.getProcessorType(peopleID, (response: any) => {
          let processorData = response.Data.ProcessorTypes;
          this.common.proData = processorData;
          let merData = response.Data.MerchantIds;

          this.common.multiArray = merData.split(",");
          resolve({});
        });
        if (this.jsonDATA?.BillData?.length > 0) {
          let mulArray = [];
          let exArray = [];

          for (let i = 0; i < this.jsonDATA?.BillData?.length; i++) {
            if (this.jsonDATA?.BillData[i].PaymentAmount > 0) {
              mulArray.push(this.jsonDATA?.BillData[i].MerchantId);

            }

          }


          function arrayUnique(array: any) {
            let a = array.concat();
            for (let i = 0; i < a.length; ++i) {
              for (let j = i + 1; j < a.length; ++j) {
                if (a[i] === a[j])
                  a.splice(j--, 1);
              }
            }

            return a;
          }

          // let exArray = arrayUnique(mulArray);
          // this.common.multiArray = exArray;

          if (mulArray && mulArray.length == 1) {
            // if(mulArray[0]="FD"){
            //     this.processor="FD";
            // }

            this.isMulti = false;
          } else {
            this.isMulti = true;
          }
        }
        // resolve({}); original
      })
    }

    this.common.applePaychecker = () => {

      if ((window as any).ApplePaySession && this.processor == "FD" && this.paymentKey == CONSTANTS.PAY_MODES.NOW) {
        this.common.ApplepayEnabled = true;
      } else {
        this.common.ApplepayEnabled = false;
      }

    }

    /**
     * @desc: get HPS Popup URL 
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */

    this.common.getCCUrl = () => {
      return new Promise((resolve, reject) => {
        let data = this.userService.getUserInfo();
        let tempRecords = this.jsonDATA ? this.jsonDATA : {};
        tempRecords = tempRecords ? tempRecords.BillData : [];
        let param = {
          email: data && data.EmailId ? data.EmailId : data.UserHeader.Email,
          paymentPlan: (
            this.data.Key == CONSTANTS.PAY_MODES.HALF ||
            this.data.Key == CONSTANTS.PAY_MODES.OTHERS ||
            this.data.Key == CONSTANTS.PAY_MODES.ATTACH ||
            this.data.Key == CONSTANTS.PAY_MODES.THIRTY) ? "Y" : "N",
          userType: data && data.IsGuest ? "guest" : "register",
          /*-servicelocationId: "00147", tempRecords.length > 0 ? tempRecords[0].FacilityID : 1,*/
          pageType: this.data.Key == CONSTANTS.PAY_MODES.ADD ? "APM" : "AAC",
          referenceUrl: location.href,
          ClientCode: data && data.ClientCode,
          peopleId: data && data.PeopleID,
          source: 'PATIENT'
        };
        this.paymentService.getCCiframeUrl(param, (resData: any) => {
          // this.ccUrl.Data = resData.Data;
          this.loader(!1);
          this.paymentCC.ccFrameURL = this.sanitizer.bypassSecurityTrustResourceUrl(resData.Data)
          let item = { request: param, response: resData };
          let details = {
            module: 'CC Call PageLoad',
            submodule: 'HPS CC URL',
            button: null,
            message: resData.Message,
            data: item && JSON.stringify(item)
          };
          resolve({});
        })
      })
    }


    this.common.planChecker = () => {
      this.common.paymentPlan = (
        this.data.Key == CONSTANTS.PAY_MODES.HALF ||
        this.data.Key == CONSTANTS.PAY_MODES.OTHERS ||
        this.data.Key == CONSTANTS.PAY_MODES.ATTACH ||
        this.data.Key == CONSTANTS.PAY_MODES.THIRTY) ? true : false;

    }
    /**
     * @desc: init 
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    this.common.init = async (t: any) => {
      this.userDetails = this.userService.getUserInfo();
      this.paymentKey = this.data ? this.data.Key : null;
      this.tempData = this.data;
      this.accountInfo = this.userService.getUserInfo();
      this.tempKey = this.utility.parseJSON(atob(this.utility.getTempData(CONSTANTS.SESSION.PAYMENT_TEMP_ID))) || null;
      this.jsonDATA = this.tempData.Value;
      this.today = new Date();
      this.dateToday = this.today.setDate(this.today.getDate()), "MM/dd/yyyy";
      const multiCheckerData = await this.common.multiChecker();
      const checkProcessorData = await this.common.checkProcessor();
      this.common.applePaychecker(checkProcessorData);
      this.common.planChecker();
      this.common.appleShow = false;

      this.common.setDefaultTab();
      this.paymentCCInit(this.paymentCC);
    }
    this.common.init();
  }

  /**
   * @desc  : CC process
   * @name  : paymentCC
   * @author: Arun Lalithambaran
   * @source: HCA Patient portal - paymentMethodAdd.js
   */
  private paymentCCInit(paymentCC: any) {

    paymentCC.ccForm = {};
    paymentCC.common = this.common;
    paymentCC.saveCardObject = {};
    paymentCC.updatedNickName = null;
    paymentCC.ccFrameURL = null;
    paymentCC.paymentWebPageURL = null;

    /**
     * @desc  : 
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    paymentCC.isJSON = (data: any) => {
      let isJson = false;
      try {
        let json = this.utility.parseJSON(data);
        isJson = typeof json === 'object';
      } catch (ex) { }
      return isJson;
    };


    /**
     * @desc  : 
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    paymentCC.externalBind = (data: any) => {
      // let controller = Ce.__container__.lookup("controller:CeRegistrationSubmit");
      // let boundSend = controller.send.bind(controller);
      // boundSend('hpsCallback', data);
    };

    /**
     * @desc  : create CC payment object
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    paymentCC.makeCCPaymentObject = (data: any) => {
      let tempArray = [];

      for (let i = 0; i < data.tokenDetails.length; i++) {
        paymentCC.ccForm.LastFourDigits = data.fourdigitsOfCard;
        paymentCC.ccForm.ExternalToken = data.tokenDetails[i].paymentToken;
        paymentCC.ccForm.MerchantId = data.tokenDetails[i].serviceLocation;
        paymentCC.ccForm.Email = data.emailId;
        paymentCC.ccForm.CardType = data.cardType;
        paymentCC.ccForm.ProcessorType = this.processor;
        paymentCC.ccForm.CcType = data.cardType;
        paymentCC.ccForm.PaymentType = this.paymentModes.CC;
        paymentCC.ccForm.PaymentMethod = this.paymentModes.CC;
        paymentCC.ccForm.SaveStatus = data.isPaymentmethodtosave;
        paymentCC.ccForm.Nickname = paymentCC.updatedNickName ? paymentCC.updatedNickName : paymentCC.setCCMethodName();
        paymentCC.ccForm.formattedCard = paymentCC.common.getCreditCardFormatted(data.fourdigitsOfCard);
        paymentCC.ccForm.ccChosen = true;
        tempArray.push(this.utility.deepCopy(paymentCC.ccForm))
      }

      this.jsonDATA.CardData = tempArray;
      this.jsonDATA.paymentProcessor = this.processor;
      this.tempData.Value = JSON.stringify(this.jsonDATA);
    };

    /**
     * @desc  : make db object to save data
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    paymentCC.makePlanObject = () => {
      paymentCC.ccForm.PlanHeaderID = this.jsonDATA ? this.jsonDATA?.HeaderID : null;
      paymentCC.ccForm.SaveType = "Plan";
    };

    /**
     * @desc  :make card save object
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    paymentCC.makeCardObject = (data: any) => {
      paymentCC.ccForm.Email = data.emailId;
      paymentCC.ccForm.CardType = data.cardType;
      paymentCC.ccForm.SaveStatus = data.isPaymentmethodtosave;
      paymentCC.ccForm.CcType = data.cardType;
      paymentCC.ccForm.OldTokenId = this.jsonDATA ? this.jsonDATA?.PaymentTokenId : null;
      this.paymentKey == CONSTANTS.PAY_MODES.ATTACH && paymentCC.makePlanObject();
      paymentCC.saveCardObject = {
        PaymentInfoList: paymentCC.makePaymentInfoObject(),
        Transaction: paymentCC.makeTransactionObject(),
        ProcessorType: this.processor,
        OrderId: paymentCC.orderId && paymentCC.orderId ? paymentCC.orderId : ''
      };
    };



    paymentCC.makePaymentInfoObject = () => {
      let data = [];
      for (let i = 0; i < paymentCC.marchntObj.tokenDetails.length; i++) {
        let details: any = {};
        details.MerchantId = paymentCC.marchntObj.tokenDetails[i].serviceLocation;
        details.LastFourDigits = paymentCC.marchntObj.fourdigitsOfCard ? paymentCC.marchntObj.fourdigitsOfCard : null;
        details.AccountNo = 'xxxx xxxx xxxx xxxx';
        details.Email = paymentCC.marchntObj.emailId;
        details.InstrumentType = paymentCC.marchntObj.cardType;
        details.PaymentType = "CC";
        details.Status = paymentCC.marchntObj.status;
        details.SaveStatus = paymentCC.marchntObj.isPaymentmethodtosave;
        details.MethodName = paymentCC.updatedNickName ? paymentCC.updatedNickName : null;
        details.ExternalToken = paymentCC.marchntObj.tokenDetails[i].paymentToken;
        details.PlanHeaderID = paymentCC.ccForm.PlanHeaderID;
        details.ProcessorType = this.processor;
        details.CardType = paymentCC.ccForm.CardType;
        details.SaveType = paymentCC.ccForm.SaveType;
        details.OldTokenId = paymentCC.ccForm.OldTokenId;
        data.push(details);
      }
      return data;
    };

    /**
     * @desc  : make transaction object
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    paymentCC.makeTransactionObject = () => {
      return {
        Email: paymentCC.ccForm.Email,
        InstrumentType: paymentCC.ccForm.CcType,
        Nickname: paymentCC.updatedNickName ? paymentCC.updatedNickName : paymentCC.setCCMethodName(),
        PaymentMethod: this.paymentModes.CC
      };
    };

    /**
     * @desc:create CC method name
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    paymentCC.setCCMethodName = () => {
      return this.accountInfo.UserHeader.LastName + "-CC-" + paymentCC.ccForm.LastFourDigits
    };


    /**
     * @desc: CC payment submit
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    paymentCC.ccPaymentSubmit = (data: any) => {
      data.isPaymentmethodtosave ? paymentCC.CheckNickName(data) : paymentCC.savePayment(data);
    };

    /**
     * @desc: CC card save
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    paymentCC.ccMethodSave = (data: any) => {
      paymentCC.marchntObj = this.utility.deepCopy(data);
      data.isPaymentmethodtosave ? paymentCC.CheckNickName(data) : paymentCC.saveCards(data);
    };

    /**
     * @desc:
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    paymentCC.saveCards = (details: any) => {
      this.ngZone.run(() => {
        paymentCC.common.loader(!0);
        paymentCC.makeCardObject(details);
        paymentCC.tempdata = this.data.Value;
        if (paymentCC.tempdata) {
          paymentCC.tempdata.CardData = paymentCC.tempdata.CardData && paymentCC.tempdata.CardData[0] ? paymentCC.tempdata.CardData[0] : paymentCC.tempdata.CardData ? (paymentCC.tempdata.CardData.length == 0 ? {} : paymentCC.tempdata.CardData) : {};
          paymentCC.tempdata.CardData.Mode = ("edit" == (this.jsonDATA?.Mode || '').toLocaleLowerCase()) ? "U" : 'D', //mode X changed to U HCA-1202
            paymentCC.tempdata.CardData.PeopleId = this.userDetails.PeopleID,
            paymentCC.tempdata.CardData.CcType = "CC";
          paymentCC.tempdata.CardData.PaymentType = "CC";
          this.paymentService.updateMethodDetails(paymentCC.tempdata.CardData, (response: any) => {
            if (response.Status) {
              (this.paymentService.saveCardDetails(paymentCC.saveCardObject, (response: any) => {
                let data: any = {};
                if (response.Status) {


                  paymentCC.updateCookie();
                  data.Mode = ("edit" == (this.jsonDATA?.Mode || '').toLocaleLowerCase()) ? 'PMU' : 'D',
                    data.IsDefault = paymentCC.tempdata && paymentCC.tempdata.CardData && paymentCC.tempdata.CardData.IsDefault,
                    data.TokenId = paymentCC.tempdata && paymentCC.tempdata.CardData && paymentCC.tempdata.CardData.TokenId,
                    data.ParentTokenId = paymentCC.tempdata && paymentCC.tempdata.CardData && paymentCC.tempdata.CardData.TokenId,
                    data.NewTokenId = response.Data && parseInt(response.Data.attribute2),
                    this.paymentService.updateMethodDetails(data, (response: any) => {
                      this.loader(!1);
                      if (response.Status) {
                        if (paymentCC.tempdata.CardData.Mode == "D") {
                          this.alert("Payment method added successfully ", 'success');
                          // this.utility.alert.confirm({
                          //   title: 'Payment method added successfully',
                          //   text: '',
                          //   type: 'success',
                          //   okText: 'Ok',
                          //   hideCancelButton: true
                          // })
                          this.common.submitNavigation()
                        } else {
                          this.alert("Payment method updated successfully ", 'success');
                          // this.utility.alert.confirm({
                          //   title: 'Payment method updated successfully',
                          //   text: '',
                          //   type: 'success',
                          //   okText: 'Ok',
                          //   hideCancelButton: true
                          // })
                          this.common.submitNavigation()
                        }
                      } else {
                        if (paymentCC.tempdata.CardData.Mode == "D") {
                          this.alert("payment method adding failed", 'error')
                        } else {
                          this.alert("payment method updation failed", 'error');
                        }
                      }
                    })
                } else {
                  this.loader(!1);
                  this.alert("payment method adding failed", 'error');
                  paymentCC.tempdata.CardData.Mode = paymentCC.tempdata.CardData.CardStatus;
                  this.paymentService.updateMethodDetails(paymentCC.tempdata.CardData, (response: any) => {

                  });
                  paymentCC.common.loader(!1);
                }
              }))
            } else {
              this.loader(!1);
              paymentCC.common.loader(!1);
              this.alert("payment method adding failed", 'error');
            }

          });
        }
      })
    };



    paymentCC.updateCookie = () => {
      // paymentACH.updateCookie =  () =>{
      if (this.paymentKey == CONSTANTS.PAY_MODES.ATTACH) {
        let userDetails = this.userService.getUserInfo();
        userDetails.EmailId = paymentCC.ccForm.Email;

        this.userService.setUserInfo(userDetails);
      }
    }
    /**
     * @desc:
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    paymentCC.savePayment = (data: any) => {
      paymentCC.common.loader(!0);
      paymentCC.makeCCPaymentObject(data);
      paymentCC.ccForm.PaymentType = this.paymentModes.CC, this.paymentService.updateTempBillDetails(this.tempData, (response: any) => {
        paymentCC.common.loader(!1);
        if (response.Status) {
          paymentCC.manageCCForm(false);
          paymentCC.common.submitNavigation(response);
        } else {
          this.alert(response.Message, 'error');
        }
      });
    };

    /**
     * @desc: Check the nick name
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    paymentCC.CheckNickName = (data: any) => {
      let name = this.accountInfo.UserHeader.LastName + "-CC-" + data.fourdigitsOfCard;
      paymentCC.updatedNickName = null;
      this.paymentService.CheckCCNickName(name, (response: any) => {
        if (response.Status) {
          paymentCC.updatedNickName = response.Data;
          if (this.paymentKey == CONSTANTS.PAY_MODES.ADD || this.paymentKey == CONSTANTS.PAY_MODES.ATTACH)
            paymentCC.saveCards(data)
          else
            paymentCC.savePayment(data)
        } else {
          this.alert(response.Message, 'error');
        }
      });
    };

    /**
     * @desc  : receive CC data
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    paymentCC.listenCCSubmit = (e: any) => {
      this.loader(!0);
      let x = this.utility.getTempData('cc-patient-back');
      this.utility.setTempData('cc-patient-back', ++x);
      try {
        if (e.data) {
          let json = (typeof (e.data) == 'string') ? this.utility.parseJSON(e.data) : e.data;
          if (json.eventType && json.eventType.toLowerCase() == "confirmation") {
            this.common.gtmObjectPlan('submit');
            paymentCC.writeLog('continue', json);
            if (json.status) {
              paymentCC.manageCCForm(false);
              paymentCC.validateEmail(json);
            } else {
              this.alert(json.reason, 'error');
              this.loader(!1);
            }
          } else if (json.eventType && json.eventType.toLowerCase() == "cancellation") {
            this.common.gtmObjectPlan('cancel');
            paymentCC.writeLog('cancel', json);
            paymentCC.manageCCForm(false);
            this.ccChosen = false;
            this.common.tabName = 'ACH';
            paymentCC.common.setDefaultTab();
            window.history.go(-2);
            this.loader(!1);
          }
        };
      } catch (e) {
        this.loader(!1);
      }
    };

    paymentCC.writeLog = (btn: any, item: any) => {
      let details = {
        module: 'Payment-method add',
        submodule: 'Credit Card',
        button: btn,
        data: item && JSON.stringify(item)
      };
      // commonService.logRequest(details, (response: any) => {
      // })
    }

    paymentCC.validateEmail = (json: any) => {
      this.loader(!0);
      let reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
      if (this.paymentKey == CONSTANTS.PAY_MODES.THIRTY || this.paymentKey == CONSTANTS.PAY_MODES.OTHERS || this.paymentKey == CONSTANTS.PAY_MODES.HALF || this.paymentKey == CONSTANTS.PAY_MODES.ATTACH || this.paymentKey == CONSTANTS.PAY_MODES.ADD) {
        json.isPaymentmethodtosave = true;
      }
      if (this.paymentKey == CONSTANTS.PAY_MODES.NOW) {
        if (reg.test(json.emailId) == false) {
          json.emailId = null;
        }
        (this.paymentKey == CONSTANTS.PAY_MODES.ADD || this.paymentKey == CONSTANTS.PAY_MODES.ATTACH) ? paymentCC.ccMethodSave(json) : paymentCC.ccPaymentSubmit(json)

      } else {
        if (reg.test(json.emailId) == false) {
          this.alert('Please enter a valid email', 'error')
        } else {
          (this.paymentKey == CONSTANTS.PAY_MODES.ADD || this.paymentKey == CONSTANTS.PAY_MODES.ATTACH) ? paymentCC.ccMethodSave(json) : paymentCC.ccPaymentSubmit(json)
        }
      }
      this.loader(!1);
    }


    function S4() {
      return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    }

    /**
     * @desc  : Add Log for CC mangement
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */

    paymentCC.CCLog = (logInfo: any) => {

      this.loader(!0);
      // commonService.logRequest(logInfo, (response: any) => {
      // })
      this.loader(!1);
    }


    let paymentTypeCheck = () => {
      if (this.paymentKey == CONSTANTS.PAY_MODES.NOW) {

        paymentCC.payType = 'paynow'

      } else if (this.paymentKey == (CONSTANTS.PAY_MODES.ADD || CONSTANTS.PAY_MODES.EDIT)) {

        paymentCC.payType = 'addnew';

      } else {

        paymentCC.payType = 'plan'
      }
    }


    /**
     * @desc  : manage CC popup
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    paymentCC.manageCCForm = (status: any) => {

      if (status == true) {


        let details = {
          module: 'Credit Card',
          submodule: 'Popup selection',
          button: null,
          message: "Click on Credit Card Option",
          data: "Processor Type is" + this.processor
        };
        paymentCC.CCLog(details);
      }
      let paymentPushData: any = [];
      let erMsg;
      let guid = (S4() + S4() + "-" + S4() + "-4" + S4().substr(0, 3) + "-" + S4() + "-" + S4() + S4() + S4()).toLowerCase();
      if (this.processor == "FD") {
        let data: any = {};
        this.loader(!0);
        if (status) {
          this.paymentService.getLpgToken(data, (response: any) => {
            response.Data && this.utility.setTempData(CONSTANTS.SESSION.LPG_TOKEN, response.Data);
            let isGuestUser = this.accountInfo.IsGuest;
            let paymentMethod = this.common.paymentPlan;
            paymentTypeCheck();
            let arr = this.common.multiArray;
            if (arr?.length > 0) {
              for (let i = 0; i < arr.length; i++) {
                let paymentMeth = {
                  "paymentMode": "CC",
                  "tokenId": "",
                  "clientGroupCode": this.accountInfo.UserHeader.MasterClientCode,
                  "accountNo": null,
                  "externalToken": null,
                  "cID": null,
                  "country": null,
                  "state": null,
                  "city": null,
                  "zipCode": "11747",
                  "expDate": null,
                  "ccType": null,
                  "accountName": null,
                  "achAccountType": null,
                  "routingTransitNo": null,
                  "achVerificationFlag": null,
                  "attribute1": "",
                  "attribute2": null,
                  "attribute3": arr[i],
                  "OptionalCardDetails": null,
                  "merchantGroup": arr[i],
                  "operatorName": null
                }
                paymentPushData.push(paymentMeth);
              }

            } else {
              let paymentMeth = {
                "paymentMode": "CC",
                "tokenId": "",
                "clientGroupCode": this.accountInfo.UserHeader.MasterClientCode,
                "accountNo": null,
                "externalToken": null,
                "cID": null,
                "country": null,
                "state": null,
                "city": null,
                "zipCode": "11747",
                "expDate": null,
                "ccType": null,
                "accountName": null,
                "achAccountType": null,
                "routingTransitNo": null,
                "achVerificationFlag": null,
                "attribute1": "",
                "attribute2": null,
                "attribute3": null,
                "OptionalCardDetails": null,
                "merchantGroup": null,
                "operatorName": null
              }
              paymentPushData.push(paymentMeth);
            }
            if (status) {
              this.loader(!0);

              let token = this.utility.getTempData(CONSTANTS.SESSION.LPG_TOKEN);
              if (token && token.access_token && token.access_token != "") {
                let firstParam = {
                  "HeaderData": {
                    "queueToken": guid,
                    "actionName": "Save",
                    "profile": "HCA_FD",
                    "hpsEnableStatus": false,
                    "emvEnableStatus": false,
                    "PaymentAmount": null,
                    "EnableSwiper": false,
                    "savePayment": paymentMethod,
                    "DefaultEmail": this.userService.getUserInfo()?.EmailId,
                    "serviceProviderName": "PaymentEngine",
                    "isGuest": isGuestUser,
                    "UiTheme": "cl-hca-mob"
                  },
                  "BodyData": {
                    "TransactionData": {
                      "sourceTxId": null,
                      "txId": 0,
                      "operatorName": this.accountInfo.ProfileName,
                      "ipAddress": null,
                      "busDate": this.dateToday,
                      "clientGroupCode": this.accountInfo.UserHeader.MasterClientCode,
                      "isProvider": 'N',
                      "providerUser": null,
                      "attribute1": null,
                      "attribute2": null,
                      "attribute3": null,
                      "txOrigin": null,
                      "TotalAmount": 0,
                      "PaymentOption": paymentCC.payType
                    },
                    "PaymentData": [],
                    "PaymentMethodData": paymentPushData,
                    "FrequentlyUsedMethods": null,
                    "TermsAndConditions": null,
                    "CaptureData": null
                  }
                };
                let authParam = {
                  "Autherization": token.access_token,
                  "FormType": "CC_HPS_Form",
                  "ProfileId": token.profileid,
                  "encToken": encodeURIComponent(token.access_token_encrypted),
                  "lpgURL": token.LpgCCUrl
                }

                let logDetails = {
                  data1: firstParam,
                  data2: authParam
                }

                let details11 = {
                  module: 'Credit Card',
                  submodule: 'FD Patient',
                  button: null,
                  message: "LPG popup request",
                  data: JSON.stringify(logDetails)
                };
                paymentCC.CCLog(details11);

                this.common.gtmObjectFD('open');
                this.loader(!1);
                (window as any).LPG.Open(firstParam, authParam, (callback: any) => {
                  paymentCC.common.loader(!0);
                  paymentCC.lpgData(callback);
                });
              } else {
                erMsg = "Access Denied";

                let details10 = {
                  module: 'Credit Card',
                  submodule: 'FD Patient',
                  button: null,
                  message: 'LPG Token Missing',
                  data: JSON.stringify(token)
                };
                this.loader(!1);
                paymentCC.CCLog(details10);
                this.alert(erMsg, 'error');
                this.common.tabName = 'ACH';
                this.ccChosen = false;

              }
            }
          });
        }
      } else {
        paymentCC.paymentWebPageURL = null;
        if (status) {
          paymentCC.paymentWebPageURL = this.utility.deepCopy(paymentCC.ccFrameURL);
          this.showiFrameCC = true;
        }
        // $timeout(() => {
        //   status && (paymentCC.paymentWebPageURL = angular.copy(paymentCC.ccFrameURL));
        //   $("#iframeCC").modal(status ? "show" : "hide");
        // }, 500)
      }
    };
    /**
     * @desc  : manage lpg response
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */

    paymentCC.lpgData = (lpData: any) => {
      let erMsg;
      // this.loader(!0);
      let details = {
        module: 'Credit Card',
        submodule: 'FD Credit Card',
        button: null,
        message: "Receving Credit Card details",
        data: JSON.stringify(lpData)
      };
      paymentCC.CCLog(details);

      if (lpData.LPGInfo.eventType == "Confirmation") {
        this.common.gtmObjectFD('submit');
        if (lpData && lpData.ServiceProviderInfo && lpData.ServiceProviderInfo.BodyData && lpData.ServiceProviderInfo.BodyData.AccDetails) {
          let tokenDetails = [];
          let originalEvent;
          let data;
          let tokenData = [];
          paymentCC.orderId = lpData.LPGInfo.OrderId;
          for (let i = 0; i < lpData.ServiceProviderInfo.BodyData.AccDetails.length; i++) {
            if (lpData.ServiceProviderInfo.BodyData.AccDetails[i].tokenId) {
              let tokenArrange = {
                serviceLocation: lpData.ServiceProviderInfo.BodyData.AccDetails[i].attribute3,
                paymentToken: lpData.ServiceProviderInfo.BodyData.AccDetails[i].tokenId,
                reason: "Verified"
              }
              tokenData.push(tokenArrange);
            } else {
              erMsg = "Failed. Please try again. Reason: No Token Details from First Data";
              let details62 = {
                module: 'Credit Card',
                submodule: 'FD Credit Card',
                button: null,
                message: erMsg,
                data: JSON.stringify(lpData)
              };
              paymentCC.CCLog(details62);
              this.alert(erMsg, 'error');
              this.common.tabName = 'ACH';
              this.ccChosen = false;
              paymentCC.common.loader(!1);
              break;
            }
          }
          if (tokenData) {
            let lpgResponse = {
              originalEvent: {
                data: {
                  "cardType": lpData.LPGInfo.cardType == "MC" ? "MASTERCARD" : lpData.LPGInfo.cardType,
                  "emailId": lpData.LPGInfo.emailId ? lpData.LPGInfo.emailId : '',
                  "eventType": "Confirmation",
                  "fourdigitsOfCard": lpData.LPGInfo.fourdigitsOfCard,
                  "isPaymentmethodtosave": lpData.LPGInfo.isPaymentmethodtosave,
                  "requestId": 0,
                  "status": true,
                  tokenDetails: tokenData
                }
              }
            }
            paymentCC.updateCCData(lpgResponse);
            // this.loader(!1);
          } else {
            erMsg = "Failed. Please try again. Reason: No Token Details from First Data";
            let details72 = {
              module: 'Credit Card',
              submodule: 'FD Credit Card',
              button: null,
              message: erMsg,
              data: JSON.stringify(lpData)
            };
            paymentCC.CCLog(details72);
            this.alert(erMsg, 'error');
            this.common.tabName = 'ACH';
            this.ccChosen = false;
            paymentCC.common.loader(!1);
          }
        } else {
          erMsg = "Failed. Please try again. Reason: No Response from First Data";
          let details82 = {
            module: 'Credit Card',
            submodule: 'FD Credit Card',
            button: null,
            message: erMsg,
            data: JSON.stringify(lpData)
          };
          paymentCC.CCLog(details82);
          this.alert(erMsg, 'error');
          this.common.tabName = 'ACH';
          this.ccChosen = false;
          paymentCC.common.loader(!1);
        }
      } else if (lpData.LPGInfo.eventType == "Cancel") {
        this.common.gtmObjectFD('cancel');
        this.ccChosen = false;
        this.common.tabName = 'ACH';
        paymentCC.common.setDefaultTab();
        paymentCC.common.loader(!1);
        history.back();
      } else {
        this.common.gtmObjectFD('error');
        erMsg = "Failed. Please try again. Reason: No Response from First Data";
        let details92 = {
          module: 'Credit Card',
          submodule: 'FD Credit Card',
          button: null,
          message: erMsg,
          data: JSON.stringify(lpData)
        };
        paymentCC.CCLog(details92);
        this.alert(erMsg, 'error');
        this.common.tabName = 'ACH';
        this.ccChosen = false;
        paymentCC.common.loader(!1);
      }


    }
    /**
     * @desc  : manage CC 
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    paymentCC.updateCardDataOnEdit = () => {
      this.jsonDATA && this.jsonDATA?.CardData && "edit" == (this.jsonDATA?.Mode || '').toLocaleLowerCase() && (paymentCC.ccForm = "CC" == this.jsonDATA?.CardData.PaymentType ? this.jsonDATA?.CardData : {});
    };


    /**
     * @desc  : initilize data
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    paymentCC.init = () => {
      // paymentCC.ccFrameURL = angular.copy($sce.trustAsResourceUrl(this.ccUrl.Data));
      this.tempData && paymentCC.updateCardDataOnEdit();
      (this.paymentType == 'CC') && ((paymentCC.common.tabName = 'CC'), paymentCC.manageCCForm(true));
    };

    /**
     * @desc  :update cc data
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    paymentCC.updateCCData = (e: any) => {
      paymentCC.listenCCSubmit(e?.originalEvent ? e?.originalEvent : e);
    };

    /**
     * @desc  : set cc event listner
     * @author: Arun Lalithambaran
     * @source: HCA Patient portal - paymentMethodAdd.js
     */
    if (window) window.addEventListener('message', paymentCC.updateCCData);


    // /**
    //  * @desc: open terms and condition popup
    //  * @author: Arun Lalithambaran
    //  * @source: HCA Patient portal - paymentMethodAdd.js
    //  */
    // paymentCC.openTermsConditionModel = () => {
    //   $rootthis.$broadcast(this.paymentModes.CC + CONSTANTS.EVENTS.TERMS_CONDITIONS, {
    //     buttons: true
    //   });
    // };


    // /**
    //  * @desc: terms and condition listner
    //  * @author: Arun Lalithambaran
    //  * @source: HCA Patient portal - paymentMethodAdd.js
    //  */
    // this.$on(this.paymentModes.CC + CONSTANTS.EVENTS.UPDATE_TERMS_CONDITION, (event, args) => {
    //   if (this.ccChosen) {
    //     args.data ? this.paymentCC.manageCCForm(true) : (this.ccChosen = false, this.common.tabName = 'ACH');
    //   } else {
    //     paymentACH.achForm.agreeCondition = args.data;
    //   }
    //   $timeout(() => {
    //     $("#termsDiv").focus()
    //   });
    // });

    // this.$on('$destroy', () => {
    //   angular.element($window).off('message', paymentCC.updateCCData);
    // });

    // /**
    //  * @desc: listen cc event
    //  * @author: Arun Lalithambaran
    //  * @source: HCA Patient portal - paymentMethodAdd.js
    //  */
    // // this.$on(CONSTANTS.EVENTS.UPDATE_CC_DATA, (event, args) => {
    // //   paymentCC.listenCCSubmit(args);
    // // });

    paymentCC.init();
  }
  ngOnDestroy() {
    window.removeEventListener('message', this.paymentCC.updateCCData);
  }

}

