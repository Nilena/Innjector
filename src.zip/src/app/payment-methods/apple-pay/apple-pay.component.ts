import { Component, OnInit, Output, Input, EventEmitter, NgZone } from '@angular/core';
import { getApiUrl, apiList } from 'src/app/core/constants/api-list';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { Router } from '@angular/router';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { PaymentResponse, ApiResponse, PayData, Profile } from 'src/app/core/models/auth';
import { UserService } from 'src/app/auth/services/user.service';
@Component({
  selector: 'app-apple-pay',
  templateUrl: './apple-pay.component.html',
  styleUrls: ['./apple-pay.component.css']
})
export class ApplePayComponent implements OnInit {
  openMenu: boolean = false;
  tempData: any;
  enableApplePay: boolean = false;
  applePayUrls: any;
  applePay: any = {};
  userInfo: Profile | null = null;
  payload: any = {};
  loader: boolean = false;

  constructor(private http: HttpClient,
    private utility: UtilityService,
    private router: Router,
    private userService: UserService,
    private ngZone: NgZone) {
  }
  ngOnInit(): void {
    this.userInfo = this.userService.getUserInfo();
    if (this.utility.getTempData('tempId')) {
      let id = this.utility.getTempData('tempId');
      this.getData(id);
    }
  }
  getData(id: string) {
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.temp.get) + id;
    this.http.get<ApiResponse>(endpoint).subscribe((data) => {
      if (data.Status == true) {
        this.getSettings();
        this.tempData = data.Data;
        this.tempData.Value = JSON.parse(this.tempData.Value);

        this.utility.loader.next(false);
      } else {
        this.utility.loader.next(false);
        this.utility.alert.toast({ title: data.Message, type: 'error' });
      }
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.loader.next(false);
      this.utility.alert.toast({ title: 'Something went wrong', type: 'error' });
    })
  }

  /*
  *author: Nilena Alexander
  *desc: to check whether apple pay enable in gettings.
  */
  getSettings() {
    this.utility.loader.next(true);
    let payload = {
      SettingsKey: "MerchantIdentifier,IsApplepayEnabled"
    }
    let endpoint = getApiUrl(apiList.payment.GetSettings)
    this.http.post<ApiResponse>(endpoint, payload).subscribe((data) => {
      if (data.Status == true) {
        this.applePayUrls = {
          merchantIdentifier: data.Data[0].Key,
          webhook: data.Data[0].Value,
          merchantIdentifier1: data.Data[1].Key,
          webhook1: data.Data[1].Value
        }
        this.utility.loader.next(false);
        this.enableApplePay = true;
      } else {
        this.utility.loader.next(false);
        this.utility.alert.toast({ title: data.Message, type: 'error' });
      }
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.loader.next(false);
      this.utility.alert.toast({ title: 'Something went wrong', type: 'error' });
    })
  }
  /*
    *author: Nilena Alexander
    *desc: check apple pay button
  */
  clickButtonApple() {
    this.utility.loader.next(true);
    this.loader = true;
    if ((window as any)['ApplePaySession']) {
      const merchantIdentifier = this.applePayUrls.merchantIdentifier;
      // Indicates whether the device supports Apple Pay and whether the user has an active card in Wallet.
      if ((window as any)['ApplePaySession'].canMakePaymentsWithActiveCard(merchantIdentifier)) {
        this.checkout();
      }
    }
    else {
      console.error('This device does not support Apple Pay');
      this.loader = false;
      this.utility.loader.next(false);
    }
  }


  /*
   *author: Nilena Alexander
   *desc: to set apple pay payment reuest details
  */

  checkout() {
    //To present the ApplePay payment sheet
    let discountvalApplePay = 0;
    if ((window as any)['ApplePaySession']) {
      const paymentRequest = {
        countryCode: 'US',
        currencyCode: 'USD',
        supportedNetworks: ['visa', 'masterCard', 'amex', 'discover'],
        merchantCapabilities: ['supports3DS'],
        requiredBillingContactFields: [
          'postalAddress'
        ],
        total: {
          label: 'Amount', type: 'final',
          amount: this.tempData.Value.Total.paid
        },
      };
      const session = new (window as any)['ApplePaySession'](3, paymentRequest);
      // When this method is called, the payment sheet is presented and the merchant validation process is initiated.
      session.begin();
      session.oncancel = (event: any) => {
        this.ngZone.run(() => {
          this.loader = false;
          console.log("oncancel");
          this.utility.loader.next(false);
        });
      };

      // Merchant Validation
      // Call onvalidatemerchant when the payment sheet is displayed to return a merchant session.

      session.onvalidatemerchant = (event: any) => {
        const validationURL = event.validationURL;
        // send validationURL to your server...
        const promise = this.getApplePaySession(validationURL);
        promise.then((merchantSession: any) => {
          session.completeMerchantValidation(merchantSession);
        }).catch((error) => {
          this.ngZone.run(() => {
            console.log("error");
            this.loader = false;
            this.utility.loader.next(false);
          });
        });     // ...return base64 decoded token

      };


      session.onpaymentmethodselected = (event: any) => {
        var newTotal = { type: 'final', label: 'Total', amount: this.tempData.Value.Total.paid };
        var newLineItems = [{ type: 'final', label: 'Amount', amount: this.tempData.Value.Total.paid }];
        session.completePaymentMethodSelection(newTotal, newLineItems);
      }

      session.onpaymentauthorized = (event: any) => {
        session.completePayment((window as any)['ApplePaySession'].STATUS_SUCCESS);
        // this.utility.alert.toast({ title: 'Payment Success', type: 'success' });
        this.makeApplePaymentObject(event);
      }
    }
  }

  /*
   *author: Nilena Alexander
   *desc: getApplePaySession
  */
  getApplePaySession(validationURL: string) {
    const url = this.applePayUrls.webhook1 + validationURL;
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.onload = function () {
        const data = JSON.parse(this.responseText);
        resolve(data);
      };
      xhr.onerror = reject;
      xhr.open('GET', url);
      xhr.send();
    });

  }

  /*
   *author: Nilena Alexander
   *desc: creating obj for Card details 
  */
  makeApplePaymentObject(appleData: any) {
    var applePayPaymentToken: any = {};
    this.applePay.appleData = {};
    applePayPaymentToken.data = appleData.payment.token.paymentData.data;
    applePayPaymentToken.ephemeralPublicKey = appleData.payment.token.paymentData.header.ephemeralPublicKey;
    applePayPaymentToken.transactionId = appleData.payment.token.paymentData.header.transactionId;
    applePayPaymentToken.publicKeyHash = appleData.payment.token.paymentData.header.publicKeyHash;
    applePayPaymentToken.version = appleData.payment.token.paymentData.version;
    let tempArray = [];
    this.applePay.appleData.AccountNo = "";
    this.applePay.appleData.AccountType = "Credit Card";
    this.applePay.appleData.Email = (this.userInfo?.EmailId) ? this.userInfo?.EmailId : "";
    this.applePay.appleData.Nickname = "";
    this.applePay.appleData.TokenId = 0;
    this.applePay.appleData.Token = "";
    this.applePay.appleData.formattedCard = "";
    this.applePay.appleData.PaymentType = "CC";
    this.applePay.appleData.LastFourDigits = "";
    this.applePay.appleData.ProcessorType = "FD";
    this.applePay.appleData.CcType = "CC";
    this.applePay.appleData.MerchantId = "";
    this.applePay.appleData.ParentTokenId = 0;
    // this.applePay.appleData.CardType = (appleData.payment.token.paymentMethod && appleData.payment.token.paymentMethod.network) ? appleData.payment.token.paymentMethod.network : null;
    // this.applePay.appleData.CcType = (appleData.payment.token.paymentMethod && appleData.payment.token.paymentMethod.network) ? appleData.payment.token.paymentMethod.network : null,
    this.applePay.appleData.ZipCode = (appleData.payment.billingContact && appleData.payment.billingContact.postalCode) ? appleData.payment.billingContact.postalCode : null;
    tempArray.push(this.applePay.appleData);
    this.payload = {};
    this.payload = {
      'BillData': this.tempData.Value.BillData,
      'Total': this.tempData.Value.Total,
      'CardData': tempArray,
      'paymentProcessor': 'FD',
      'applePayPaymentToken': applePayPaymentToken,
      'isApplePay': true,
    }
    this.tempData.Value = JSON.stringify(this.payload)
    this.saveApplePayment();
  }

  /*
   *author: Nilena Alexander
   *desc: Saving details in savetotemp api
  */
  saveApplePayment() {
    this.ngZone.run(() => {
      this.loader = true;
      let enpoint = getApiUrl(apiList.temp.save);
      this.http.post<ApiResponse>(enpoint, this.tempData).subscribe(response => {
        if (response.Status) {
          this.utility.setTempData('tempId', response.Data);
          let payString = {
            id: response.Data,
            isGuest: this.userInfo?.IsGuest
          }
          let payload = {
            "": false,
            ActionName: "Payment",
            PaynowStr: btoa(JSON.stringify(payString)),
            id: 0
          }
          // let data = { "PaynowStr": response.Data, "id": 0, "": false, "ActionName": "Payment" };
          // this.utility.alert.toast({ title: response.Message, type: 'success' });
          this.confirmPayment(payload);
        } else {
          this.loader = false;
          this.utility.loader.next(false);
          this.utility.alert.toast({ title: response.Message, type: 'error' });
        }
      }, (err: HttpErrorResponse) => {
        this.loader = false;
        console.log(err)
        this.utility.loader.next(false);
        this.utility.alert.toast({ title: 'Something went wrong', type: 'error' });
      })
    })
  }
  /*
   *author: Nilena Alexander
   *desc: final confirmation submit to Confirm payment
  */
  confirmPayment(data: {}) {
    this.ngZone.run(() => {
      let endpoint = getApiUrl(apiList.paymentMethods.applePaySubmit);
      this.http.post<ApiResponse>(endpoint, data).subscribe(response => {
        this.utility.loader.next(false);
        this.loader = false;
        this.utility.setTempData('paymentStatus', response);
        this.utility.setTempData('paymentKey', 'payNow');
        this.clearTempTable();
        this.router.navigate(['/payment/payment-status']);
      }, (err: HttpErrorResponse) => {
        this.loader = false;
        this.utility.loader.next(false);
        console.log(err)
        this.utility.alert.toast({ title: 'Something went wrong', type: 'error' });
      })
    })
  }

   /*
  author : Nilena Alexander
  desc   : to submit
  */

 private clearTempTable() {
  this.utility.setTempData('tempId',null);
  let endpoint = getApiUrl(apiList.temp.clear);
  this.http.get<ApiResponse>(endpoint).subscribe((response) => {

  }, (err: HttpErrorResponse) => {
    this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
  })
}
cancel(){
  history.back();
}
}
