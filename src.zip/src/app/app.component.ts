import { Component, OnInit } from '@angular/core';
import { UtilityService } from './shared/services/utility.service';
import { ToasterService } from './shared/services/toaster.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  constructor(private utility: UtilityService,
    private toasterService:ToasterService) { }
  title = 'mho';
  ngOnInit() {
    this.toasterService.listenToaster();
    this.utility.checkCookieEnabled();
    this.utility.getSettingsData();
  }
}
