import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
 
import { AuthGuard } from './core/guards/auth.guard';
 
import { LayoutComponent } from './layout/layout.component';
 
const routes: Routes = [
  // {
  // auth routes are added in auth module and import in app.modules.ts
  // },
  {
    path: '', component: LayoutComponent,
    children: [
      { path: 'dashboard', loadChildren: () => import('./dashboard/dashboard.module').then(m => m.DashboardModule) },
      { path: 'payment-plans', loadChildren: () => import('./payment-plans/payment-plans.module').then(m => m.PaymentPlansModule) },
      { path: 'payment', loadChildren: () => import('./payment/payment.module').then(m => m.PaymentModule) },
      { path: 'online-statement', loadChildren: () => import('./online-statement/online-statement.module').then(m => m.OnlineStatementModule) },
      { path: 'payment-methods', loadChildren: () => import('./payment-methods/payment-methods.module').then(m => m.PaymentMethodsModule) },
      { path: 'payment-history', loadChildren: () => import('./payment-histroy/payment-histroy.module').then(m => m.PaymentHistroyModule) },
      
      {
        path: '', redirectTo: 'dashboard', pathMatch: 'full'
      },
    ],
    canActivate: [AuthGuard]
  },
  {
    path: '**', redirectTo: 'login', pathMatch: 'full'
  }
];
 
@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true, scrollPositionRestoration: 'top' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }