import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { UtilityService } from 'src/app/shared/services/utility.service';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  private selectedPaymentOption: number | null = null;
  public paymentOptionList: any[] = [
    { label: 'Pay Now', id: 1, key: CONSTANTS.PAY_MODES.NOW },
    { label: 'Pay in 30 days', id: 2, key: CONSTANTS.PAY_MODES.THIRTY },
    { label: 'Pay half now, half in 30 days', id: 3, key: CONSTANTS.PAY_MODES.HALF },
    { label: 'Other options', id: 4, key: CONSTANTS.PAY_MODES.OTHERS },
  ];

  constructor(
    private http: HttpClient,
    private utility: UtilityService
  ) { }

  /*
    author : Arun Lalithambaran
    desc   : to selected payment option
  */
  public getSelectedPaymentOption(reFetch: boolean = false): number | null {
    if (reFetch) this.selectedPaymentOption = null;
    if (!this.selectedPaymentOption) {
      let selectedPaymentOption = this.utility.getTempData('selectedPaymentOption');
      this.selectedPaymentOption = selectedPaymentOption ? Number(selectedPaymentOption) : null;
    }
    return this.selectedPaymentOption;
  }

  public setSelectedPaymentOption(value: number) {
    this.selectedPaymentOption = value;
    this.utility.setTempData('selectedPaymentOption', JSON.stringify(value));
    // localStorage.setItem('selectedPaymentOption', JSON.stringify(value));
  }

  public updateMethodDetails(data: any, cb: any) {
    this.utility.loader.next(true);
    this.http.post(getApiUrl(apiList.cc.updatePaymentMethod), data).subscribe(res => {
      cb(res);
      this.utility.loader.next(false);
    }, err => {
      cb(err)
      this.utility.loader.next(false);
    })
  }
  public saveCardDetails(data: any, cb: any) {
    this.utility.loader.next(true);
    this.http.post(getApiUrl(apiList.cc.savepmtmethod), data).subscribe(res => {
      cb(res);
      this.utility.loader.next(false);
    }, err => {
      cb(err);
      this.utility.loader.next(false);
    })
  }
  CheckCCNickName(nickName: any, cb: any) {
    this.utility.loader.next(true);
    this.http.get(getApiUrl(apiList.cc.createNickName + `?nickName=${nickName}`)).subscribe(res => {
      cb(res);
      this.utility.loader.next(false);
    }, err => {
      cb(err);
      this.utility.loader.next(false);
    })
  };
  getProcessorWithToken(data: any, cb: any) {
    this.utility.loader.next(true);
    this.http.get(getApiUrl(apiList.paymentMethods.getProcessorTypeByTokenId + `tokenId=${data}`)).subscribe(res => {
      cb(res);
      this.utility.loader.next(false);
    }, err => {
      cb(err);
      this.utility.loader.next(false);
    })
  };
  getProcessorType(data: any, cb: any) {
    this.utility.loader.next(true);
    this.http.get(getApiUrl(apiList.paymentMethods.getPatientProcessorType + `?peopleid=${data}`)).subscribe(res => {
      cb(res);
      this.utility.loader.next(false);
    }, err => {
      cb(err);
      this.utility.loader.next(false);
    })
  };
  getCCiframeUrl(data: any, cb: any) {
    this.utility.loader.next(true);
    this.http.post(getApiUrl(apiList.paymentMethods.PAYMENT_CC_URL), data).subscribe(res => {
      cb(res);
      this.utility.loader.next(false);
    }, err => {
      cb(err);
      this.utility.loader.next(false);
    })
  };
  updateTempBillDetails(data: any, cb: any) {
    this.utility.loader.next(true);
    this.http.post(getApiUrl(apiList.temp.save), data).subscribe(res => {
      cb(res);
      this.utility.loader.next(false);
    }, err => {
      cb(err);
      this.utility.loader.next(false);
    })
  };
  getLpgToken(data: any, cb: any) {
    this.utility.loader.next(true);
    this.http.post(getApiUrl(apiList.lpg.token), data).subscribe(res => {
      cb(res);
      this.utility.loader.next(false);
    }, err => {
      cb(err);
      this.utility.loader.next(false);
    })
  };

}
