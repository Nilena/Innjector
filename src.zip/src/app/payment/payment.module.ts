import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BalanceRequirigActionComponent } from './balance-requirig-action/balance-requirig-action.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PaymentMethodListComponent } from './payment-method-list/payment-method-list.component';
import { SharedModule } from '../shared/shared.module';
import { PaymentSummaryComponent } from './payment-summary/payment-summary.component';
import { PaymentStatusComponent } from './payment-status/payment-status.component';
import { ConfirmpaymentComponent } from './confirmpayment/confirmpayment.component';
import { CreatePaymentPlanComponent } from './create-payment-plan/create-payment-plan.component';
import { PaymentOptionsComponent } from './payment-options/payment-options.component';
import { OtherPaymentSummaryComponent } from './other-payment-summary/other-payment-summary.component';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { PrintReceiptComponent } from './print-receipt/print-receipt.component';
import { EmailReceiptComponent } from './email-receipt/email-receipt.component';
import { TempResolver } from '../shared/resolver/temp.resolver';
import { RmexBalanceRequiruingActionComponent } from './rmex-balance-requiruing-action/rmex-balance-requiruing-action.component';
export const routes: Routes = [
  {
    path: 'pay', component: BalanceRequirigActionComponent,
  },
  {
    path: 'rmex-pay', component: RmexBalanceRequiruingActionComponent,
  },
  {
    path: 'methods', component: PaymentMethodListComponent
  },
  {
    path: 'confirm-payment', component: PaymentSummaryComponent, resolve: { temp: TempResolver} 
  },
  {
    path: 'payment-status', component: PaymentStatusComponent
  },
  {
    path: 'confirm-pay', component: ConfirmpaymentComponent, resolve: { temp: TempResolver} 
  },
  {
    path: 'create-payment-plan', component: CreatePaymentPlanComponent
  },
  {
    path: 'payment-plan-options', component: PaymentOptionsComponent
  },
  {
    path: 'confirm-other-payment', component: OtherPaymentSummaryComponent, resolve: { temp: TempResolver} 
  },
  {
    path: 'print/:id', component: PrintReceiptComponent
  },
  {
    path: 'email/:id', component: EmailReceiptComponent
  }
]

@NgModule({
  declarations: [
    BalanceRequirigActionComponent,
    PaymentMethodListComponent,
    PaymentSummaryComponent,
    PaymentStatusComponent,
    ConfirmpaymentComponent,
    CreatePaymentPlanComponent,
    PaymentOptionsComponent,
    OtherPaymentSummaryComponent,
    PrintReceiptComponent,
    EmailReceiptComponent,
    RmexBalanceRequiruingActionComponent,
    ],
  imports: [
    CommonModule,
    FormsModule,
    SharedModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    MatDatepickerModule,
    MatNativeDateModule,
    MatFormFieldModule,
    MatInputModule

  ]
})
export class PaymentModule { }
