import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/auth/services/user.service';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { ApiResponse } from 'src/app/core/models/auth';
import { PaymentDetailsInfo, PaymentHeaderDetails } from 'src/app/core/models/payment';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { PaymentService } from '../services/payment.service';
import { InlineToaster } from 'src/app/shared/components/inline-toast/inline-toast.component';

@Component({
  selector: 'app-create-payment-plan',
  templateUrl: './create-payment-plan.component.html',
  styleUrls: ['./create-payment-plan.component.css']
})
export class CreatePaymentPlanComponent implements OnInit {

  public fetchingInProgress: boolean = false;
  public paymentDetailsInfo: PaymentDetailsInfo | null = null;
  public totalAmountToPay: number = 0;
  public paymentOptionList: any[];
  public selectedPaymentOption: any;
  public savingInProgress: boolean = false;
  public totalAmount: number = 0;
  @ViewChild('topToastMessage') public topToastMessage?: InlineToaster;
  @ViewChild('summary') summary! : ElementRef;
  constructor(
    private utility: UtilityService,
    private http: HttpClient,
    private userService: UserService,
    private router: Router,
    private paymentService: PaymentService
  ) {
    this.paymentOptionList = this.paymentService.paymentOptionList;
    this.clearTempTable();
  }
  ngOnInit(): void {
    this.utility.headerText$.next('Bill Payment');
    this.paymentOptionSelected();
  }
  ngAfterViewInit(){
    this.summary.nativeElement.focus();
 }

  private clearTempTable() {
    this.utility.setTempData('tempId', null);
    let endpoint = getApiUrl(apiList.temp.clear);
    this.http.get<ApiResponse>(endpoint).subscribe((response) => {

    }, (err: HttpErrorResponse) => {
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }

  public paymentOptionSelected() {
    let selectedPaymentOptionId = this.paymentService.getSelectedPaymentOption() || 1;
    let el = this.paymentOptionList.find(item => item.id == selectedPaymentOptionId);
    this.selectedPaymentOption = el;
    this.topToastMessage?.clearToast();
    this.getPaymentDetails();
  }

  public getPaymentDetails() {
    // this.fetchingInProgress = true;
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.payment.otherOptions);
    this.http.post<ApiResponse>(endpoint, null).subscribe((response) => {
      if (response.Status == true) {
        this.paymentDetailsInfo = response.Data as PaymentDetailsInfo;
        this.updateTotalAmountToPay();
        this.openAllCollapsedItems();
        if (this.paymentDetailsInfo) {
          let totalAmount = this.paymentDetailsInfo?.PaymentDetails.reduce((total: number, item: any) => {
            return total + item.TotalPlanAmount
          }, 0)
          this.totalAmount = totalAmount
        }


        // this.utility.alert.toast({ title: response.Message, type: 'success' });
      } else {
        this.utility.alert.toast({ title: response.Message, type: 'error' });
      }
      // this.fetchingInProgress = false;
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      // this.fetchingInProgress = false;
      this.utility.loader.next(false);
    })
  }

  public updateTotalAmountToPay() {
    try {
      this.totalAmountToPay = 0;
      if (this.paymentDetailsInfo)
        this.paymentDetailsInfo.PaymentDetails.forEach(item => {
          let subTotal = 0;
          item.PaymentHeaderDetails.forEach(el => {
            if (el._checked)
              subTotal += Number(el.PaymentAmount);
          })
          this.totalAmountToPay += subTotal;
        })
    } catch (err) {
      this.totalAmountToPay = this.paymentDetailsInfo?.TotalBalance || 0;
    }
  }
  public formatInputValue(item: any) {
    try {
      ("" == item.PaymentAmount || null == item.PaymentAmount) && (item.PaymentAmount = 0.00);
      item.PaymentAmount = parseFloat(item.PaymentAmount).toFixed(2);
      if (item.PaymentAmount == 'NaN') item.PaymentAmount = 0;
    } catch (er) {
      item.PaymentAmount = 0;
    }

  }

  public gtmLog(title: string) {
    let data: any = {};
    let user = this.userService.getUserInfo();
    data.event_title = title;
    data.data_object = {};
    data.event_interactive = true;
    data.event_logged_in = user ? true : false;
    data.event_category = "Payment Plans";
    data.event_registration_type = user ? (user.IsGuest ? 'guest' : user.FromMHO ? 'mho' : 'epay') : null;
    data.event_facility = user ? user.ClientCode : null;
    data.event_user_id = user ? user.UserID : null;
    data.event_user_type = user ? 'patient' : null;
    data.event_success = true;
    data.event_session_id = user ? user.RequestToken : null;
    this.utility.googleTrack(data);
  }

  public showDuplicatePopup: boolean = false;
  public duplicateList: any[] = [];
  /*
    author : Nilena Alexander
    desc   : for clear local storage
  */
  public logout() {
    let loginConfig = this.utility.getTempData(CONSTANTS.APP_CONFIG.login_config);
    this.userService.removeSession(true);
    try {
      if (loginConfig && loginConfig.eLogin == 1) {
        this.router.navigate(['/email-login' + loginConfig.token]);
      } else if (loginConfig.eLogin && loginConfig.eLogin == 2) {
        this.router.navigate(['/text-login' + loginConfig.token]);
      } else {
        this.router.navigate(['/user-login']);
      }
    } catch (err) {
      this.router.navigate(['/user-login']);
    }
  }
  public next(isDuplicate: boolean = false) {
    this.topToastMessage?.clearToast();
    let user = this.userService.getUserInfo();
    if (user.IsGuest && (this.selectedPaymentOption.key == CONSTANTS.PAY_MODES.OTHERS)) {
      this.utility.alert.confirm({
        text: 'To view other payment options, please login or create an account',
        type: 'warning',
        hideCancelButton: true,
        okText: 'Back to login',
        title: ''
      }).then(res => {
        if (res) {
          //this.loaderSub =true;
          this.logout();
        }
      })
      return;
    }
    if (this.isUserInputInvalid()) return;
    // this.showDuplicatePopup = false;
    this.gtmLog('Plan Options');
    this.savingInProgress = true;
    let endpoint = getApiUrl(apiList.temp.save);
    let billData: PaymentHeaderDetails[] = [];
    this.paymentDetailsInfo?.PaymentDetails.forEach((el) => {
      el.PaymentHeaderDetails.forEach(item => {
        if (item._checked) {
          billData.push(item);
        }
      })
    })
    let total: any = {
      balance: this.paymentDetailsInfo?.TotalBalance,
      paid: this.totalAmountToPay.toFixed(2)
    }
    let facilities: string[] = billData.map(el => el.ClientCode);
    // this.paymentDetailsInfo?.PaymentDetails.forEach(el => {
    //   // if (!(!el.PaymentHeaderDetails.[0].PaymentAmount || Number(item.PaymentHeaderDetails.PaymentAmount) == 0)) {
    //   //   facilities.push(el.ClientCode);

    //   // }
    // })

    let payload = {
      Key: this.selectedPaymentOption.key,
      Value: JSON.stringify({
        BillData: billData,
        Total: total,
        facilities: facilities
      })
    };
    this.http.post<ApiResponse>(endpoint, payload).subscribe((response) => {
      this.savingInProgress = false;
      this.utility.setTempData('tempId', response.Data);
      this.router.navigate(['/payment/payment-plan-options']);
    }, (err: HttpErrorResponse) => {
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.utility.loader.next(false);
      this.savingInProgress = false;
    })
  }

  public showAlert() {
    this.utility.alert.confirm({
      title: 'Information',
      type: 'info',
      hideCancelButton: true,
      hideOkButton: true,
      text: 'This item can be part of a one-time payment but cannot be included in any scheduled payment or payment plan.'
    })
  }

  private isUserInputInvalid() {
    if (this.paymentDetailsInfo && this.totalAmountToPay < this.paymentDetailsInfo.OthersMinAmount) {
      // this.utility.alert.toast({ type: 'error', title: `Plan amount should be greater than or equal to ${this.paymentDetailsInfo.OthersMinAmount}!` })

      this.topToastMessage?.inlineToast({ type: 'warning', title: `Plan amount should be greater than or equal to $${this.paymentDetailsInfo.OthersMinAmount}`, __disableAutoClose: true });

      return true;
    }
    let invalid = false;
    this.paymentDetailsInfo?.PaymentDetails.forEach((el) => {
      el.PaymentHeaderDetails.forEach(item => {
        if (item._checked && item.restricted_account_status == 0) {
          (item as any)['error'] = true;
          invalid = true;
        } else {
          (item as any)['error'] = false;
        }
      })
    })
    if (invalid) {
      this.showAlert();
      return true;
    }
    return false;
  }
  private openAllCollapsedItems() {
    this.paymentDetailsInfo?.PaymentDetails.forEach(el => {
      el._open = true;
    })
  }
}
