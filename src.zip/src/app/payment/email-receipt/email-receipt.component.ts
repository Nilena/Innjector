
import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { getApiUrl, apiList } from 'src/app/core/constants/api-list';
import { ApiResponse, Profile } from 'src/app/core/models/auth';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { UserService } from 'src/app/auth/services/user.service';
import { CONSTANTS } from '../../core/constants/constants';
import { REGCONSTANTS } from '../../core/constants/regex-constants';

import { ReceiptDetailsList, ReceiptHeaderDetails } from 'src/app/core/models/print&email';

@Component({
  selector: 'app-email-receipt',
  templateUrl: './email-receipt.component.html',
  styleUrls: ['./email-receipt.component.css']
})
export class EmailReceiptComponent implements OnInit {
  routeSub: any = null;
  receiptDetailsList: ReceiptDetailsList[] = [];
  receiptHeaderDetails: ReceiptHeaderDetails | ReceiptHeaderDetails | null = null;
  loader: boolean = false;
  userInfo: Profile | null = null;
  openSub: boolean = false;
  emailScreen: boolean = false;
  emailId: any = null;
  printScreen: boolean = false;
  submitted: boolean = false;
  invalidEmail: boolean = false;
  paymentStatus: any;
  constructor(router: Router,
    private route: ActivatedRoute,
    private http: HttpClient,
    private utility: UtilityService,
    private UserService: UserService,
    private Router: Router) {
    this.paymentStatus = this.utility.getTempData('paymentStatus');
  }
  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.routeSub = params['id'];
    });
    this.showReceipt();
    this.userInfo = this.UserService.getUserInfo();
  }

  sendMail() {
    this.submitted = true;
    if (!this.emailId || this.invalidEmail) {
      this.invalidEmail = true;
      return;
    }
    else {
      this.loader = true;
      let value = JSON.parse(atob(this.routeSub));
      let payload: any = {
        Email: this.emailId,
        PaymentID: value.PaymentTransactionId
      };
      let endpoint = getApiUrl(apiList.paymentHistroy.sendMail);
      this.http.post<ApiResponse>(endpoint, payload).subscribe(response => {
        if (response.Status) {
          this.utility.alert.toast({ title: response.Message, type: 'success' });
          this.loader = false;
          this.paymentStatus.Data.Email = this.emailId;
          this.utility.setTempData('paymentStatus', this.paymentStatus);
          window.history.back();
        }
        else {
          this.loader = false;
          this.emailScreen = false;
          this.utility.alert.toast({ title: response.Message, type: 'error' });
        }
      }, (err: HttpErrorResponse) => {
        this.loader = false;
        this.emailScreen = false;
        this.utility.alert.toast({ title: 'Something went Worng!', type: 'error' });
      });
    }
  }

  emailIdCheck() {
    if (this.emailId) {
      const pattern = new RegExp(REGCONSTANTS.emailRegExp);
      if (this.emailId && !pattern.test(this.emailId)) {
        return this.invalidEmail = true;
      } else
        return this.invalidEmail = false;
    }
    else
      return this.invalidEmail = true;
  }
  /*
  author:Nilena Aelxander
  dec:go to back to payment status page
  */
  showReceipt() {
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.paymentHistroy.ShowReceipt) + 'id=' + this.routeSub;
    this.http.get<ApiResponse>(endpoint).subscribe(response => {
      if (response.Status) {
        this.receiptDetailsList = response.Data.ReceiptDetailsList as ReceiptDetailsList[];
        this.receiptHeaderDetails = response.Data.ReceiptHeaderDetails as ReceiptHeaderDetails;
        this.emailId = this.receiptHeaderDetails.Email ? this.receiptHeaderDetails.Email : this.userInfo?.EmailId;
        this.utility.loader.next(false);
      }
      else {
        this.utility.loader.next(false);
        this.utility.alert.toast({ title: response.Message, type: 'error' })
      }
    }, (err: HttpErrorResponse) => {
      this.utility.loader.next(false);
      this.utility.alert.toast({ title: 'Something went Worng!', type: 'error' })
    })
  }
  /*
   author:Nilena Aelxander
   dec:go to back to payment status page
   */
  cancel() {
    window.history.back();
  }
  /*
   author:Nilena Aelxander
   dec:to print 
   */
  print() {
    (window as any).print();
  }
}
