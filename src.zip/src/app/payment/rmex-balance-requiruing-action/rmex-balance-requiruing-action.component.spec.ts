import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmexBalanceRequiruingActionComponent } from './rmex-balance-requiruing-action.component';

describe('RmexBalanceRequiruingActionComponent', () => {
  let component: RmexBalanceRequiruingActionComponent;
  let fixture: ComponentFixture<RmexBalanceRequiruingActionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RmexBalanceRequiruingActionComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RmexBalanceRequiruingActionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
