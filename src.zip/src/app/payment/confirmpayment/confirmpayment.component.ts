import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/auth/services/user.service';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { PaymentDetailsInfo } from 'src/app/core/models/payment';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { PaymentService } from '../services/payment.service';
import { Profile, ApiResponse } from 'src/app/core/models/auth';
import { ConditionalExpr } from '@angular/compiler';
import { CONSTANTS } from 'src/app/core/constants/constants';
@Component({
  selector: 'app-confirmpayment',
  templateUrl: './confirmpayment.component.html',
  styleUrls: ['./confirmpayment.component.css']
})
export class ConfirmpaymentComponent implements OnInit {


  public fetchingInProgress: boolean = false;
  public agreeTerms: boolean = false;
  public tempId: any;
  public tempData: any = null;
  public savingInProgress: boolean = false;
  public totalPaymentInfo: any = null;
  public billData: any[] = [];
  public cardData: any = null;
  public termsAndCondition: boolean = false;
  public submitted: boolean = false;
  public showDuplicatePopup: boolean = false;
  public duplicateList: any[] = [];
  public paymentType: string = ""
  emittedCheckedvalue: boolean = false;
  userInfo: Profile | null = null;
  payInthirty: any = {};
  ScheduledDateData: any = [];
  LPGAcessToken: any = {};
  termsPopup: boolean = false;
  checkBoxEnable: boolean = false;

  constructor(
    private utility: UtilityService,
    private http: HttpClient,
    private userService: UserService,
    private router: Router,
    private paymentService: PaymentService
  ) {
    this.tempId = this.utility.getTempData('tempId');
  }

  ngOnInit(): void {
    this.userInfo = this.userService.getUserInfo();
    if (this.utility.getTempData('LPGAcessToken')) {
      this.LPGAcessToken = this.utility.getTempData('LPGAcessToken');
    }
    this.getTempData();
  }

  cancel() {
    history.back();
  }

  public getTempData() {
    //this.fetchingInProgress = true;
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.temp.get + this.tempId);
    this.http.get<any>(endpoint).subscribe((response) => {
      if (response.Status == true) {
        this.tempData = response.Data;
        this.tempData.Value = JSON.parse(this.tempData.Value);
        this.totalPaymentInfo = this.tempData.Value.Total;
        this.billData = this.tempData.Value.BillData;
        this.cardData = this.tempData.Value.CardData[0];
        this.utility.loader.next(true);
        this.paymentType = this.tempData.Key
        this.paymentCall(this.tempData.Key);
        this.utility.loader.next(false);
      } else {
        this.utility.alert.toast({ title: response.Message, type: 'error' });
        this.utility.loader.next(false);
      }
    }, (err: HttpErrorResponse) => {
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.utility.loader.next(false);
    })
  }

  /*
author : Nilena Alexander
desc   : to take checkbox data
params :
*/
  checkBoxChanges() {
    if (this.checkBoxEnable) {
      this.emittedCheckedvalue = false;
      this.termsPopup = true;
    }else{
      this.emittedCheckedvalue = false;
    }
  }
  /*
  author :Elizabeth
  desc   : open terms and condition from T&C keyword
  params :
  */
  checkEnable() {
    this.emittedCheckedvalue = false;
    this.termsPopup = true;
  }
  /*
  author :Nilena Alexander
  desc   : T&C emitted value
  params :event from component
  */
  checkValue(event: boolean) {
    if (event == true) {
      this.emittedCheckedvalue = true;
      this.checkBoxEnable = true;
      this.gtmLog('Terms and Conditions', 'agree');
    } else {
      this.emittedCheckedvalue = false
      this.checkBoxEnable = false;
      this.gtmLog('Terms and Conditions', 'reject');
    }
    this.termsPopup = false;
  }
  /*
  author : Nilena Alexander
  desc   : to get call based on payin30 or payhalf
  */
  paymentCall(type: string) {
    let endpoint: string = '';
    let payload = {
      PaymentPlanAmount: this.totalPaymentInfo.paid,
      payOptions: this.tempData.Key,
    }
    if (type == CONSTANTS.PAY_MODES.THIRTY)
      endpoint = getApiUrl(apiList.payment.payInthirty)
    else
      endpoint = getApiUrl(apiList.payment.PayHalf)

    this.http.post<ApiResponse>(endpoint, payload).subscribe((response) => {
      if (response.Status == true) {
        this.payInthirty = response.Data;
        this.ScheduledDateData = this.payInthirty.ScheduledInstallment;
        this.utility.loader.next(false);
      }
      else {
        this.utility.loader.next(false);
        this.utility.alert.toast({ title: response.Message, type: 'error' });
      }
    }, (err: HttpErrorResponse) => {
      this.utility.loader.next(false);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }

  public gtmLog(title: string, item: string, category?: string) {
    let data: any = {};
    let user = this.userService.getUserInfo();
    data.event_title = title;
    item ? data.data_object = {
      item_selected: item
    } : data.data_object = {};
    data.event_interactive = true;
    data.event_logged_in = user ? true : false;
    data.event_category = category ? category : "Payment Plans";
    data.event_registration_type = user ? (user.IsGuest ? 'guest' : user.FromMHO ? 'mho' : 'epay') : null;
    data.event_facility = user ? user.ClientCode : null;
    data.event_user_id = user ? user.UserID : null;
    data.event_user_type = user ? 'patient' : null;
    data.event_success = true;
    data.event_session_id = user ? user.RequestToken : null;
    this.utility.googleTrack(data);
  }

  /*
  author : Nilena Alexander
  desc   : to submit
  */
  public makePayment() {
    this.submitted = true;
    if (this.tempData.Key == CONSTANTS.PAY_MODES.THIRTY || this.tempData?.Key == CONSTANTS.PAY_MODES.HALF) {
      if (!this.checkBoxEnable)
        return;
    }
    let text: string = '';
    let amount = this.totalPaymentInfo.paid

    if (this.tempData.Key == CONSTANTS.PAY_MODES.THIRTY) {
      text = '$' + amount + ' will be deducted on ' + this.payInthirty.FirstInstallmentDate;
    } else if (this.tempData?.Key == CONSTANTS.PAY_MODES.HALF) {

      let text2 = this.payInthirty?.DownPaymentAmount.toFixed(2)
      text = '$' + text2 + ' will be paid now, the rest of the amount will be deducted on ' + this.payInthirty.NextInstallmentDate;
    }

    this.utility.alert.confirm({
      title: this.totalPaymentInfo.paid,
      text: text,
      type: 'warning',
      isTitleCash: true,
      okText: 'Yes'
    }).then(status => {
      if (status && (this.tempData?.Key == CONSTANTS.PAY_MODES.THIRTY || this.tempData?.Key == CONSTANTS.PAY_MODES.HALF)) {
        this.savingInProgress = true;
        this.utility.paymentLoader.next(true);
        let data = [];
        for (let i = 0; i < this.tempData.Value.CardData.length; i++) {
          let details: any = {};
          details.AccountName = this.tempData.Value.CardData[i].AccountName;
          details.AccountNo = this.tempData.Value.CardData[i].AccountNo;
          details.AccountType = this.tempData.Value.CardData[i].AccountType;
          details.Email = this.tempData.Value.CardData[i].Email ? this.tempData.Value.CardData[i].Email : this.userInfo?.EmailId;
          details.Nickname = this.tempData.Value.CardData[i].MethodName;
          details.RoutingTransitNo = this.tempData.Value.CardData[i].RoutingTransitNo;
          details.TokenId = this.tempData.Value.CardData[i].TokenId;
          details.Token = this.tempData.Value.CardData[i].Token;
          details.ExternalToken = this.tempData.Value.CardData[i].ExternalToken;
          details.formattedCard = this.tempData.Value.CardData[i].AccountNo;
          details.PaymentType = this.tempData.Value.CardData[i].PaymentType;
          details.LastFourDigits = this.tempData.Value.CardData[i].LastFourDigits;
          details.SaveStatus = this.tempData.Value.CardData[i].SaveStatus;
          details.CcType = this.tempData.Value.CardData[i].PaymentType;
          details.MerchantId = this.tempData.Value.CardData[i].MerchantId;
          details.ProcessorType = this.tempData.Value.CardData[i].ProcessorType;
          details.ParentTokenId = this.tempData.Value.CardData[i].ParentTokenId;
          data.push(details);
        }
        let payload: any = {};
        payload = {
          'InstallmentDetails': this.payInthirty,
          'MakePaymentHeader': this.tempData.Value.BillData,
          'PaymentInfoList': data,
          'PaymentRuleRequest': {
            'PayOptions': (this.tempData?.Key == CONSTANTS.PAY_MODES.HALF) ? 2 : 1,
          },
          'ProcessorType': this.payInthirty.ProcessorType ? this.payInthirty.ProcessorType : (this.tempData?.Value?.paymentProcessor ? this.tempData?.Value?.paymentProcessor : null),
          'Transaction': {
            'Email': (this.cardData.Email) ? this.tempData.Value.CardData[0].Email : this.userInfo?.EmailId,
            'Nickname': this.cardData.Nickname ? this.cardData.Nickname : this.cardData.PaymentMethod,
            'Station': this.tempData.Value.BillData ? this.tempData.Value.BillData[0].StationCode : null,
            'amount': (this.totalPaymentInfo.paid),
            'instrumentType': this.cardData.CcType ? this.cardData.CcType : this.cardData.PaymentType,
            'PaymentMethod': this.cardData.PaymentMethod ? this.cardData.PaymentMethod : (this.cardData.CcType ? this.cardData.CcType : this.cardData.PaymentType),
          }
        }

        if (this.LPGAcessToken && this.LPGAcessToken.LPGtoken && this.LPGAcessToken.LPGtoken.access_token) {
          payload.AccessToken = (this.LPGAcessToken && this.LPGAcessToken.LPGtoken && this.LPGAcessToken.LPGtoken.access_token) ? this.LPGAcessToken.LPGtoken.access_token : null

        }
        let endpoint = getApiUrl(apiList.payment.ConfirmDistribution);

        this.http.post<any>(endpoint, payload).subscribe((response) => {
          this.utility.setTempData('paymentStatus', response);
          if (this.tempData?.Key == CONSTANTS.PAY_MODES.THIRTY)
            this.utility.setTempData('paymentKey', CONSTANTS.PAY_MODES.THIRTY);
          else
            this.utility.setTempData('paymentKey', CONSTANTS.PAY_MODES.HALF);
          this.savingInProgress = false;
          this.utility.paymentLoader.next(false);
          this.clearTempTable();
          this.router.navigate(['/payment/payment-status']);
        }, (err: HttpErrorResponse) => {
          this.savingInProgress = false;
          this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
          this.utility.loader.next(false);
          this.utility.paymentLoader.next(false);
        })
      }
    })
  }

  /*
  author : Nilena Alexander
  desc   : to submit
  */

  private clearTempTable() {
    this.utility.setTempData('tempId', null);
    let endpoint = getApiUrl(apiList.temp.clear);
    this.http.get<ApiResponse>(endpoint).subscribe((response) => {

    }, (err: HttpErrorResponse) => {
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }
}


