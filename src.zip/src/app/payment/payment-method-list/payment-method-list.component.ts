import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ElementRef, ViewChild, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/auth/services/user.service';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { ApiResponse } from 'src/app/core/models/auth';
import { UtilityService } from 'src/app/shared/services/utility.service';

@Component({
  selector: 'app-payment-method-list',
  templateUrl: './payment-method-list.component.html',
  styleUrls: ['./payment-method-list.component.css']
})
export class PaymentMethodListComponent implements OnInit {

  public fetchingInProgress: boolean = false;
  public paymentMethodList: any | null = null;
  public clientCodes: string[] = [];
  public selectedPaymentOption: any = null;
  public tempId: any;
  public tempData: any = null;
  public savingInProgress: boolean = false;
  public selectedDisplayItem: any | null = null;
  @ViewChild('scroll') scroll!: ElementRef;
  
  @ViewChild('selectedPaymentOptionx') selectedPaymentOptionx!: ElementRef;

  @ViewChild('Method') Method! : ElementRef;

  openMenu: boolean = false;
  constructor(
    private utility: UtilityService,
    private http: HttpClient,
    private userService: UserService,
    private router: Router) {
    this.tempId = this.utility.getTempData('tempId');
  }
  // @HostListener('keydown', ['$event'])
  // clickarrowx(event: any) {
  //   if(event.code == 'Enter' || event.key == 'Enter'){
  //       if(document.activeElement?.lastChild?.textContent==='Responsible Party'){
  //       }
  //   }
  // }

  ngOnInit(): void {
    this.utility.headerText$.next('Bill Payment');
    this.getTempData();

  }
  selectedCard(item: any) {
    this.selectedDisplayItem = item
  }
  clearselectedCard() {
    this.selectedDisplayItem = null;
    this.selectedPaymentOption = null;
  }
  ngAfterViewInit(){
    this.Method.nativeElement.focus();
 }


  /*
author : Nilena Alexander
modified: Arun Lalithambaran
desc   : to open side menu
*/
  menuData(event: boolean | string) {
    this.openMenu = !!event;
  }


  public getTempData() {
    //this.fetchingInProgress = true;
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.temp.get + this.tempId);
    this.http.get<any>(endpoint).subscribe((response) => {
      if (response.Status == true) {
        this.tempData = response.Data;
        this.tempData.Value = JSON.parse(this.tempData.Value);
        this.clientCodes = this.tempData.Value.facilities;
        this.getPaymentMethodList();
      } else {
        this.utility.alert.toast({ title: response.Message, type: 'error' });
      }
      //this.fetchingInProgress = false;
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      //this.fetchingInProgress = false;
      this.utility.loader.next(false);
    })
  }

  public getPaymentMethodList() {
    //this.fetchingInProgress = true;
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.payment.paymentMethodList);
    let payload = {
      client_codes: this.clientCodes
    }
    this.http.post<any>(endpoint, payload).subscribe((response) => {

      if (response.success == true) {
        this.paymentMethodList = response.Data;
        this.paymentMethodList.reverse();
        try {
          if (this.paymentMethodList && this.paymentMethodList.length) {
            if (this.tempData.Key == CONSTANTS.PAY_MODES.ATTACH) {
              const editItem = this.paymentMethodList.find((el: any) => this.tempData.Value.PaymentTokenId == el.TokenId);
              this.selectedPaymentOption = editItem.TokenId;
              if(this.selectedPaymentOption){
                setTimeout(() => {

                  var headerOffset = 300;
                  var elementPosition = this.selectedPaymentOptionx.nativeElement.getBoundingClientRect().top;
                  var offsetPosition = elementPosition - headerOffset;
                  this.selectedPaymentOptionx.nativeElement.scrollIntoView({
                    behavior: "smooth",
                    block: "center",
                    inline: "start"
                  });

                }, 50)
              }
              this.selectedDisplayItem = editItem;
            } else {
              this.selectedPaymentOption = this.paymentMethodList[0].TokenId;
              const defaultItem = this.paymentMethodList.find((el: any) => el.IsDefault);
              if (defaultItem) {
                this.selectedPaymentOption = defaultItem.TokenId;
                this.selectedDisplayItem = defaultItem;
                setTimeout(() => {

                  // Checking if its mobile coz - diffrent scroll type in mobile and desktop
                  if (this.utility.isMobile()){

                  var headerOffset = 300;
                  var elementPosition = this.scroll.nativeElement.getBoundingClientRect().top;
                  var offsetPosition = elementPosition - headerOffset;
                  window.scrollTo({
                    top: offsetPosition,
                    behavior: "smooth"
                  });

                }else{
                  var headerOffset = 300;
                  var elementPosition = this.scroll.nativeElement.getBoundingClientRect().top;
                  var offsetPosition = elementPosition - headerOffset;
                  this.scroll.nativeElement.scrollIntoView({
                    behavior: "smooth",
                    block: "center",
                    inline: "start"
                  });
                }
                }, 50)

              }else{
                this.selectedDisplayItem = this.paymentMethodList[0];
              }
            }
          } else {
            this.addPaymentMethod();
          }
        } catch (err) {
          // this.utility.alert.toast({ title: 'Payment method not found', type: 'error' });
        }

        // this.utility.alert.toast({ title: response.Message, type: 'success' });
      } else {
        this.utility.alert.toast({ title: response.Message, type: 'error' });
      }
      //this.fetchingInProgress = false;
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: 'Something went wrong', type: 'error' });
      //this.fetchingInProgress = false;
      this.utility.loader.next(false);
    })
  }

  public continue() {
    const selectedOption = this.paymentMethodList.find((el: any) => el.TokenId == this.selectedPaymentOption);
    if (!this.selectedPaymentOption) {
      this.utility.alert.toast({ title: 'Please select any payment method', type: 'error' });
      return;
    }
    this.savingInProgress = true;
    if (this.tempData?.Key == CONSTANTS.PAY_MODES.ATTACH) {
      let payload = {
        TokenId: selectedOption.TokenId,
        PlanHeaderID: this.tempData.Value.HeaderID
      }
      let endpoint = getApiUrl(apiList.paymentMethods.savePaymentMethod);
      this.http.post<ApiResponse>(endpoint, payload).subscribe((response) => {
        this.savingInProgress = false;
        this.utility.alert.toast({ title: 'Payment method changed successfully', type: 'success' });
        history.back();
      }, (err: HttpErrorResponse) => {
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
        this.savingInProgress = false;
      })
    } else {
      this.tempData.Value['CardData'] = selectedOption.Details;
      let payload = {
        ...this.tempData,
        Value: JSON.stringify(this.tempData.Value)
      }
      let endpoint = getApiUrl(apiList.temp.save);
      this.http.post<ApiResponse>(endpoint, payload).subscribe((response) => {
        this.savingInProgress = false;
        if (this.tempData.Key == CONSTANTS.PAY_MODES.NOW)
          this.router.navigate(['/payment/confirm-payment']);
        else if (this.tempData.Key == CONSTANTS.PAY_MODES.THIRTY || this.tempData?.Key == CONSTANTS.PAY_MODES.HALF) {
          this.router.navigate(['/payment/confirm-pay']);
        } else if (this.tempData.Key == CONSTANTS.PAY_MODES.OTHERS) {
          this.router.navigate(['/payment/confirm-other-payment'])
        } else if (this.tempData?.Key == CONSTANTS.PAY_MODES.ATTACH)
          this.router.navigate(['/dashboard/scheduled-payment-confirmation']);
        else {
          this.utility.setTempData('tempId', null);
          window.history.back();

        }

      }, (err: HttpErrorResponse) => {
        this.savingInProgress = false;
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      })
    }
  }
  addPaymentMethod() {
    this.utility.loader.next(true);
    if (this.utility.getTempData('tempId'))
      this.router.navigate(['/payment-methods/electronic-check']);
    else {
      let endpoint = getApiUrl(apiList.temp.save);
      let payload = {
        Key: CONSTANTS.PAY_MODES.ADD,
        Value: JSON.stringify({ BillData: [], Total: { balance: 0, paid: 0 } })
      };
      this.http.post<ApiResponse>(endpoint, payload).subscribe((data) => {
        if (data.Status == true) {
          this.utility.setTempData('tempId', data.Data);
          this.router.navigate(['/payment-methods/electronic-check'])
        } else {
          this.utility.loader.next(false);
          this.utility.alert.toast({ title: data.Message, type: 'error' });
        }
      }, (err: HttpErrorResponse) => {
        console.log(err);
        this.utility.loader.next(false);
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      })
    }
  }
  cancel() {
    history.back();
  }
}
