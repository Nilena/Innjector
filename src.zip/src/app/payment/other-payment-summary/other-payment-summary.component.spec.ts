import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OtherPaymentSummaryComponent } from './other-payment-summary.component';

describe('OtherPaymentSummaryComponent', () => {
  let component: OtherPaymentSummaryComponent;
  let fixture: ComponentFixture<OtherPaymentSummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [OtherPaymentSummaryComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OtherPaymentSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
