import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/auth/services/user.service';
import { getApiUrl, apiList } from 'src/app/core/constants/api-list';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { ApiResponse, Profile } from 'src/app/core/models/auth';
import { InstallmentDetails } from 'src/app/core/models/payment';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { PaymentService } from '../services/payment.service';

@Component({
  selector: 'app-other-payment-summary',
  templateUrl: './other-payment-summary.component.html',
  styleUrls: ['./other-payment-summary.component.css']
})
export class OtherPaymentSummaryComponent implements OnInit {

  public fetchingInProgress: boolean = false;
  public agreeTerms: boolean = false;
  public tempId: any;
  public tempData: any = null;
  public savingInProgress: boolean = false;
  public totalPaymentInfo: any = null;
  public billData: any[] = [];
  public cardData: any = null;
  public cardDataList: any[] = [];
  public termsAndCondition: string = '';
  public submitted: boolean = false;
  public showDuplicatePopup: boolean = false;
  public duplicateList: any[] = [];
  public selectedOption: InstallmentDetails | null = null;
  public firstPaymentDate: string | null = null;
  checkBoxSelected: boolean = false;
  emittedCheckedvalue: boolean = false;
  termsPopup: boolean = false;
  checkBoxEnable: boolean = false;
  userInfo: Profile | null = null;
  @ViewChild('summary') summary! : ElementRef;
  constructor(
    private utility: UtilityService,
    private http: HttpClient,
    private userService: UserService,
    private router: Router,
    private paymentService: PaymentService
  ) {
    this.tempId = this.utility.getTempData('tempId');
  }

  ngOnInit(): void {
    this.userInfo = this.userService.getUserInfo();
    this.getTempData();
  }
  ngAfterViewInit(){
    this.summary.nativeElement.focus();
 }

  cancel() {
    history.back();
  }


  public getTempData() {
    // this.fetchingInProgress = true;
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.temp.get + this.tempId);
    this.http.get<any>(endpoint).subscribe((response) => {
      if (response.Status == true) {
        this.tempData = response.Data;
        this.tempData.Value = JSON.parse(this.tempData.Value);
        this.totalPaymentInfo = this.tempData.Value.Total;
        this.billData = this.tempData.Value.BillData;
        this.cardData = this.tempData.Value.CardData[0];
        this.cardDataList = this.tempData.Value.CardData;
        this.selectedOption = this.tempData.Value.selectedOption;
        this.firstPaymentDate = this.selectedOption?.ScheduledInstallment[0] ? this.selectedOption?.ScheduledInstallment[0]?.ScheduledDate : null;
        this.termsAndCondition = (this.selectedOption ? this.selectedOption?.TermsAndCondition : '') as string;
      } else {
        this.utility.alert.toast({ title: response.Message, type: 'error' });
      }
      // this.fetchingInProgress = false;
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      // this.fetchingInProgress = false;
      this.utility.loader.next(false);
    })
  }

  private clearTempTable() {
    this.utility.setTempData('tempId', null);
    let endpoint = getApiUrl(apiList.temp.clear);
    this.http.get<ApiResponse>(endpoint).subscribe((response) => {

    }, (err: HttpErrorResponse) => {
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }

  checkBoxChanges() {
    if (this.checkBoxEnable) {
      this.emittedCheckedvalue = false;
      this.termsPopup = true;
    }else{
      this.emittedCheckedvalue = false;
    }
  }


  checkEnable() {
    this.emittedCheckedvalue = false;
    this.termsPopup = true;
  }

  checkValue(event: boolean) {
    if (event == true) {
      this.emittedCheckedvalue = true;
      this.checkBoxEnable = true
    } else {
      this.emittedCheckedvalue = false
      this.checkBoxEnable = false
    }
    this.termsPopup = false;
  }

  private getPaymentInfoList() {
    let data = [];
    for (let i = 0; i < this.cardDataList.length; i++) {
      let details: any = {};
      details.AccountName = this.cardDataList[i].AccountName;
      details.AccountNo = this.cardDataList[i].AccountNo;
      details.AccountType = this.cardDataList[i].AccountType;
      // details.Email = this.cardDataList[i].Email;
      details.Email = this.tempData.Value.CardData[i].Email ? this.tempData.Value.CardData[i].Email : this.userInfo?.EmailId;
      details.Nickname = this.cardDataList[i].MethodName;
      details.RoutingTransitNo = this.cardDataList[i].RoutingTransitNo;
      details.TokenId = this.cardDataList[i].TokenId;
      details.Token = this.cardDataList[i].Token;
      details.ExternalToken = this.cardDataList[i].ExternalToken;
      details.formattedCard = this.cardDataList[i].AccountNo;
      details.PaymentType = this.cardDataList[i].PaymentType;
      details.LastFourDigits = this.cardDataList[i].LastFourDigits;
      details.SaveStatus = this.cardDataList[i].SaveStatus;
      details.CcType = this.cardDataList[i].CcType;
      details.MerchantId = this.cardDataList[i].MerchantId;
      details.ParentTokenId = this.cardDataList[i].ParentTokenId;
      details.ProcessorType = this.cardDataList[i].ProcessorType;
      data.push(details);
    }
    return data;
  }

  public makePayment() {
    this.submitted = true;
    if (!this.emittedCheckedvalue) {
      return;
    }
    let text2 = this.totalPaymentInfo?.paid
    let text = 'You are setting up a plan for $' + text2 + ' with ' + this.selectedOption?.NoOfInstallment + ' installment(s) starting from ' + this.selectedOption?.FirstInstallmentDate;
    this.utility.alert.confirm({
      title: this.totalPaymentInfo.paid,
      text: text,
      type: 'warning',
      isTitleCash: true,
      okText: 'Yes'
    }).then(status => {
      if (status) {
        this.savingInProgress = true;
        this.utility.paymentLoader.next(true);
        let endpoint = getApiUrl(apiList.payment.ConfirmDistribution);
        let payString = {
          id: this.tempId,
          isGuest: false
        }
        let lpgToken = this.utility.getTempData(CONSTANTS.SESSION.LPG_TOKEN);
        let payload = {
          AccessToken: lpgToken ? lpgToken.access_token : null,
          PaymentInfoList: this.getPaymentInfoList(),
          InstallmentDetails: this.selectedOption,
          MakePaymentHeader: this.billData,
          PaymentRuleRequest: {
            PayOptions: 0
          },
          ProcessorType: this.cardData.ProcessorType ? (this.cardData.ProcessorType) : (this.tempData.Value.paymentProcessor),
          Transaction: {
            Email: this.cardData.Email,
            Nickname: (this.cardData.NickName) ? (this.cardData.NickName) : (this.cardData.Nickname),
            Station: this.billData[0] ? this.billData[0].StationCode : null,
            amount: this.totalPaymentInfo?.paid,
            instrumentType: (this.cardData.CcType) ? (this.cardData.CcType) : this.cardData.PaymentMethod,
            PaymentMethod: (this.cardData.PaymentMethod) ? (this.cardData.PaymentMethod) : (this.cardData.CcType)
          }
        }
        this.http.post<any>(endpoint, payload).subscribe((response) => {
          this.savingInProgress = false;
          this.utility.paymentLoader.next(false);
          this.utility.setTempData('paymentStatus', response);
          this.utility.setTempData('paymentKey', CONSTANTS.PAY_MODES.OTHERS);
          this.clearTempTable();
          this.router.navigate(['/payment/payment-status'])
        }, (err: HttpErrorResponse) => {
          this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
          this.savingInProgress = false;
          this.utility.paymentLoader.next(false);
        })
      }
    })


  }


}
