import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { getApiUrl, apiList } from 'src/app/core/constants/api-list';
import { ApiResponse, Profile } from 'src/app/core/models/auth';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { UserService } from 'src/app/auth/services/user.service';
import { ReceiptDetailsList ,ReceiptHeaderDetails} from 'src/app/core/models/print&email';
@Component({
  selector: 'app-print-receipt',
  templateUrl: './print-receipt.component.html',
  styleUrls: ['./print-receipt.component.css']
})
export class PrintReceiptComponent implements OnInit {

  uniqueAuthNos: any = []
  routeSub: any = null;
  receiptDetailsList: ReceiptDetailsList[] = [];
  receiptHeaderDetails: ReceiptHeaderDetails | ReceiptHeaderDetails | null = null;
  loader: boolean = false;
  userInfo: Profile | null = null;
  openSub: boolean = false;
  emailScreen: boolean = false;
  emailId: any = null;
  printScreen: boolean = false;
  constructor(router: Router,
    private route: ActivatedRoute,
    private http: HttpClient,
    private utility: UtilityService,
    private UserService: UserService,
    private Router: Router) {

  }
  ngOnInit(): void {
    this.loader = true;
    // this.utility.headerText$.next("Payment Receipt");
    this.route.params.subscribe(params => {
      this.routeSub = params['id'];
    });
    this.showReceipt();
    this.userInfo = this.UserService.getUserInfo();
  }

  showReceipt() {
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.paymentHistroy.ShowReceipt) + 'id=' + this.routeSub;
    this.http.get<ApiResponse>(endpoint).subscribe(response => {
      if (response.Status) {
        this.receiptDetailsList = response.Data.ReceiptDetailsList as ReceiptDetailsList[];
        this.receiptHeaderDetails = response.Data.ReceiptHeaderDetails as ReceiptHeaderDetails;
        this.emailId = this.receiptHeaderDetails.Email ? this.receiptHeaderDetails.Email : this.userInfo?.EmailId;
        this.loader = false;
        let uniAuthNos = this.receiptDetailsList.map((item) => {
          return item.AuthCode
        })
        uniAuthNos = [...new Set(uniAuthNos)];
        this.uniqueAuthNos = uniAuthNos;


        this.utility.loader.next(false);
      }
      else {
        this.loader = false;
        this.utility.loader.next(false);
        this.utility.alert.toast({ title: response.Message, type: 'error' })
      }
    }, (err: HttpErrorResponse) => {
      this.loader = false;
      this.utility.loader.next(false);
      this.utility.alert.toast({ title: 'Something went Worng!', type: 'error' })
    })
  }

  /*
   author:Nilena Aelxander
   dec:to print 
   */
  print() {
    (window as any).print();
  }

  cancel() {
    window.history.back();
  }
}
 
