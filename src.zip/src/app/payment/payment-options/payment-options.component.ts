import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { forkJoin } from 'rxjs';
import { UserService } from 'src/app/auth/services/user.service';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { ApiResponse } from 'src/app/core/models/auth';
import { InstallmentDetails } from 'src/app/core/models/payment';
import { UtilityService } from 'src/app/shared/services/utility.service';

@Component({
  selector: 'app-payment-options',
  templateUrl: './payment-options.component.html',
  styleUrls: ['./payment-options.component.css']
})
export class PaymentOptionsComponent implements OnInit {

  public fetchingInProgress: boolean = false;
  public installmentDetails: InstallmentDetails[] = [];
  public tempId: any;
  public value = new Date();
  public tempData: any = null;
  private date = new Date();
  public today = `${this.date.getFullYear()}-${this.date.getMonth() + 1}-${this.date.getDate()}`
  public selectedDate = new Date();
  public selectedPaymentOption: number = 0;
  public savingInProgress: boolean = false;
  public totalPaymentAmount: number = 0;
  dateMin: Date = new Date();
  dateMax: Date = new Date()
  @ViewChild('planoptions') planoptions! :ElementRef;
  constructor(
    private utility: UtilityService,
    private http: HttpClient,
    private userService: UserService,
    private router: Router) {
    this.tempId = this.utility.getTempData('tempId');
  }

  ngOnInit(): void {
    this.utility.headerText$.next('Bill Payment');
    this.getPaymentMethodCount();
    this.getTempData();

  }

  ngAfterViewInit(){
    this.planoptions.nativeElement.focus();
  }

  public getTempData() {
    this.fetchingInProgress = true;
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.temp.get + this.tempId);
    this.http.get<any>(endpoint).subscribe((response) => {
      if (response.Status == true) {
        this.tempData = response.Data;
        this.tempData.Value = JSON.parse(this.tempData.Value);
        this.totalPaymentAmount = this.tempData.Value.Total.paid;
        this.getPaymentOptions();
      } else {
        this.utility.alert.toast({ title: response.Message, type: 'error' });
      }
      this.fetchingInProgress = false;
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.fetchingInProgress = false;
      this.utility.loader.next(false);
    })
  }

  public paymentMethodCount: number = 0;
  public getPaymentMethodCount() {
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.payment.paymentMethodCount);
    this.http.get<ApiResponse>(endpoint).subscribe((response) => {
      if (response.Status == true) {
        this.paymentMethodCount = response.Data;
      }
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.utility.loader.next(false);
    })
  }

  public intiDate() {
    let selectedObj = this.installmentDetails.find(el => el.OptionNo == this.selectedPaymentOption);
    if (selectedObj) {
      this.dateMin = new Date(selectedObj.MinimumDate);
      this.dateMax = new Date(selectedObj.MaximumDate);
      this.selectedDate = new Date(selectedObj.FirstInstallmentDate);
    }
  }
  public changeDate() {
    let selectedObj = this.installmentDetails.find(el => el.OptionNo == this.selectedPaymentOption);
    if (selectedObj) {
      (selectedObj.FirstInstallmentDate) = this.formatForSavetoTemp(this.selectedDate);
    }
  }
  public getPaymentOptions() {
    this.fetchingInProgress = true;
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.payment.paymentInstallmentOptions);
    let payload = {
      payOptions: this.tempData.Key,
      PaymentPlanAmount: this.totalPaymentAmount
    }
    this.http.post<any>(endpoint, payload).subscribe((response) => {
      if (response.Status == true) {
        this.installmentDetails = response.Data.InstallmentDetails;
        if (this.installmentDetails && this.installmentDetails.length) {
          this.selectedPaymentOption = this.installmentDetails[0].OptionNo;
          this.intiDate();
        }
        // this.utility.alert.toast({ title: response.Message, type: 'success' });
      } else {
        this.utility.alert.toast({ title: response.Message, type: 'error' });
      }
      this.fetchingInProgress = false;
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.fetchingInProgress = false;
      this.utility.loader.next(false);
    })
  }
  public formatForApi(inputDate: any): any {
    var date = new Date(inputDate);
    if (date)
      if (!isNaN(date.getTime())) {
        if ((Number(date.getMonth()) + 1) < 10) {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
        else {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
      }
      else
        return undefined;
  }

  public formatForSavetoTemp(inputDate: any): any {
    var date = new Date(inputDate);
    if (date)
      if (!isNaN(date.getTime())) {
        if ((Number(date.getMonth()) + 1) < 10) {
          if (Number(date.getDate() < 10)) {
            return "0" + (Number(date.getMonth()) + 1) + "/0" + date.getDate() + "/" + date.getFullYear();
          }
          else {
            return "0" + (Number(date.getMonth()) + 1) + "/" + date.getDate() + "/" + date.getFullYear();
          }
        }
        else {
          if (Number(date.getDate() < 10)) {
            return (Number(date.getMonth()) + 1) + "/0" + date.getDate() + "/" + date.getFullYear();
          }
          else {
            return (Number(date.getMonth()) + 1) + "/" + date.getDate() + "/" + date.getFullYear();
          }
        }
      }
      else
        return undefined;
  }
  public continue() {
    this.savingInProgress = true;
    const selectedOption = this.installmentDetails.find((el) => el.OptionNo == this.selectedPaymentOption);
    this.updateScheduledItemsDate(selectedOption as InstallmentDetails);
    this.tempData.Value['selectedOption'] = selectedOption;
    let payload1 = {
      ...this.tempData,
      Value: JSON.stringify(this.tempData.Value)
    }
    let endpoint1 = getApiUrl(apiList.temp.save);
    let payload2 = {
      AmountBaseEdit: true,
      EditedInstallmentAmount: selectedOption?.InstallmentAmount,
      InstalmentStartDate: this.formatForApi(this.selectedDate),
      NoOfInstalment: selectedOption?.NoOfInstallment,
      PaymentPlanAmount: this.totalPaymentAmount,
      optionNo: selectedOption?.OptionNo
    }
    let endpoint2 = getApiUrl(apiList.payment.editInstallment);
    forkJoin([
      this.http.post<ApiResponse>(endpoint1, payload1),
      this.http.post<ApiResponse>(endpoint2, payload2)
    ]).subscribe((response) => {
      this.savingInProgress = false;
      if (this.paymentMethodCount == 0) {
        this.router.navigate(['/payment-methods/electronic-check']);
      } else {
        this.router.navigate(['/payment/methods']);
      }
    }, (err: HttpErrorResponse) => {
      this.savingInProgress = false;
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }

  updateScheduledItemsDate(selectedOption: InstallmentDetails) {
    let selectedDate = this.selectedDate;
    selectedOption.ScheduledInstallment.forEach(item => {
      item.ScheduledDate = this.formatForSavetoTemp(selectedDate);
      selectedDate = moment(selectedDate).add(1, 'month').toDate();
    })
  }
  goback() {
    history.back();
  }


}
