import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BalanceRequirigActionComponent } from './balance-requirig-action.component';

describe('BalanceRequirigActionComponent', () => {
  let component: BalanceRequirigActionComponent;
  let fixture: ComponentFixture<BalanceRequirigActionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [BalanceRequirigActionComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BalanceRequirigActionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
