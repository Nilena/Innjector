import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/auth/services/user.service';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { ApiResponse } from 'src/app/core/models/auth';
import { PaymentDetailsInfo, PaymentHeaderDetails, ValidationError } from 'src/app/core/models/payment';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { PaymentService } from '../services/payment.service';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { InlineToaster } from 'src/app/shared/components/inline-toast/inline-toast.component';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-balance-requirig-action',
  templateUrl: './balance-requirig-action.component.html',
  styleUrls: ['./balance-requirig-action.component.css']
})
export class BalanceRequirigActionComponent implements OnInit {

  public fetchingInProgress: boolean = false;
  public paymentDetailsInfo: PaymentDetailsInfo | null = null;
  public totalAmountToPay: number = 0;
  public validation: ValidationError = {}
  public paymentOptionList: any[];
  public selectedPaymentOption: any;
  public savingInProgress: boolean = false;
  public inputFocused: boolean = false;
  public errorMessage: string = '';
  public toastMessage: string = '';
  public showDuplicatePopup: boolean = false;
  public duplicateList: any[] = [];
  public hasDuplicate: boolean = false;
  public messageSwap: boolean = false;
  public phoneNumber: string = '';
  public paymentMethodCount: number = 0;
  private payModStringMap: any = {
    'payInThirty': 'pay in 30 days',
    'payInHalf': 'pay half now, half in 30 days',
    'x payNow': 'pay in 30 days',
  }
  @ViewChild('topToastMessage') public topToastMessage?: InlineToaster;
  @ViewChild('Balance') Balance! : ElementRef;
  private subscriptionMap: { [key: string]: Subscription } = {};

  constructor(
    private utility: UtilityService,
    private http: HttpClient,
    private userService: UserService,
    private router: Router,
    private paymentService: PaymentService
  ) {
    this.paymentOptionList = this.paymentService.paymentOptionList;
    this.clearTempTable();
  }
  ngOnInit(): void {
    this.subscriptionMap['phoneNumber'] = this.utility.phoneNumber$.subscribe(number => {
      this.phoneNumber = number;
      this.prepareDuplicateMessage();
    })
    this.utility.headerText$.next('Bill Payment');
    this.getPaymentMethodCount();
    this.paymentOptionSelected();
  }
  ngAfterViewInit(){
    this.Balance.nativeElement.focus();
 }

  private clearTempTable() {
    this.utility.setTempData('tempId', null);
    let endpoint = getApiUrl(apiList.temp.clear);
    this.http.get<ApiResponse>(endpoint).subscribe((response) => {

    }, (err: HttpErrorResponse) => {
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }

  public paymentOptionSelected() {
    let selectedPaymentOptionId = this.paymentService.getSelectedPaymentOption() || 1;
    let el = this.paymentOptionList.find(item => item.id == selectedPaymentOptionId);
    this.selectedPaymentOption = el;
    this.topToastMessage?.clearToast();
    this.getPaymentDetails();
  }

  public getPaymentMethodCount() {
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.payment.paymentMethodCount);
    this.http.get<ApiResponse>(endpoint).subscribe((response) => {
      if (response.Status == true) {
        this.paymentMethodCount = response.Data;
      }
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.utility.loader.next(false);
    })
  }

  public getPaymentDetails() {
    // this.fetchingInProgress = true;
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.payment.getPaymentDetails);
    this.http.post<ApiResponse>(endpoint, null).subscribe((response) => {
      if (response.Status == true) {
        if (response.Data && response.Data.PaymentDetails && response.Data.PaymentDetails.length) {
          for (let i = 0; i < response.Data.PaymentDetails.length; i++) {
            for (let j = 0; j < response.Data.PaymentDetails[i].PaymentHeaderDetails.length; j++) {
              if (response.Data.PaymentDetails[i].PaymentHeaderDetails[j].PaymentAmount)
                this.formatInputValue(response.Data.PaymentDetails[i].PaymentHeaderDetails[j])
            }
          }
        }

        this.paymentDetailsInfo = response.Data as PaymentDetailsInfo;
        this.backupOriginalAmount();
        this.updateTotalAmountToPay();
        this.openAllCollapsedItems();
        this.paymentDetailsInfo.PaymentDetails.forEach((el, i) => {
          el.PaymentHeaderDetails.forEach((item, j) => {
            this.validation[`${i}${j}`] = {};
          })
        })
        this.prepareDuplicateMessage();
        // this.utility.alert.toast({ title: response.Message, type: 'success' });
      } else {
        this.errorMessage = response.Message;
      }
      // this.fetchingInProgress = false;
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      // this.fetchingInProgress = false;
      this.utility.loader.next(false);
    })
  }
  public prepareDuplicateMessage() {
    if (this.paymentDetailsInfo) {
      this.paymentDetailsInfo.dupMsg = this.paymentDetailsInfo.duplicateMessage.replace("@phone@", this.phoneNumber);
      let dupMsgArr = this.paymentDetailsInfo.dupMsg.split('|');
      this.paymentDetailsInfo.dupMsg = dupMsgArr[0];
      this.paymentDetailsInfo.dupMsgFooter = dupMsgArr[1];

      this.paymentDetailsInfo.dupMsg_x = this.paymentDetailsInfo.duplicateMessage_x.replace("@phone@", this.phoneNumber);
    }
  }

  public backupOriginalAmount() {
    try {
      if (this.paymentDetailsInfo)
        this.paymentDetailsInfo.PaymentDetails.forEach(item => {
          item.PaymentHeaderDetails.forEach(el => {
            el['_backupPaymentAmount'] = el.PaymentAmount;
          })
        })
    } catch (err) {
      console.log(err);
    }
  }
  public updateTotalAmountToPay() {
    try {
      this.totalAmountToPay = 0;
      if (this.paymentDetailsInfo)
        this.paymentDetailsInfo.PaymentDetails.forEach(item => {
          let subTotal = 0;
          item.PaymentHeaderDetails.forEach(el => {
            subTotal += Number(el.PaymentAmount);
          })
          this.totalAmountToPay += subTotal;
        })
    } catch (err) {
      this.totalAmountToPay = this.paymentDetailsInfo?.TotalBalance || 0;
    }
  }
  public formatInputValue(item: any) {
    try {
      ("" == item.PaymentAmount || null == item.PaymentAmount) && (item.PaymentAmount = 0.00);
      item.PaymentAmount = parseFloat(item.PaymentAmount).toFixed(2);
      if (item.PaymentAmount == 'NaN') item.PaymentAmount = 0;
    } catch (er) {
      item.PaymentAmount = 0;
    }

  }


  private checkForPreviousPayments() {
    this.duplicateList = [];
    // payment.dupeTemp = [];
    let List = this.paymentDetailsInfo?.PaymentDetails || [];
    for(let i = 0; i < List.length; i++) {
      for (let j = 0; j < List[i].PaymentHeaderDetails.length; j++) {
        let currentBill = List[i].PaymentHeaderDetails[j];
        let currentTxDetails = currentBill && currentBill.txhistory;
        this.hasDuplicate = (this.paymentDetailsInfo?.duplicatecheckstatus as boolean) && this.checkForNowDupes(currentBill.txhistory, currentBill.PaymentAmount, currentBill.ChargeHeaderRowID);
        if (currentTxDetails && currentTxDetails.length > 0) {
          for (let k = 0; k < currentTxDetails.length; k++) {
            currentTxDetails[k].accNo = currentBill.PatientAccountNo;
            currentTxDetails[k].ClientType = currentBill.ClientType;
            currentTxDetails[k].client = currentBill.ClientName;
            currentTxDetails[k].claimNo = currentBill.BillNumber;
            // let messageSwap = (currentTxDetails[k].status == 'X' || currentTxDetails[k].status == 'O') ? true : false;
            this.hasDuplicate && (currentBill.PaymentAmount == currentTxDetails[k].amount) && this.duplicateList.push(currentTxDetails[k]);
            // messageSwap && payment.messageSwapCheck.push(messageSwap);
          }
        }

      }
    }
    // payment.messageSwap = payment.messageSwapCheck.length > 0 ? true : false;
    // this.duplicateList.length > 0 ? payment.showPrevPopup() : payment.payNowConfirm();

    if (this.duplicateList.length) {
      for (let k = 0; k < this.duplicateList.length; k++) {
        this.messageSwap = (this.duplicateList[k].status == 'X' || this.duplicateList[k].status == 'O') ? true : false;
        if (this.messageSwap) break;
      }
    }
  }

  private checkForNowDupes(transactions: any, payAmount: any, chrRowId: any) {
    let dupes = [];
    let retFlag = false;
    if (transactions) {
      for (let j = 0; j < transactions.length; j++) {
        if ((transactions[j].amount == payAmount) && (transactions[j].chargeheaderrowid == chrRowId)) {
          dupes.push(transactions[j]);
        }
      }
      retFlag = dupes.length > 0 ? true : false;
    }
    return retFlag;

  }
  /*
      author : Nilena Alexander
      desc   : for clear local storage
    */
  public logout() {
    let loginConfig = this.utility.getTempData(CONSTANTS.APP_CONFIG.login_config);
    this.userService.removeSession(true);
    try {
      if (loginConfig && loginConfig.eLogin == 1) {
        this.router.navigate(['/email-login' + loginConfig.token]);
      } else if (loginConfig.eLogin && loginConfig.eLogin == 2) {
        this.router.navigate(['/text-login' + loginConfig.token]);
      } else {
        this.router.navigate(['/user-login']);
      }
    } catch (err) {
      this.router.navigate(['/user-login']);
    }
  }
  public resetValidationState() {
    if (this.paymentDetailsInfo) {
      this.paymentDetailsInfo?.PaymentDetails.forEach((el) => {
        el.PaymentHeaderDetails.forEach(item => {
          (item as any)['error'] = false;
        })
      })
    }
  }
  public next(isDuplicate: boolean = false) {
    this.topToastMessage?.clearToast();
    this.resetValidationState();
    let user = this.userService.getUserInfo();
    if (user.IsGuest && (this.selectedPaymentOption.key == CONSTANTS.PAY_MODES.THIRTY ||
      this.selectedPaymentOption.key == CONSTANTS.PAY_MODES.HALF)) {
      this.utility.alert.confirm({
        text: 'To view other payment options, please login or create an account',
        type: 'warning',
        hideCancelButton: true,
        okText: 'Back to login',
        title: ''
      }).then(res => {
        if (res) {
          //this.loaderSub =true;
          this.logout();
        }
      })
      return;
    }
    if (this.isUserInputInvalid()) {
      return;
    }
    this.checkForPreviousPayments();
    if (this.duplicateList.length && !isDuplicate) {
      if (this.duplicateList.length && this.selectedPaymentOption.key == CONSTANTS.PAY_MODES.NOW) {
        this.showDuplicatePopup = true;
        window.scrollTo({ top: 0, behavior: "smooth" })
        return;
      }
    }

    if (this.payModStringMap[this.selectedPaymentOption.key]) this.gtmLog('Payment Choice', this.payModStringMap[this.selectedPaymentOption.key]);
    this.savingInProgress = true;
    let endpoint = getApiUrl(apiList.temp.save);
    let billData: PaymentHeaderDetails[] = [];
    this.paymentDetailsInfo?.PaymentDetails.forEach((el) => {
      el.PaymentHeaderDetails.forEach(item => {
        if (!(!item.PaymentAmount || Number(item.PaymentAmount) == 0)) {
          billData.push(item);
        }
      })
    })
    let total: any = {
      balance: this.paymentDetailsInfo?.TotalBalance,
      dupe: this.duplicateList,
      dupeMsgs: {
        prevPaymentMsg: this.paymentDetailsInfo?.dupMsg,
        prevPaymentMsgFooter: '',
        prevPaymentMsgSec: this.paymentDetailsInfo?.dupMsg_x,
        messageSwap: this.messageSwap
      },
      paid: this.totalAmountToPay.toFixed(2)
    }
    let facilities: string[] = billData.map(el => el.ClientCode);
    let payload = {
      Key: this.selectedPaymentOption.key,
      Value: JSON.stringify({
        BillData: billData,
        Total: total,
        facilities: facilities
      })
    };
    this.http.post<ApiResponse>(endpoint, payload).subscribe((response) => {
      this.savingInProgress = false;
      this.utility.setTempData('tempId', response.Data);
      if (user.IsGuest || this.paymentMethodCount == 0) {
        if (this.utility.isMobile()){
          this.router.navigate(['/payment-methods/electronic-check']);
        }else{
          this.router.navigate(['/payment-methods/add-payment-method']);
        }
      } else {
        this.router.navigate(['/payment/methods']);
      }

    }, (err: HttpErrorResponse) => {
      this.savingInProgress = false;
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }

  public gtmDupeLog(title: string, item: string) {
    let data: any = {};
    let user = this.userService.getUserInfo();
    data.event_title = title;
    item ? data.data_object = {
      item_selected: item,
      confirmation_number: null
    } : data.data_object = {};
    data.event_interactive = true;
    data.event_logged_in = user ? true : false;
    data.event_category = "Make a Payment";
    data.event_registration_type = user ? (user.IsGuest ? 'guest' : user.FromMHO ? 'mho' : 'epay') : null;
    data.event_facility = user ? user.ClientCode : null;
    data.event_user_id = user ? user.UserID : null;
    data.event_user_type = user ? 'patient' : null;
    data.event_success = true;
    data.event_session_id = user ? user.RequestToken : null;
    this.utility.googleTrack(data);
  }
  public gtmLog(title: string, item: string, category?: string) {
    let data: any = {};
    let user = this.userService.getUserInfo();
    data.event_title = title;
    item ? data.data_object = {
      item_selected: item
    } : data.data_object = {};
    data.event_interactive = true;
    data.event_logged_in = user ? true : false;
    data.event_category = category ? category : "Payment Plans";
    data.event_registration_type = user ? (user.IsGuest ? 'guest' : user.FromMHO ? 'mho' : 'epay') : null;
    data.event_facility = user ? user.ClientCode : null;
    data.event_user_id = user ? user.UserID : null;
    data.event_user_type = user ? 'patient' : null;
    data.event_success = true;
    data.event_session_id = user ? user.RequestToken : null;
    this.utility.googleTrack(data);
  }

  validateUserInputs(i: number, j: number, event: Event, item: any) {
    let data = this.paymentDetailsInfo?.PaymentDetails[i].PaymentHeaderDetails[i];
    let currentValue = (event.target as HTMLInputElement).value;
    try {
      if ((!currentValue) || Number(currentValue) == NaN) {
        this.validation[`${i}${j}`]['error'] = true;
        this.validation[`${i}${j}`]['message'] = 'Invalid inputs!'
      } else {
        this.validation[`${i}${j}`]['error'] = false;
        this.validation[`${i}${j}`]['message'] = ''
      }
      if ((parseFloat(item.BalanceRequiringAction) >= parseFloat(item.PaymentAmount))) {
        this.validation[`${i}${j}`]['error'] = false;
        this.validation[`${i}${j}`]['message'] = ''
      } else {
        this.validation[`${i}${j}`]['error'] = true;
        this.validation[`${i}${j}`]['message'] = 'Invalid inputs!'
      }
      this.updateTotalAmountToPay();
    } catch (err) {
      this.validation[`${i}${j}`]['error'] = true;
      this.validation[`${i}${j}`]['message'] = 'Invalid inputs!'
    }
  }
  private isUserInputInvalid() {
    if ((this.totalAmountToPay == 0) || (this.paymentDetailsInfo && (this.totalAmountToPay > this.paymentDetailsInfo?.TotalBalance))) {
      // this.utility.alert.toast({ type: 'warning', title: 'We are sorry, Please check whether the entered amount is valid (Payment amount is less than or equal to the balance amount and greater than zero)' });
      this.topToastMessage?.inlineToast({ type: 'warning', title: 'We are sorry, Please check whether the entered amount is valid (Payment amount is less than or equal to the balance amount and greater than zero)', __disableAutoClose: true });
      return true;
    }
    if (this.paymentDetailsInfo && this.selectedPaymentOption.key == CONSTANTS.PAY_MODES.HALF) {
      if (Number(this.totalAmountToPay) < ((Number(this.paymentDetailsInfo?.PayHalfMinAmount) + Number(this.paymentDetailsInfo?.PayHalfMinAmount)))) {
        let msg = Number(this.paymentDetailsInfo?.PayHalfMinAmount) * 2;
        // this.utility.alert.toast({ title: 'Plan amount should be greater than or equal to $' + msg, type: 'error' });
        this.topToastMessage?.inlineToast({ type: 'error', title: 'Plan amount should be greater than or equal to $' + msg, __disableAutoClose: true });
        return true;
      }
    }
    if (this.paymentDetailsInfo && this.selectedPaymentOption.key == CONSTANTS.PAY_MODES.THIRTY) {
      if (Number(this.totalAmountToPay) < (Number(this.paymentDetailsInfo?.PayThirtyMinAmount))) {
        let msg = Number(this.paymentDetailsInfo?.PayHalfMinAmount);
        // this.utility.alert.toast({ title: 'Plan amount should be greater than or equal to $' + msg, type: 'error' });
        this.topToastMessage?.inlineToast({ type: 'error', title: 'Plan amount should be greater than or equal to $' + msg, __disableAutoClose: true });
        return true;
      }
    }
    if (this.paymentDetailsInfo && (this.selectedPaymentOption.key == CONSTANTS.PAY_MODES.THIRTY || this.selectedPaymentOption.key == CONSTANTS.PAY_MODES.HALF)) {
      let invalid = false;
      this.paymentDetailsInfo?.PaymentDetails.forEach((el) => {
        el.PaymentHeaderDetails.forEach(item => {
          if (item.PaymentAmount && item.PaymentAmount > 0 && item.restricted_account_status == 0) {
            (item as any)['error'] = true;
            invalid = true;
          } else {
            (item as any)['error'] = false;
          }
        })
      })
      if (invalid) {
        this.showAlert();
        return true;
      }
    }
    if (this.paymentDetailsInfo) {
      let invalid = false;
      this.paymentDetailsInfo?.PaymentDetails.forEach((el) => {
        el.PaymentHeaderDetails.forEach(item => {
          if (Number(item.PaymentAmount) && Number(item.PaymentAmount) > 0 && Number(item.PaymentAmount) > Number(item._backupPaymentAmount)) {
            invalid = true;
            (item as any)['error'] = true;
          } else {
            (item as any)['error'] = false;
          }
        })
      })
      if(invalid) {
        this.topToastMessage?.inlineToast({ type: 'warning', title: 'We are sorry, Please check whether the entered amount is valid (Payment amount is less than or equal to the balance amount and greater than zero)', __disableAutoClose: true });
        return true;
      }
    }
    return false;
  }
  public showAlert() {
    this.utility.alert.confirm({
      title: 'Information',
      type: 'info',
      hideCancelButton: true,
      hideOkButton: true,
      text: 'This item can be part of a one-time payment but cannot be included in any scheduled payment or payment plan.'
    })
  }
  private openAllCollapsedItems() {
    this.paymentDetailsInfo?.PaymentDetails.forEach(el => {
      el._open = true;
    })
  }

  ngOnDestroy() {
    for (const key in this.subscriptionMap) {
      if (this.subscriptionMap[key]) this.subscriptionMap[key].unsubscribe();
    }
  }

}
