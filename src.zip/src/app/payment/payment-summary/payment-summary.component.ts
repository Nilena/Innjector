import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/auth/services/user.service';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { Profile, ApiResponse } from 'src/app/core/models/auth';
import { PaymentDetailsInfo } from 'src/app/core/models/payment';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { PaymentService } from '../services/payment.service';

@Component({
  selector: 'app-payment-summary',
  templateUrl: './payment-summary.component.html',
  styleUrls: ['./payment-summary.component.css']
})
export class PaymentSummaryComponent implements OnInit {

  public fetchingInProgress: boolean = false;
  public agreeTerms: boolean = false;
  public tempId: any;
  public tempData: any = null;
  public savingInProgress: boolean = false;
  public totalPaymentInfo: any = null;
  public billData: any[] = [];
  public cardData: any = null;
  public termsAndCondition: boolean = false;
  public TandCerr: boolean = false;
  public submitted: boolean = false;
  public showDuplicatePopup: boolean = false;
  public duplicateList: any[] = [];
  public userInfo: Profile;
  public phoneNumber: string = "";
  @ViewChild('summary') summary! : ElementRef;

  constructor(
    private utility: UtilityService,
    private http: HttpClient,
    private userService: UserService,
    private router: Router,
    private paymentService: PaymentService
  ) {
    this.tempId = this.utility.getTempData('tempId');
    this.userInfo = this.userService.getUserInfo();
    this.phoneNumber = this.utility.getTempData('phoneNumber');
  }

  ngOnInit(): void {
    this.getTempData();
  }
  ngAfterViewInit(){
    this.summary.nativeElement.focus();
 }

  public getTempData() {
    // this.fetchingInProgress = true;
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.temp.get + this.tempId);
    this.http.get<any>(endpoint).subscribe((response) => {
      if (response.Status == true) {
        this.tempData = response.Data;
        this.tempData.Value = JSON.parse(this.tempData.Value);
        this.totalPaymentInfo = this.tempData.Value.Total;
        this.billData = this.tempData.Value.BillData;
        this.cardData = this.tempData.Value.CardData[0];
        this.duplicateList = this.totalPaymentInfo.dupe;
        let phoneNumber = this.utility.getTempData('phoneNumber');
        if (this.totalPaymentInfo?.dupeMsgs?.prevPaymentMsg)
          this.totalPaymentInfo.dupeMsgs.prevPaymentMsg = this.totalPaymentInfo.dupeMsgs.prevPaymentMsg.replace("@phone@", '(844) 236-3525').split('|')[0];
        this.openAllCollapsedItems()
      } else {
        this.utility.alert.toast({ title: response.Message, type: 'error' });
      }
      // this.fetchingInProgress = false;
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      // this.fetchingInProgress = false;
      this.utility.loader.next(false);
    })
  }

  cancel() {
    history.back();
  }

  public makePayment() {
    this.submitted = true;

    if (!this.termsAndCondition)
      this.TandCerr = true

    if (this.totalPaymentInfo?.dupe?.length && !this.termsAndCondition) {
      return;
    }
    this.utility.alert.confirm({
      title: this.totalPaymentInfo.paid,
      text: 'Are you sure you want to pay the amount above?',
      type: 'warning',
      isTitleCash: true,
      okText: 'Yes'
    }).then(status => {
      if (status) {
        this.savingInProgress = true;
        this.utility.paymentLoader.next(true);
        let endpoint = getApiUrl(apiList.payment.makePayment);
        let payString = {
          id: this.tempId,
          isGuest: this.userInfo.IsGuest
        }
        let payload = {
          "": false,
          ActionName: "Payment",
          PaynowStr: btoa(JSON.stringify(payString)),
          id: 0
        }
        this.http.post<any>(endpoint, payload).subscribe((response) => {
          this.savingInProgress = false;
          this.utility.paymentLoader.next(false);
          this.utility.setTempData('paymentStatus', response);
          // localStorage.setItem('key', 'payNow');
          this.utility.setTempData('paymentKey', 'payNow');
          this.clearTempTable();
          this.router.navigate(['/payment/payment-status']);
        }, (err: HttpErrorResponse) => {
          this.savingInProgress = false;
          this.utility.paymentLoader.next(false);
          this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
        })
      }
    })
  }

  private clearTempTable() {
    this.utility.setTempData('tempId', null);
    let endpoint = getApiUrl(apiList.temp.clear);
    this.http.get<ApiResponse>(endpoint).subscribe((response) => {

    }, (err: HttpErrorResponse) => {
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }
  private openAllCollapsedItems() {
    this.billData.forEach(el => {
      el._open = false;
    })
  }
}
