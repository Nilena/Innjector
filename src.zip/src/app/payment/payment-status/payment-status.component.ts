import { HttpClient } from '@angular/common/http';
import { Component, NgZone, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/auth/services/user.service';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { Profile } from 'src/app/core/models/auth';

@Component({
  selector: 'app-payment-status',
  templateUrl: './payment-status.component.html',
  styleUrls: ['./payment-status.component.css']
})
export class PaymentStatusComponent implements OnInit {

  public paymentStatus: any = null;
  public keyName: any = '';
  userInfo: Profile | null = null;
  public emailID: string = "";

  constructor(
    private utility: UtilityService,
    private http: HttpClient,
    private userService: UserService,
    private router: Router,
    private ngZone: NgZone
  ) {
    this.keyName = this.utility.getTempData('paymentKey');
    this.paymentStatus = this.utility.getTempData('paymentStatus');
    this.emailID = this.userService.getUserInfo().EmailId;

    if (!this.paymentStatus) {
      this.utility.setTempData('paymentStatus', null);
      this.utility.setTempData('paymentKey', null);
      this.router.navigate(['/dashboard']);
    } else if (this.paymentStatus.Status && !this.paymentStatus.hideSurvey) {
      this.utility.surveyTrigger$.next(1);
      this.paymentStatus.hideSurvey = true;
      this.utility.setTempData('paymentStatus', this.paymentStatus);
      const payModStringMap: any = {
        'payInThirty': 'pay in 30 days',
        'payInHalf': 'pay half now, half in 30 days',
        'x payNow': 'pay in 30 days',
      }
      if (payModStringMap[this.keyName]) this.gtmLog('Completed', payModStringMap[this.keyName]);
    }
    if (this.paymentStatus.Status) {
      this.userService.refetchUserDetails(() => {
        if (!this.paymentStatus.hideRmexPopup) {
          this.paymentStatus.hideRmexPopup = true;
          this.utility.setTempData('paymentStatus', this.paymentStatus);
          setTimeout(() => {
            this.ngZone.run(() => {
              let userInfo = this.userService.getUserInfo();
              if (this.paymentStatus.Data.IsRmexPayment && (userInfo?.UserPaymentDetails.BalanceRequiringAction || 0) > 0) {
                this.utility.alert.confirm({
                  title: '',
                  text: 'You have other accounts with balance. Do you want to make that payment now?',
                  type: 'info',
                  okText: 'Yes',
                  cancelText: 'No'
                }).then(res => {
                  if (res) {
                    this.router.navigate(['/payment/pay']);
                  }
                })
              }
            })
          }, 3000)
        }
      });
    }
  }

  print() {
    let encString = btoa(JSON.stringify({ PaymentTransactionId: this.paymentStatus.Data.TxId }));
    this.router.navigate(['/payment/print/' + encString]);
  }
  email() {
    let encString = btoa(JSON.stringify({ PaymentTransactionId: this.paymentStatus.Data.TxId }));
    this.router.navigate(['/payment/email/' + encString]);
  }
  ngOnInit(): void {
  }

  public gtmLog(title: string, item: string, category?: string) {
    let data: any = {};
    let user = this.userService.getUserInfo();
    data.event_title = title;
    item ? data.data_object = {
      item_selected: item
    } : data.data_object = {};
    data.event_interactive = true;
    data.event_logged_in = user ? true : false;
    data.event_category = category ? category : "Payment Plans";
    data.event_registration_type = user ? (user.IsGuest ? 'guest' : user.FromMHO ? 'mho' : 'epay') : null;
    data.event_facility = user ? user.ClientCode : null;
    data.event_user_id = user ? user.UserID : null;
    data.event_user_type = user ? 'patient' : null;
    data.event_success = true;
    data.event_session_id = user ? user.RequestToken : null;
    this.utility.googleTrack(data);
  }

}
