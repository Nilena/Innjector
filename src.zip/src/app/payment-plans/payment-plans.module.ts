import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SharedModule } from '../shared/shared.module';

import { PaymentListingComponent } from './payment-listing/payment-listing.component';
import { PrintPaymentPlansComponent } from './print-payment-plans/print-payment-plans.component';
import { RoleGuardService } from '../shared/services/role-guard.service';

export const routes: Routes = [
  {
    path: 'list', component: PaymentListingComponent
  },
  {
    path: 'list/:view', component: PaymentListingComponent
  },
  {
    path: 'print/:id', component: PrintPaymentPlansComponent
  },
]

@NgModule({
  declarations: [
    PaymentListingComponent,
    PrintPaymentPlansComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    SharedModule,
    RouterModule.forChild(routes)
  ]
})
export class PaymentPlansModule { }
