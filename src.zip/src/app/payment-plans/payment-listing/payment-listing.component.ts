import { query, style, animate, trigger, transition, AnimationMetadata, group } from '@angular/animations';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/auth/services/user.service';
import { getApiUrl, apiList } from 'src/app/core/constants/api-list';
import { ApiResponse, Profile, RmexScheduledPaymentInfo, StanderdSliderInfo, ScheduledPaymentInfo } from 'src/app/core/models/auth';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { CONSTANTS } from 'src/app/core/constants/constants';

@Component({
  selector: 'app-payment-listing',
  templateUrl: './payment-listing.component.html',
  styleUrls: ['./payment-listing.component.css']
})
export class PaymentListingComponent implements OnInit {


  public dataArr: { [key: string]: string }[] = CONSTANTS.dataArr;

  public statusMap: { [key: string]: string } = CONSTANTS.statusMap;
  public statusClassMap: { [key: string]: string } = CONSTANTS.statusClassMap;

  public fetchingInProgress: boolean = false;
  public scheduledPaymentInfo: StanderdSliderInfo[] = [];
  public activeIndex: number = 0;
  paymentPlansStaus: string = 'A,S';
  displayPaymentArrangement: boolean = false;
  showDiv: boolean = true;
  clickedItem : number = -1;
  @ViewChild('Plans') Plans! : ElementRef;

  public config = {
    slidesPerView: 1,
    centeredSlides: true,
    watchOverflow: true,
    spaceBetween: 20,
    init: true,
    // autoplay:true,
    pagination: true,
    navigation: true,
  }
  userInfoData: Profile | null = null;
  setItems: any = [];
  ScheduledTotal: number | null = null;
  TotalMonthlyPayments: number | null = null;
  constructor(
    private utility: UtilityService,
    private http: HttpClient,
    private userService: UserService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {
  }

  ngOnInit(): void {
    this.utility.headerText$.next('Payment Plans')
    this.userInfoData = this.userService.getUserInfo();
    this.utility.loader.next(true);
    this.getFilterItems();
    this.fetchDashboardData();
    let headerdata = this.activatedRoute.snapshot.paramMap.get('view');
    if (headerdata) {
      this.displayPaymentArrangement = true;
    } else {
      this.displayPaymentArrangement = false;
    }
  }
  ngAfterViewInit(){
    this.Plans.nativeElement.focus();
 }

  /*
      author : Nilena Alexander
      desc   :to get data from multiselector
    */
  selectChange(event: []): void {
    if (event)
      this.paymentPlansStaus = event.toString();
    else
      this.paymentPlansStaus = 'N';
    this.fetchDashboardData();

  }

  /*
    author : Nilena Alexander
    desc   :for show and hide menu bar
  */
  getFilterItems() {
    //this.fetchingInProgress = true;
    this.utility.loader.next(true);
    this.showDiv = false;
    let endpoint: string = ''
    if (this.userInfoData?.ClientGroupID)
      endpoint = getApiUrl(apiList.paymentPlans.filterItem) + '?ClientGroupId=' + this.userInfoData?.ClientGroupID;
    else
      endpoint = getApiUrl(apiList.paymentPlans.filterItem) + '?ClientGroupId=';
    this.http.get<ApiResponse>(endpoint).subscribe((response) => {
      if (response.Status == true) {
        this.dataArr = response.Data.PaymentPlanStatus;
        this.setItems = this.dataArr.filter((el: any) => el.IsActive)
        if (!this.setItems.length) {
          this.setItems = this.dataArr.filter((el: any) => {
            return el.Code == 'A' || el.Code == 'S'
          }).map((item: any) => item.Code)
        }
        //this.fetchingInProgress = false;
        this.utility.loader.next(false);
        this.showDiv = true;
        // let active = this.dataArr.find((el:any) =>{
        //   el.code=='A'
        // })

      } else {
        this.utility.alert.toast({ title: response.Message, type: 'error' });
        //this.fetchingInProgress = false;
        this.utility.loader.next(false);
        this.showDiv = true;
      }
      //this.fetchingInProgress = false;
      this.utility.loader.next(false);
      this.showDiv = true;
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      //this.fetchingInProgress = false;
      this.utility.loader.next(false);
      this.showDiv = true;
    })
  }
  /*
    author : Nilena Alexander
    desc   :to get data for dashboard
  */
  public fetchDashboardData() {
    this.scheduledPaymentInfo = []
    //this.fetchingInProgress = true;
    this.utility.loader.next(true);
    this.showDiv = false;
    let endpoint = getApiUrl(apiList.paymentPlans.paymentPlanStatus) + 'paymentPlanStatus=' + this.paymentPlansStaus;
    this.http.post<ApiResponse>(endpoint, this.paymentPlansStaus).subscribe((response) => {
      if (response.Status == true) {
        const normalItems = response.Data as ScheduledPaymentInfo;
        this.ScheduledTotal = response.Data.ScheduledTotal;
        this.TotalMonthlyPayments = response.Data.TotalMonthlyPayments;

        (normalItems.ScheduledPayment || []).forEach(el => {
          const data: any = {
            AmountDue: el.AmountDue,
            AmountPaid: el.AmountPaid,
            RemainingBalance: el.RemainingBalance,
            Rmx: false,
            InstallmentDate: el.InstallmentDate,
            PlanAmount: el.PlanAmount,
            Percentage: this.getPercentage(el.AmountPaid, el.PlanAmount),
            HeaderID: el.HeaderID,
            PlanStatus: el.PlanStatus,
            IsRmex: false,
            NextPaymentAmount: el.NextPaymentAmount
          }
          this.scheduledPaymentInfo.push(data);
        })
        const rmexItems = response.Data.RmexSchedulePaymentDetails as RmexScheduledPaymentInfo[];
        (rmexItems || []).forEach(el => {
          const data: StanderdSliderInfo = {
            AmountDue: el.AmountDue,
            AmountPaid: el.PaidAmount,
            RemainingBalance: el.RemainingBalance,
            Rmx: true,
            Percentage: 0,
            InstallmentDate: el.NextpaymentDate,
            PlanAmount: 0,
            HeaderID: 0,
            PlanStatus: '',
            IsRmex: true,
            NextPaymentAmount: el.NextPaymentAmount

          }
          this.scheduledPaymentInfo.push(data);
        })
        // this.fetchingInProgress = false;
        this.utility.loader.next(false);
        this.showDiv = true;
      } else {
        this.utility.alert.toast({ title: response.Message, type: 'error' });
      }
      //this.fetchingInProgress = false;
      this.utility.loader.next(false);
      this.showDiv = true;
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      //this.fetchingInProgress = false;
      this.utility.loader.next(false);
      this.showDiv = true;
    })
  }

  /*
    author : Nilena Alexander
    desc   :to route edit detail
    */
  public savingInProgress: boolean = false;
  public gotPlanDetails(plan: StanderdSliderInfo,i:number) {
    this.clickedItem = i;
    this.savingInProgress = true;
    this.SaveTemp(plan.HeaderID);
    let data = btoa(JSON.stringify({ HeaderID: plan.HeaderID }))
  }
  /*
   author : Nilena Alexander
   desc   :to save data in temp api
   */
  SaveTemp(data: number) {
    this.savingInProgress = true;
    let endpoint = getApiUrl(apiList.temp.save);
    let payload = {};
    payload = {
      Key: CONSTANTS.PAY_MODES.ATTACH,
      Value: JSON.stringify({
        BillData: [],
        Total: { balance: 0, paid: 0 },
        HeaderID: data
      })
    }
    this.http.post<ApiResponse>(endpoint, payload).subscribe((res: any) => {
      if (res.Status == true) {
        this.utility.setTempData('tempId', res.Data);
        this.router.navigate(['/dashboard/scheduled-payment-confirmation']);
      }
    },
      (err: HttpErrorResponse) => {
        console.log(err);
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      })
  }

  gotodashboard() {
    this.router.navigate(['/dashboard']);
  }
  /*
     author : Nilena Alexander
     desc   :to get %
     */
  private getPercentage(value: number, total: number): number {
    return Math.round((value / total) * 100);
  }

}




