import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/auth/services/user.service';
import { getApiUrl, apiList } from 'src/app/core/constants/api-list';
import { ApiResponse, Profile, PaymentPlanDetails, PaymentPlanHeaderDetails } from 'src/app/core/models/auth';
import { UtilityService } from 'src/app/shared/services/utility.service';
@Component({
  selector: 'app-print-payment-plans',
  templateUrl: './print-payment-plans.component.html',
  styleUrls: ['./print-payment-plans.component.css']
})
export class PrintPaymentPlansComponent implements OnInit {

  headerId: any = null;
  public fetchingInProgress: boolean = false;
  MakePaymentHeaderList: any = [];
  public paymentPlanDetails: PaymentPlanDetails | null = null;
  PaymentPlanHeaderDetails: PaymentPlanHeaderDetails | null = null;
  userInfo: Profile | null = null;
  today: any;
  constructor(
    private utility: UtilityService,
    private http: HttpClient,
    private userService: UserService,
    private router: Router,
    private activatedRoute: ActivatedRoute) {
    this.headerId = this.activatedRoute.snapshot.paramMap.get('id');
    // this.headerId = atob(headerId as string);

  }
  ngOnInit(): void {
    this.today = new Date();
    this.getPaymentPlanDetails();
    this.userInfo = this.userService.getUserInfo();
  }

  /*
    author:Nilena Aelxander
    dec:to to get data
    */
  public getPaymentPlanDetails() {
    // this.fetchingInProgress = true;
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.dashboard.getPaymentPlanDetails + this.headerId);
    this.http.get<ApiResponse>(endpoint).subscribe((response) => {
      if (response.Status == true) {
        this.paymentPlanDetails = response.Data as PaymentPlanDetails;
        this.MakePaymentHeaderList = response.Data.MakePaymentHeaderList;
        this.PaymentPlanHeaderDetails = response.Data.PaymentPlanHeaderDetails as PaymentPlanHeaderDetails;
      }
      else
        this.utility.alert.toast({ title: response.Message, type: 'error' });
      //this.fetchingInProgress = false;
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      //this.fetchingInProgress = false;
      this.utility.loader.next(false);
    })
  }
  /*
  author:Nilena Aelxander
  dec:to go back
  */
  cancel() {
    window.history.back();
    // this.router.navigate(['/dashboard/scheduled-payment-confirmation' + JSON.parse(this.headerId)])
  }
  /*
   author:Nilena Aelxander
   dec:to print 
   */
  print() {
    window.print();
  }

  ngOnDestroy() {
  }
}
