import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrintPaymentPlansComponent } from './print-payment-plans.component';

describe('PrintPaymentPlansComponent', () => {
  let component: PrintPaymentPlansComponent;
  let fixture: ComponentFixture<PrintPaymentPlansComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PrintPaymentPlansComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrintPaymentPlansComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
