import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HistroyListingComponent } from './histroy-listing.component';

describe('HistroyListingComponent', () => {
  let component: HistroyListingComponent;
  let fixture: ComponentFixture<HistroyListingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HistroyListingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HistroyListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
