import { Component, OnInit, HostListener, ViewChild, ElementRef } from '@angular/core';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { UserService } from 'src/app/auth/services/user.service';
import { Router } from '@angular/router';
import { ApiResponse } from 'src/app/core/models/auth';
import { getApiUrl, apiList } from 'src/app/core/constants/api-list';
import { Pagination, paymentHistroyDetails } from '../../core/models/histroy and online state';

@Component({
  selector: 'app-histroy-listing',
  templateUrl: './histroy-listing.component.html',
  styleUrls: ['./histroy-listing.component.css']
})
export class HistroyListingComponent implements OnInit {
  expandIcon: boolean = false;
  loader: boolean = false;
  openFilter: boolean = false;
  filterApplied: boolean = false;
  showDiv: boolean = true;
  totalItems: number = 0;
  currentPage: number = 1;
  totalCount : number = 0;
  payload: any = {

  };
  paymentHistroyDetails: paymentHistroyDetails[] = [];
  paginationDetails: Pagination = {
    CurrentPage: 1,
    RecordsPerPage: 20
  };

  paginationDetailsDesktop: Pagination = {
    CurrentPage: 1,
    RecordsPerPage: 10
  };
  @ViewChild('table') table! : ElementRef;
  @ViewChild('scrollMe') private myScrollContainer: ElementRef | null = null;

  constructor(private utility: UtilityService,
    private https: HttpClient,
    private userService: UserService,
    private router: Router) { }



  @HostListener("window:scroll", ["$event"]) onWindowScroll(): void {

    if (this.utility.isMobile()){
      if ((window.innerHeight + window.scrollY) > (this.myScrollContainer?.nativeElement?.offsetHeight - 100)) {
        if (!this.loader && (this.paymentHistroyDetails && this.paymentHistroyDetails.length >= 20) && (this.paginationDetails.TotalPages !== this.paginationDetails.CurrentPage)) {
          this.paginationDetails.CurrentPage = this.paginationDetails.CurrentPage + 1;
          this.getHistroyDetails();
        }
      }
    }
  }
  

  ngOnInit(): void {
    // this.loader = true;
    if (this.utility.isMobile()) {
      this.getHistroyDetails();
    } else {
      this.getHistroyDetailsDesktop();
    }
  }
  
  ngAfterViewInit(){
    this.table.nativeElement.focus();
 }


  pageChange(pageNumber: number) {
    // console.log(pageNumber)
    this.paginationDetailsDesktop.CurrentPage = pageNumber
    this.getHistroyDetailsDesktop()
    this.paymentHistroyDetails = []
  }

  getHistroyDetailsDesktop(): void {
    this.loader = true;
    this.showDiv = false;
    this.payload.Pagination = this.paginationDetailsDesktop;
    let endpoint = getApiUrl(apiList.paymentHistroy.BasicPaymentHistory)
    this.https.post<ApiResponse>(endpoint, this.payload).subscribe(data => {
      if (data.Status == true) {
        this.paymentHistroyDetails.push(...data.Data.paymentHistoryBasicDetails as paymentHistroyDetails[]);
        this.totalItems = data.Data.pagination?.TotalRecords;
        this.totalCount=Math.floor(this.totalItems/this.paginationDetailsDesktop.RecordsPerPage)
        this.loader = false;
        this.showDiv = true;
      }
      else {

        this.utility.alert.toast({ title: data.Message, type: 'error' });
      }
    },
      (err: HttpErrorResponse) => {
        this.utility.alert.toast({ title: err.error.message, type: 'error' });
        this.loader = false;
        this.showDiv = true;
      })
  }



  /*
    author : Nilena Alexander
    desc   : to get histroyDetails
    */
  getHistroyDetails(): void {
    this.loader = true;
    this.showDiv = false;
    this.payload.Pagination = this.paginationDetails;
    let endpoint = getApiUrl(apiList.paymentHistroy.BasicPaymentHistory)
    this.https.post<ApiResponse>(endpoint, this.payload).subscribe(data => {
      if (data.Status == true) {
        this.paginationDetails = data.Data.pagination as Pagination;
        this.paymentHistroyDetails.push(...data.Data.paymentHistoryBasicDetails as paymentHistroyDetails[]);
        this.loader = false;
        this.showDiv = true;
      }
      else {
        this.loader = false;
        this.showDiv = true;
        this.utility.alert.toast({ title: data.Message, type: 'error' });
      }
    },
      (err: HttpErrorResponse) => {
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
        this.loader = false;
      })
  }

  /*
  author : Nilena Alexander
  desc   : to get selected filter data
  */
  slectedFilers(event: any) {
    this.paymentHistroyDetails = [];
    this.loader = true;
    if (event) {
      // console.log("EVENT",event)
      this.filterApplied = true;
      this.openFilter = false;
      this.payload = event;
      if (this.paginationDetails)
        this.paginationDetails.CurrentPage = 1;
      else {
        this.paginationDetails = {
          CurrentPage: 1,
          RecordsPerPage: 20
        };
      }
      this.payload.Pagination = this.paginationDetails;
      window.scrollTo(0, 0)
      this.getHistroyDetails();
    } else {
      this.payload = {};
      if (this.paginationDetails)
        this.paginationDetails.CurrentPage = 1;
      else {
        this.paginationDetails = {
          CurrentPage: 1,
          RecordsPerPage: 20
        };
      }
      window.scrollTo(0, 0)
      this.getHistroyDetails();
      this.openFilter = false;
      this.filterApplied = false;
    }
  }

  filter(event: boolean) {
    (event == false) ? (this.openFilter = false) : null;
  }


  slectedFilersDesktop(event: any) {
    // console.log("DF",event)
    this.paymentHistroyDetails = [];
    if (event) {
      // console.log("EVENT",event)
      this.payload = event;
      if (this.paginationDetailsDesktop)
        this.paginationDetailsDesktop.CurrentPage = 1;
      else {
        this.paginationDetailsDesktop = {
          CurrentPage: 1,
          RecordsPerPage: 10
        };
      }
      this.payload.Pagination = this.paginationDetailsDesktop;
      this.getHistroyDetailsDesktop();
    } else {
      this.payload = {};
      if (this.paginationDetailsDesktop)
        this.paginationDetailsDesktop.CurrentPage = 1;
      else {
        this.paginationDetailsDesktop = {
          CurrentPage: 1,
          RecordsPerPage: 10
        };
      }
      this.getHistroyDetailsDesktop();

    }
  }


  /*
  author : Nilena Alexander
  desc   : to view details
  */
  viewDetails(item: any) {
    let id = {
      'IsConsolidated': item.IsConsolidated,
      'PaymentTransactionId': item.PaymentTransactionId,
    }
    this.router.navigate(['/payment-history/consolidated-receipt/' + btoa(JSON.stringify(id))])
  }


}
