import { Component, OnInit, Output, EventEmitter, Input, ViewChild, ElementRef } from '@angular/core';
import { CONSTANTS } from 'src/app/core/constants/constants';
import { payload } from 'src/app/core/models/histroy and online state';
import { UtilityService } from 'src/app/shared/services/utility.service';

@Component({
  selector: 'app-payment-filter',
  templateUrl: './payment-filter.component.html',
  styleUrls: ['./payment-filter.component.css']
})
export class PaymentFilterComponent implements OnInit {
  regexp = /^-{0,1}\d*\.{0,1}\d+$/;
  dateErr: boolean = false
  receiptNo: string = '';
  paidFrom: string = '';
  paidTo: string = '';
  amountFrom: string = '';
  amountTo: string = '';
  dataArr:  { [key: string]: any }[] =CONSTANTS.histroyfiter;
  setItems: any = [];
  payLoadObj: payload | {} = {};
  PaymentMethod: string = '';
  PaymentMethods: any = [];
  amountErr: boolean = false;
  dateInvalid: boolean = false;
  dateOutofBound: boolean = false;
  constructor(private utility:UtilityService) { }
  @Output() selectedValues = new EventEmitter();
  @Output() closeFilter = new EventEmitter();
  @ViewChild('ReceiptNo') ReceiptNo! : ElementRef;
  @Input() set selectedInput(value: payload) {

    this.receiptNo = value.RecieptNo ? value.RecieptNo : '';
    this.paidFrom = (value.PaidFromDate) ? value.PaidFromDate : '';
    this.paidTo = (value.PaidToDate) ? value.PaidToDate : '';
    this.amountFrom = (value.AmountStartRange) ? value.AmountStartRange : '';
    this.amountTo = (value.AmountEndRange) ? value.AmountEndRange : '';
    if (value.PaymentMethods) {
      this.setItems = [...(value.PaymentMethods.map((el: any) => el.Code))]
    } else {
      this.setItems = []
    }
  }

  ngOnInit(): void {
    // this.dataArr = CONSTANTS.histroyfiter;
  }
  ngAfterViewInit(){
    this.ReceiptNo.nativeElement.focus();
 }
  /*
   author : Nilena Alexander
   desc   : to set data from multiselect
   */
  selectChange(event: any) {
    if (event) {
       //this.setItems = event;
      this.PaymentMethods= [];
      for (let i = 0; i < this.dataArr.length; i++) {
        for (let j = 0; j < event.length; j++) {

          if (event[j] == this.dataArr[i].Code) {
            // delete this.dataArr[i].status;
            this.PaymentMethods.push(this.dataArr[i])
          }
        }
      }
      this.PaymentMethod = (event).toString();
    }
    else{
      this.PaymentMethod ='';
      this.PaymentMethods =[];
      this.setItems = [];
    }

  }
  /*
     author : Nilena Alexander
     desc   : to cancel all data
     */
  cancel() {
    if (this.utility.isMobile()) {
      this.receiptNo = '';
      this.paidFrom = '';
      this.paidTo = '';
      this.amountFrom = '';
      this.amountTo = '';
      this.dataArr = [];
      this.setItems = [];
      this.PaymentMethods = [];
      this.PaymentMethod = '';
      this.selectedValues.emit(null);
    }
    else {
      this.receiptNo = '';
      this.paidFrom = '';
      this.paidTo = '';
      this.amountFrom = '';
      this.amountTo = '';
      //this.dataArr = [];
      this.setItems = [];
      this.PaymentMethods = [];
      this.PaymentMethod = '';
      this.selectedValues.emit(null);

    }
  }




  close() {
    this.closeFilter.emit(false);

  }

  valuechange(event: any) {
    if (this.amountFrom == "" || this.amountTo == "") {
      this.amountErr = false;
    }
    else if ((parseInt(this.amountFrom) > parseInt(this.amountTo))) {
      this.amountErr = true;
    }
    else if (!(this.regexp.test(this.amountFrom) || (this.regexp.test(this.amountTo)))) {
      this.amountErr = true;
    }
    else {
      this.amountErr = false;
    }
  }

  //for checking input has valid dates
  validatorFunc(givenDate: string): boolean | undefined {
    let today = new Date().getTime();
        let date = givenDate ? new Date(givenDate).getTime() : null;
        if (!date) {
            this.dateInvalid = true
            return false
        }
        let date2 = givenDate ? new Date(givenDate).getTime() : null;
        if (date && date > today) {
            this.dateInvalid = true
            return false
        } 

        let timestamp  = Date.parse(givenDate);
        let dateObject = new Date(timestamp);
        let dateYear = dateObject.getFullYear();
        let curYear = new Date().getFullYear()

        if(dateYear<1900){
          this.dateOutofBound = true;
          return false
        }

    return true
  }


  /*
     author : Nilena Alexander
     desc   : to apply filter
     */
  apply() {
    this.dateInvalid = false
    this.dateOutofBound = false

    if (this.paidFrom != "") {
      this.validatorFunc(this.paidFrom)
      if (!this.validatorFunc(this.paidFrom))
        return
    }
    if (this.paidTo != "") {
      this.validatorFunc(this.paidTo)
      if (!this.validatorFunc(this.paidTo))
        return
    }

    if(this.PaymentMethod=="" && this.setItems.length){
      this.selectChange(this.setItems)
    }

    this.dateErr = false;
    this.amountErr = false;
    if (this.dateInvalid || this.dateOutofBound) {
      return
    }
    else if (this.paidFrom > this.paidTo) {
      this.dateErr = true
    }
    else if (parseFloat(this.amountFrom) > parseFloat(this.amountTo)) {
      this.amountErr = true;
    }

    else if (this.PaymentMethod || this.PaymentMethods.length || this.receiptNo || this.amountFrom
      || this.amountTo || this.paidFrom || this.paidTo) {


      let obj: payload = {
        'PaymentMethod': (this.PaymentMethod ? (this.PaymentMethod) : null),
        'PaymentMethods': (this.PaymentMethods.length ? (this.PaymentMethods) : []),
        'RecieptNo': (this.receiptNo) ? this.receiptNo : undefined,
        'AmountStartRange': (this.amountFrom) ? this.amountFrom : undefined,
        'AmountEndRange': (this.amountTo) ? this.amountTo : undefined,
        'PaidFromDate': (this.paidFrom) ? (this.paidFrom) : undefined,
        'PaidToDate': (this.paidTo) ? (this.paidTo) : undefined,
      }
      this.selectedValues.emit(obj);
    }
  }
}

