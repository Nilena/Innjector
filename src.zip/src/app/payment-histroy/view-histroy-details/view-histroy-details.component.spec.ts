import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewHistroyDetailsComponent } from './view-histroy-details.component';

describe('ViewHistroyDetailsComponent', () => {
  let component: ViewHistroyDetailsComponent;
  let fixture: ComponentFixture<ViewHistroyDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewHistroyDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewHistroyDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
