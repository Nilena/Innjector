import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { SharedModule } from '../shared/shared.module';

import { HistroyListingComponent } from './histroy-listing/histroy-listing.component';
import { PaymentFilterComponent } from './payment-filter/payment-filter.component';
import { ViewHistroyDetailsComponent } from './view-histroy-details/view-histroy-details.component';
import {NgxPaginationModule} from 'ngx-pagination';

export const routes: Routes = [{
  path: 'listing',
  component: HistroyListingComponent
}, {
  path: 'consolidated-receipt/:id',
  component: ViewHistroyDetailsComponent
}]

@NgModule({
  declarations: [
    HistroyListingComponent,
    PaymentFilterComponent,
    ViewHistroyDetailsComponent
  ],
  imports: [
    NgxPaginationModule,
    CommonModule,
    SharedModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forChild(routes)
  ]
})
export class PaymentHistroyModule { }
