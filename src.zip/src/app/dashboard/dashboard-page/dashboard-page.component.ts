import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { apiList, getApiUrl } from '../../core/constants/api-list';
import { ApiResponse, Profile, DashboardData } from '../../core/models/auth';
import { UtilityService } from '../../shared/services/utility.service';
import { Router } from '@angular/router';
import * as moment from 'moment';
@Component({
  selector: 'app-dashboard-page',
  templateUrl: './dashboard-page.component.html',
  styleUrls: ['./dashboard-page.component.css']
})
export class DashboardPageComponent implements OnInit {


  dashBoardDetails: any = []
  loader: boolean = false
  paymentData: any = []
  constructor(private http: HttpClient,
    private router: Router,
    private utility: UtilityService) {

  }

  ngOnInit(): void {
    this.utility.headerText$.next('Dashboard');
    this.getdashboardDetails()
  }
  /*
    author : Nilena Alexander
    desc   : to get payDetails in dashboard
    */
  getdashboardDetails() {
    //this.loader = true;
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.auth.getdashboarddata)
    this.http.get<ApiResponse>(endpoint).subscribe((data) => {
      if (data.Status == true) {
        this.paymentData = data.Data;
        if (this.paymentData && (this.paymentData.NewBillCount > 0)) {
          let msg = 'You have ' + this.paymentData.NewBillCount + ' new bill(s)';
          this.utility.alert.confirm({
            text: msg,
            title: '',
            type: 'info',
            okText: 'Ok',
            hideCancelButton: true
          })
        }
        let rmexZero = this.paymentData?.RmexSchedulePaymentDetails?.filter((el: any) => el.NextPaymentAmount <= 0).length === this.paymentData?.RmexSchedulePaymentDetails?.length;
        if (this.paymentData.RmexSchedulePaymentDetails && this.paymentData.RmexSchedulePaymentDetails.length && !rmexZero && this.paymentData.IsRmexPaymentEnable) {
          this.utility.hasRmexPlans = true;
          let firstItemAmount = this.paymentData.RmexSchedulePaymentDetails[0].NextPaymentAmount;
          let firstPayDate = moment(this.paymentData.RmexSchedulePaymentDetails[0].NextpaymentDate).format('L');
          let ifFirstTimeHasRmexPlans = this.utility.getTempData('ifFirstTimeHasRmexPlans');
          if(!ifFirstTimeHasRmexPlans) {
            this.utility.setTempData('ifFirstTimeHasRmexPlans', true);
            let message: string = this.paymentData.rmexMessage;
            if(!this.paymentData.IsRmexMultipleAccounts) {
              message = message.replace(/<date>/gi, firstPayDate);
              message = message.replace(/<payment_amt>/gi, '$$' + firstItemAmount);
            }
            message = message.replace(/<br>/gi, '');
            this.utility.alert.confirm({
              text: message,
              title: '',
              type: 'info',
              okText: 'Pay',
              cancelText: 'Cancel'
            }).then(res => {
              if (res) {
                this.router.navigate(['/payment/rmex-pay']);
              }
            })
          }
          // let rmexData = this.paymentData.RmexSchedulePaymentDetails;
          // this.showRmexNotification(rmexData);
        } else {
          this.utility.hasRmexPlans = false;
        }
      } else {
        this.utility.alert.toast({ title: data.Message, type: 'error' });
      }
      //this.loader = false;
      this.utility.loader.next(false);
    },
      (err: HttpErrorResponse) => {
        console.log(err);
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
        //this.loader = false;
        this.utility.loader.next(false);
      })
  }
}
