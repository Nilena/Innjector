import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SharedModule } from '../shared/shared.module';
import { RoleGuardService } from '../shared/services/role-guard.service';
import { CommunicationPerferenceComponent } from './communication-perference/communication-perference.component';
import { DashboardPageComponent } from './dashboard-page/dashboard-page.component';
import { SummaryPaymentComponent } from './summary-payment/summary-payment.component';
import { ScheduledPaymentsComponent } from './scheduled-payments/scheduled-payments.component';
import { ChangeCredentialsComponent } from './change-credentials/change-credentials.component';
import { SwiperModule } from 'ngx-swiper-wrapper';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ScheduledPlanDetailsComponent } from './scheduled-plan-details/scheduled-plan-details.component';
import { PlanActivityComponent } from './plan-activity/plan-activity.component';
import { TempResolver } from '../shared/resolver/temp.resolver';
import { RmexDetailsComponent } from './rmex-details/rmex-details.component';

export const routes: Routes = [
  {
    path: '', component: DashboardPageComponent,
  },
  {
    path: 'communication-pereference', component: CommunicationPerferenceComponent, canActivate: [RoleGuardService]
  },
  {
    path: 'summary', component: SummaryPaymentComponent,

  },
  {
    path: 'change-password', component: ChangeCredentialsComponent, canActivate: [RoleGuardService]
  },
  { path: 'scheduled-payment-confirmation', component: ScheduledPlanDetailsComponent, resolve: { temp: TempResolver} },
  { path: 'scheduled-payment-confirmation/:headerId', component: ScheduledPlanDetailsComponent, resolve: { temp: TempResolver} },
  {
    path: 'plan-activity/:id', component: PlanActivityComponent
  },
  {
    path: 'rmex-details/:id', component: RmexDetailsComponent
  }
]
@NgModule({
  declarations: [
    DashboardPageComponent,
    CommunicationPerferenceComponent,
    SummaryPaymentComponent,
    ScheduledPaymentsComponent,
    ChangeCredentialsComponent,
    ScheduledPlanDetailsComponent,
    PlanActivityComponent,
    RmexDetailsComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    SwiperModule,
    RouterModule.forChild(routes)
  ]
})
export class DashboardModule { }
