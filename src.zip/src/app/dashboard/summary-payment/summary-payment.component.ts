import { Component, OnInit, Input, SimpleChanges, ViewChild, ElementRef } from '@angular/core';
import { apiList, getApiUrl } from '../../core/constants/api-list';
import { ApiResponse, Profile, DashboardData, TempDataResponse } from '../../core/models/auth';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { UtilityService } from '../../shared/services/utility.service';
import { UserService } from '../../auth/services/user.service';
import { ThrowStmt } from '@angular/compiler';
import { Router } from '@angular/router';
import { CONSTANTS } from 'src/app/core/constants/constants';
@Component({
  selector: 'app-summary-payment',
  templateUrl: './summary-payment.component.html',
  styleUrls: ['./summary-payment.component.css']
})
export class SummaryPaymentComponent implements OnInit {
  paymentData: any = []
  openSub: boolean = false
  loader: boolean = false
  userDetails: Profile | null = null;
  loaderSub: boolean = false;
  showStatementHeading: boolean = false;
  hint: string = 'Review your statement for important message';
  @Input() set paymentDataType(value: DashboardData[]) {
    this.paymentData = value;
    this.checkStatementMenu();
  }

  @ViewChild('expand') expand! : ElementRef;
  @ViewChild('Balance') Balance! : ElementRef;
  constructor(private http: HttpClient,
    private utility: UtilityService,
    private router: Router,
    private userServices: UserService) { }

  ngOnInit(): void {
    this.userDetails = this.userServices.getUserInfo(true);
  }
  
  ngAfterViewInit(){
     this.Balance.nativeElement.focus();
  }


  openSelectedItem() {
    let stat = false
    if (this.paymentData && this.paymentData.DashBoardItem) {
      for (let i = 0; i < this.paymentData.DashBoardItem.length; i++) {
        if (this.paymentData.DashBoardItem[i].openStat == true) {
          stat = true;
          break;
        }
        else
          stat = false;
      }
      if (stat == true)
        this.openSub = true
      else
        this.openSub = false
    }
  }

  checkStatementMenu() {
    let facilities: any = [];
    let List = this.paymentData.DashBoardItem, count = 0, isfound = 0, i;
    if (List) {
      for (i = 0; i < List.length; i++) {
        count = 0;
        facilities.push(List[i].ClientCode);
        for (let j = 0; j < List[i].PatientBalance.length; j++) {
          List[i].PatientBalance[j].StatementName && (count++, isfound++);
          (List[i].PatientBalance[j].restricted_account_status == '0') && (List[i].hasRestricted = true);

        }
        List[i].statementMenu = count > 0 ? true : false;
      }
      this.showStatementHeading = isfound > 0 ? true : false;
    }
  }

  /*
 author : Arun Lalithambaran
 desc   : navigate
 */
  public paymentOptionSelected() {
    this.router.navigate(['/payment/pay']);
  }

  /*
 author : Nilena Alexander
 desc   : navigate
 */
  public paynow() {
    this.utility.alert.confirm({
      text: 'This will pay the balance(s) in full. Do you want to proceed?',
      title: 'Confirmation',
      type: 'warning',
      okText: 'Yes',
      cancelText: 'No'
    }).then(res => {
      if (res) {
        //this.loaderSub =true;
        this.utility.loader.next(true);
        this.savetoTemp();
      }
    })
  }
  /*
  author : Nilena Alexander
  desc   : to save to temp
  */
  savetoTemp() {
    let BillData: any = [];
    for (let i = 0; i < this.paymentData.DashBoardItem.length; i++) {
      for (let j = 0; j < this.paymentData.DashBoardItem[i].PatientBalance.length; j++) {
        BillData.push({
          AccountNumber: this.paymentData.DashBoardItem[i].PatientBalance[j].AccountNumber,
          AgencyCode: this.paymentData.DashBoardItem[i].PatientBalance[j].AgencyCode,
          AgencyName: this.paymentData.DashBoardItem[i].PatientBalance[j].AgencyName,
          AgencyPhone: this.paymentData.DashBoardItem[i].PatientBalance[j].AgencyPhone,
          ArrangementAmount: this.paymentData.DashBoardItem[i].PatientBalance[j].ArrangementAmount,
          BalanceRequiringAction: this.paymentData.DashBoardItem[i].PatientBalance[j].BalanceRequiringAction,
          BillNumber: this.paymentData.DashBoardItem[i].PatientBalance[j].BillNumber,
          ChargeHeaderRowID: this.paymentData.DashBoardItem[i].PatientBalance[j].ChargeHeaderRowID,
          ClientCode: this.paymentData.DashBoardItem[i].PatientBalance[j].ClientCode,
          ClientGroupCode: this.paymentData.DashBoardItem[i].PatientBalance[j].ClientGroupCode,
          ClientName: this.paymentData.DashBoardItem[i].PatientBalance[j].ClientName,
          ClientType: this.paymentData.DashBoardItem[i].PatientBalance[j].ClientType,
          Cnid: this.paymentData.DashBoardItem[i].PatientBalance[j].Cnid,
          CurrentBalance: this.paymentData.DashBoardItem[i].PatientBalance[j].CurrentBalance,
          DateOfService: this.paymentData.DashBoardItem[i].PatientBalance[j].DateOfService,
          FacilityID: this.paymentData.DashBoardItem[i].PatientBalance[j].FacilityID,
          GuarantorName: this.paymentData.DashBoardItem[i].PatientBalance[j].GuarantorName,
          GuarantorPeopleID: this.paymentData.DashBoardItem[i].PatientBalance[j].GuarantorPeopleID,
          IsNoScheduledPayments: this.paymentData.DashBoardItem[i].PatientBalance[j].IsNoScheduledPayments,
          IsRmex: this.paymentData.DashBoardItem[i].PatientBalance[j].IsRmex,
          IsRmexAccount: this.paymentData.DashBoardItem[i].PatientBalance[j].IsRmexAccount,
          ItemCode: this.paymentData.DashBoardItem[i].PatientBalance[j].ItemCode,
          MerchantId: this.paymentData.DashBoardItem[i].PatientBalance[j].MerchantId,
          NextPaymentDate: this.paymentData.DashBoardItem[i].PatientBalance[j].NextPaymentDate,
          PatientAccountNo: this.paymentData.DashBoardItem[i].PatientBalance[j].PatientAccountNo,
          PatientName: this.paymentData.DashBoardItem[i].PatientBalance[j].PatientName,
          PatientPeopleID: this.paymentData.DashBoardItem[i].PatientBalance[j].PatientPeopleID,
          PaymentAmount: this.paymentData.DashBoardItem[i].PatientBalance[j].PaymentAmount,
          PhysicianID: this.paymentData.DashBoardItem[i].PatientBalance[j].PhysicianID,
          PhysicianName: this.paymentData.DashBoardItem[i].PatientBalance[j].PhysicianName,
          ProcessorType: this.paymentData.DashBoardItem[i].PatientBalance[j].ProcessorType,
          RemainingBalance: this.paymentData.DashBoardItem[i].PatientBalance[j].RemainingBalance,
          ResponsibleParty: this.paymentData.DashBoardItem[i].PatientBalance[j].ResponsibleParty,
          RmexBalance: this.paymentData.DashBoardItem[i].PatientBalance[j].RmexBalance,
          ScheduledPayments: this.paymentData.DashBoardItem[i].PatientBalance[j].ScheduledPayments,
          StatementDate: this.paymentData.DashBoardItem[i].PatientBalance[j].StatementDate,
          StatementID: this.paymentData.DashBoardItem[i].PatientBalance[j].StatementID,
          StatementName: this.paymentData.DashBoardItem[i].PatientBalance[j].StatementName,
          StatementURL: this.paymentData.DashBoardItem[i].PatientBalance[j].StatementURL,
          StationCode: this.paymentData.DashBoardItem[i].PatientBalance[j].StationCode,
          UPID: this.paymentData.DashBoardItem[i].PatientBalance[j].UPID,
          restricted_account_status: this.paymentData.DashBoardItem[i].PatientBalance[j].restricted_account_status,
          txhistory: this.paymentData.DashBoardItem[i].PatientBalance[j].txhistory,
        })
      }

    }
    // BillData = Array.from(this.paymentData.DashBoardItem);
    let facilities: string[] = [];
    for (let i = 0; i < this.paymentData.DashBoardItem.length; i++) {
      facilities.push(this.paymentData.DashBoardItem[i].PatientBalance[0].FacilityID);
    }
    let Total = {
      balance: 0,
      paid: this.paymentData.BalanceRequiringAction
    }
    let Value = {
      BillData: BillData,
      facilities: facilities,
      Total: Total
    }
    let tempVal = JSON.stringify(Value);
    let payload: TempDataResponse = {
      Key: CONSTANTS.PAY_MODES.NOW,
      Value: tempVal
    }
    let endpoint = getApiUrl(apiList.temp.save);
    this.http.post<ApiResponse>(endpoint, payload).subscribe(data => {
      if (data.Status == true) {
        // this.loaderSub = false;
        this.utility.loader.next(false);
        this.utility.setTempData('tempId', data.Data);
        if (!this.userDetails?.IsGuest)
          this.router.navigate(['/payment/methods']);
        else{
          if (this.utility.isMobile()){
            this.router.navigate(['/payment-methods/electronic-check']);
          }else{
            this.router.navigate(['/payment-methods/add-payment-method']);
          }
        } 
      }
      else {
        //this.loaderSub = false;
        this.utility.loader.next(false);
        this.utility.alert.toast({ title: data.Message, type: 'error' });
      }
    },
      (err: HttpErrorResponse) => {
        //this.loaderSub = false;
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
        this.utility.loader.next(false);
      })
  }
  /*
  author : Nilena Alexander
  desc   : redirect to onlinestatements
  */
  gotoStatement(item: any) {
    let RequestData: any = {
      ClientCode: item.ClientCode,
      AccountNo: item.PatientAccountNo,
      ID: item.StatementID
    }
    let id = btoa(JSON.stringify(RequestData))
    this.router.navigate(['/online-statement/listing/' + id])

    // goto ONLINE_STATEMENT + "/"  + base64.encode(json.stringify(keyData))
  }

}
