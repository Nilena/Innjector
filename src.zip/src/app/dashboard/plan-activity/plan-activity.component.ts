import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { getApiUrl, apiList } from 'src/app/core/constants/api-list';
import { ApiResponse } from 'src/app/core/models/auth';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { ActivatedRoute } from '@angular/router';



@Component({
  selector: 'app-plan-activity',
  templateUrl: './plan-activity.component.html',
  styleUrls: ['./plan-activity.component.css']
})
export class PlanActivityComponent implements OnInit {

  public data: any;
  public details: any;
  public PlanHeaderID: any;
  endpoint: boolean = false;
  @ViewChild('plan') plan! : ElementRef;
  constructor(private http: HttpClient,
    private utility: UtilityService,
    private activateroute: ActivatedRoute) { }

  ngOnInit(): void {
    this.details = this.activateroute.snapshot.paramMap.get("id");
    this.activity();

  }
  ngAfterViewInit(){
    this.plan.nativeElement.focus();
  }
  /*
   author:Elizabeth Mathew
   dec:Plan Activity
  */

  public activity(): void {
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.auth.planActivity);
    let payload = {
      PlanHeaderId: this.details
    }
    this.http.post<ApiResponse>(endpoint, payload).subscribe((data) => {
      this.data = data;
      this.utility.loader.next(false);
    }

      , (err: HttpErrorResponse) => {
        console.log(err);
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
        this.utility.loader.next(false);
      }

    )

  }
  goback() {
    history.back();
  }
}
