import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { getApiUrl, apiList } from 'src/app/core/constants/api-list';
import { LoginResponse } from 'src/app/core/models/auth';
import { UserService } from 'src/app/auth/services/user.service';
import { REGCONSTANTS } from 'src/app/core/constants/regex-constants';
@Component({
  selector: 'app-communication-perference',
  templateUrl: './communication-perference.component.html',
  styleUrls: ['./communication-perference.component.css']
})
export class CommunicationPerferenceComponent implements OnInit {

  errorMessage: string | null = null
  loader: boolean = false
  submitted: boolean = false
  public cPForm: FormGroup;
  endpoint: boolean = false;
  @ViewChild('chosenSearch', { static: true }) private inputField: ElementRef | null = null;

  public get controls() { return this.cPForm.controls };
  constructor(private userService: UserService,
    private utility: UtilityService,
    private http: HttpClient,
    private router: Router) {

    let emailPattern = REGCONSTANTS.emailRegExp;
    this.cPForm = new FormGroup({
      email: new FormControl(null, Validators.compose([Validators.required, Validators.pattern(emailPattern)])),
      onType: new FormControl(null),
      clientCode: new FormControl(null),
      emailPrefernceID: new FormControl(null),
      healthcarePrivacyTC: new FormControl(null),
      healthcareTC: new FormControl(null),
      isDirectUpdate: new FormControl(null),
      message: new FormControl(null),
      messagePrefernceID: new FormControl(null),
      peopleID: new FormControl(null),
      prefernceID: new FormControl(null),
      serviceDeliveryTC: new FormControl(null),
      source: new FormControl(null),
      statementPrefernceID: new FormControl(null),
      statementType: new FormControl(null),
      upid: new FormControl(null),
    })
  }

  ngOnInit(): void {
    //this.utility.headerText$.next('Login');
    this.getEmail();
    this.setFocus();
  }
  /*
author : Nilena Alexander
desc   : to get email details
params :
*/
  getEmail() {
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.auth.communicationPreference);
    this.http.get<LoginResponse>(endpoint).subscribe((data) => {
      if (data.Status == true) {
        this.cPForm.patchValue(data.Data)
      } else {
        this.utility.alert.toast({ title: 'Something went wrong!', type: 'error' });
      }
      this.utility.loader.next(false);
      this.endpoint = false
    }, (err: HttpErrorResponse) => {
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.endpoint = false;
      this.utility.loader.next(false);
    })
  }

  /*
  author : Nilena Alexander
  desc   : to setFocus
  */
  setFocus(): void {
    this.inputField?.nativeElement.focus();
  }
  /*
  author : Nilena Alexander
  desc   : to submit email and username
  */
  public submit(): void {
    this.submitted = true;
    this.errorMessage = null;

    if (this.cPForm.valid) {
      this.loader = true;
      let endpoint = getApiUrl(apiList.auth.saveCommunicationPreference);
      let payload = this.cPForm.value;
      this.http.post<any>(endpoint, payload).subscribe((data) => {
        if (data.Status == true) {
          let profile = this.userService.getUserInfo();
          profile.EmailId = data.Data.email;
          this.userService.setUserInfo(profile);
          this.utility.alert.toast({ title: 'Email Updated Successfully', type: 'success' });
          this.router.navigate(['/dashboard']);
        } else {
          this.utility.alert.toast({ title: data.Message, type: 'error' });
          this.errorMessage = data.Message;
          this.submitted = false
        }
        this.endpoint = false;
        this.loader = false

      }, (err: HttpErrorResponse) => {
        console.log(err);
        this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
        this.endpoint = false;
        this.loader = false
        this.submitted = false

      })
    }
  }

}
