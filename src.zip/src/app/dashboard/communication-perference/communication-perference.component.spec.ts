import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CommunicationPerferenceComponent } from './communication-perference.component';

describe('CommunicationPerferenceComponent', () => {
  let component: CommunicationPerferenceComponent;
  let fixture: ComponentFixture<CommunicationPerferenceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CommunicationPerferenceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CommunicationPerferenceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
