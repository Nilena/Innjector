import { Component, OnInit, ViewChild,ElementRef } from '@angular/core';
import { FormControl, FormGroup, Validators, ValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import { apiList, getApiUrl } from 'src/app/core/constants/api-list';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { LoginResponse, Profile } from 'src/app/core/models/auth';
import { CustomValidation } from 'src/app/shared/utilities/custom-validator';
import { UserService } from 'src/app/auth/services/user.service';
import { CONSTANTS } from 'src/app/core/constants/constants';
@Component({
  selector: 'app-change-credentials',
  templateUrl: './change-credentials.component.html',
  styleUrls: ['./change-credentials.component.css']
})
export class ChangeCredentialsComponent implements OnInit {

  loader                   : boolean = false
  submitted                : boolean = false
  public chagePasswrdForm : FormGroup;
  endpoint                 : boolean = false;
  errorMessage             : string | null= null
  @ViewChild('chosenSearch', { static: true }) private inputField: ElementRef|null =null;
  clientToken              : string | null;
  showPassword             : boolean = false;
  showCPassword            : boolean = false;
  userInfo                 : Profile | null = null;
  public hint: string| null= null;
  public get controls() { return this.chagePasswrdForm.controls };
  constructor( private userService: UserService,
    private utility: UtilityService,
    private http   : HttpClient,
    private router : Router,
    private elementRef :ElementRef,
    private activatedRoute :ActivatedRoute){
    this.clientToken = this.activatedRoute.snapshot.paramMap.get('clientToken');
    this.userInfo    = this.userService.getUserInfo();
    this.hint=CONSTANTS.PASSWORD_HINT.PSWD_HINT;
    this.chagePasswrdForm= new FormGroup({
      UserName        : new FormControl((this.userInfo.ProfileName), Validators.compose([CustomValidation.noSpaceOnly])),
      Password        : new FormControl(null, Validators.compose([Validators.required])),
      NewPassword     : new FormControl(null, Validators.compose([Validators.required, CustomValidation.PasswordRule])), 
      ConfirmPassword : new FormControl(null, Validators.compose([Validators.required]))
    }, {validators:Validators.compose([ this.confirmPasswordValidation()]) ,updateOn: 'blur'}
    )
  } 
   ngOnInit(): void {
     this.setFocus();
  }
  
  private confirmPasswordValidation(): ValidatorFn {
    return (formGroup: AbstractControl): ValidationErrors | null => {
      let password = formGroup.get('NewPassword')?.value;
      let confirmPassword = formGroup.get('ConfirmPassword')?.value;
      if (password && confirmPassword && password != confirmPassword) {
        return { confirmPasswordNotMatching: true }
      }
      return null;
    }
  }
   



 
  /*
	author : Nilena Alexander
	desc   : to setFocus intially
	params :
  */
  setFocus(){
    this.inputField?.nativeElement.focus();
  }
  /*
	author : Nilena Alexander
	desc   : to submit email
	params :
  */
 public submit(): void {
  this.submitted = true;
  this.errorMessage =null;
  if (this.chagePasswrdForm.valid) {
    this.loader  = true;
    let endpoint = getApiUrl(apiList.auth.profileUpdate);
    let payload :any = {}
    payload  = this.chagePasswrdForm.value;
    this.http.post<LoginResponse>(endpoint, payload).subscribe((response) => {
      if (response.Status == true) {
        this.utility.alert.toast({ title:response.Message, type: 'success' });
        this.router.navigate(['/dashboard']);   
      }
       else {
        this.utility.alert.toast({ title:response.Message, type: 'error' });
        this.submitted    = false
      }
      this.endpoint = false;
      this.loader    =false
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.endpoint     = false;
      this.loader       = false
      this.submitted    = false
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
    })
  }
}
}




