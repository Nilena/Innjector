import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmexDetailsComponent } from './rmex-details.component';

describe('RmexDetailsComponent', () => {
  let component: RmexDetailsComponent;
  let fixture: ComponentFixture<RmexDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RmexDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RmexDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
