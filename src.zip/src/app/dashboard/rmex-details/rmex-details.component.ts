import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ApiResponse, Profile } from '../../core/models/auth';
import { getApiUrl, apiList } from '../../core/constants/api-list';
import { ActivatedRoute, Router } from '@angular/router';
import { UtilityService } from '../../shared/services/utility.service';
import { UserService } from 'src/app/auth/services/user.service';

@Component({
  selector: 'app-rmex-details',
  templateUrl: './rmex-details.component.html',
  styleUrls: ['./rmex-details.component.css']
})
export class RmexDetailsComponent implements OnInit {
  showPrint: boolean = false;
  routeParam: string = '';
  rmexDetails: any = [];
  today: any;
  userInfo: Profile | null = null;

  constructor(private http: HttpClient,
    private actRouter: ActivatedRoute,
    private utility: UtilityService,
    private userService: UserService,
    private router: Router) { }

  ngOnInit(): void {
    this.actRouter.params.subscribe(params => {
      this.routeParam = params['id'];
      this.routeParam ? (this.routeParam = atob(this.routeParam as string)) : null;
      this.today = new Date();
      this.userInfo = this.userService.getUserInfo();
      this.getRmexDetails();
    })

  }
  /*
author : Nilena Alexander
desc   :get rmex details from api call
*/
  getRmexDetails() {
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.dashboard.RmexPlanDetails) + 'PrimaryCaseNumber=' + this.routeParam;
    this.http.get<ApiResponse>(endpoint).subscribe((response) => {
      // let response: any = {
      //   "Data": { "TotalBalance": 1476.27, "BalanceRequiringAction": 1476.27, "ScheduledPayments": 0.0, "NewBillCount": 0, "DashBoardItem": [{ "ClientCode": "H44503", "ClientName": "QA UNIT 44503", "CurrentBalance": 1500.000000, "Balance": 1476.27, "ScheduledPayments": 0.0, "BalanceRequiringAction": 1476.27, "StatementURL": null, "ClientType": "H", "PatientBalance": [{ "PatientPeopleID": 5253381, "GuarantorPeopleID": null, "PatientName": "FDFDM ANEESH", "GuarantorName": null, "PatientAccountNo": "4577777101", "DateOfService": "2021-02-01T00:00:00", "PaymentAmount": 1500.000000, "StatementURL": null, "PhysicianName": null, "PhysicianID": null, "ClientType": "H", "Cnid": null, "UPID": 5355543, "ItemCode": "Medical_HCA1", "StationCode": null, "ClientGroupCode": "HCA", "ChargeHeaderRowID": 5422281, "ClientCode": "H44503", "CurrentBalance": 1476.27, "ScheduledPayments": null, "BalanceRequiringAction": 1476.27, "BillNumber": "4577777101", "StatementDate": "", "StatementName": null, "FacilityID": "44503", "ClientName": "QA UNIT 44503", "IsNoScheduledPayments": false, "IsRmex": false, "StatementID": null, "IsRmexAccount": false, "RmexBalance": 0.0, "AgencyCode": null, "AgencyName": null, "AgencyPhone": null, "restricted_account_status": null, "NextPaymentDate": "2021-07-15T00:00:00", "ResponsibleParty": "FDFDM ANEESH", "AccountNumber": "4577777101", "ArrangementAmount": 1500.000000, "RemainingBalance": 1476.27, "txhistory": [], "ProcessorType": "FD", "MerchantId": "44503" }], "RmexPlanIndicator": null, "RmexDirectCheckIndicator": null }], "SheduledPaymentList": null, "RmexSchedulePaymentDetails": null, "RmexdashBoard": null, "NoScheduledPaymentList": null, "IsRmexPaymentEnable": null, "IsRmexMultipleAccounts": false, "duplicateMessage": "You recently made a payment against the same item(s) for the same amount, as shown below. (You can view more details from the Payment History menu, or call @phone@ for assistance.)|If you really wish to continue with this payment, please click on Continue. Otherwise, click on Cancel. ", "duplicateMessage_x": "You recently attempted a payment against the same item(s) for the same amount, as shown below.  The status of that attempt will not be certain until overnight processing has completed.   Please check again tomorrow by accessing the Payment History menu, or call @phone@ for assistance.", "duplicatecheckstatus": true, "DuplicateContinueButton": true, "WarningMessagePaynow": null, "ShowSurvey": false, "SurveyUrl": null, "SurveyIdleTime": null, "rmexMessage": null },
      //   "Status": true, "Message": "Validation succeeded", "IsException": false
      // };
      if (response.Status == true) {
        this.rmexDetails = response.Data;
        this.utility.loader.next(false);
      }
      else {
        this.utility.alert.toast({ title: response.Message, type: 'error' });
      }
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      //this.fetchingInProgress = false;
      this.utility.loader.next(false);
    })
  }
  /*
  author : Nilena Alexander
  desc   : redirect to cancel
  */
  cancel() {
    history.back();
  }
  /*
  author : Nilena Alexander
  desc   : redirect to print 
  */
  // print() {
  // let encString = btoa(JSON.stringify({ HeaderID: this.routeParam }));
  // this.router.navigate(['/payment-plans/print/' + encString]);
  // }

  print() {
    (window as any).print();
  }
}
