import { query, style, animate, trigger, transition, AnimationMetadata, group } from '@angular/animations';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/auth/services/user.service';
import { getApiUrl, apiList } from 'src/app/core/constants/api-list';
import { ApiResponse, StanderdSliderInfo, RmexScheduledPaymentInfo, ScheduledPaymentInfo } from 'src/app/core/models/auth';
import { UtilityService } from 'src/app/shared/services/utility.service';
// import { PaymentPlanDetails } from '../scheduled-plan-details/scheduled-plan-details.component';
import { CONSTANTS } from 'src/app/core/constants/constants';

const mainLeft: any[] = [
  query(':enter, :leave', style({ position: 'fixed' }), { optional: true }),
  group([
    query(':enter', [style({ transform: 'translateX(-100%)' }), animate('1s ease-out', style({ transform: 'translateX(0%)' }))], {
      optional: true,
    }),
    query(':leave', [animate('1s ease-out', style({ transform: 'translateX(100%)' }))], {
      optional: true,
    }),
  ]),
];

const mainRight: any[] = [
  query(':enter, :leave', style({ position: 'fixed' }), { optional: true }),
  group([
    query(':enter', [style({ transform: 'translateX(100%)' }), animate('1s ease-out', style({ transform: 'translateX(0%)' }))], {
      optional: true,
    }),
    query(':leave', [animate('1s ease-out', style({ transform: 'translateX(-100%)' }))], {
      optional: true,
    }),
  ]),
];

@Component({
  selector: 'app-scheduled-payments',
  templateUrl: './scheduled-payments.component.html',
  styleUrls: ['./scheduled-payments.component.css'],
  animations: [
    trigger('mainSlide', [
      transition(':increment', mainRight),
      transition(':decrement', mainLeft),
    ])
  ]
})
export class ScheduledPaymentsComponent implements OnInit {

  public statusMap: { [key: string]: string } = CONSTANTS.statusMap;
  public statusClassMap: { [key: string]: string } = CONSTANTS.statusClassMap;
  public fetchingInProgress: boolean = false;
  public scheduledPaymentInfo: StanderdSliderInfo[] = [];
  public activeIndex: number = 0;
  public makePaymentInProgress: boolean = false;
  public savingInProgress: boolean = false;
  clickedItem : number = -1;
  clickedBtn : number = -1;

  public config = {
    slidesPerView: 1,
    centeredSlides: false,
    watchOverflow: true,
    spaceBetween: 20,
    init: true,
    // autoplay:true,
    pagination: false,
    navigation: {
      nextEl: '[data-element="swiper-button-next"]',
      prevEl: '[data-element="swiper-button-prev"]'
    },
    breakpoints: {
      // when window width is >= 320px
      765: {
        slidesPerView: 3,
        //spaceBetween: 20
      },
    }
  }

  @Input() set data(value: any) {
    if (value) {
      const rmexItems = value.RmexSchedulePaymentDetails as RmexScheduledPaymentInfo[];
      (rmexItems || []).forEach(el => {
        const data: StanderdSliderInfo = {
          IsPastDue: el.IsPastDue,
          IsCompleted: el.IsCompleted,
          AmountDue: el.AmountDue,
          AmountPaid: el.NextPaymentAmount,
          RemainingBalance: el.RemainingBalance,
          Rmx: true,
          Percentage: 0,
          InstallmentDate: el.NextpaymentDate,
          PlanAmount: 0,
          HeaderID: el.PrimaryCaseNumber,
          PlanStatus: ''
        }
        this.scheduledPaymentInfo.push(data);
      })
      const normalItems = value.SheduledPaymentList as ScheduledPaymentInfo;
      (normalItems?.ScheduledPayment || []).forEach(el => {
        const data: StanderdSliderInfo = {
          AmountDue: el.NextPaymentAmount,
          AmountPaid: el.AmountPaid,
          RemainingBalance: el.RemainingBalance,
          Rmx: false,
          InstallmentDate: el.InstallmentDate,
          PlanAmount: el.PlanAmount,
          Percentage: this.getPercentage(el.AmountPaid, el.PlanAmount),
          HeaderID: el.HeaderID,
          PlanStatus: el.PlanStatus
        }
        this.scheduledPaymentInfo.push(data);
      })
    }
  }

  constructor(
    private utility: UtilityService,
    private http: HttpClient,
    private router: Router) {
  }

  ngOnInit(): void {
  }

 
  public gotPlanDetails(plan: StanderdSliderInfo,i:number) {
    if (plan.Rmx) {
      let header = btoa(JSON.stringify(plan.HeaderID));
      this.router.navigate(['/dashboard/rmex-details/' + header]);
      return;
    }
    this.clickedItem = i;
    this.savingInProgress = true;
    let endpoint = getApiUrl(apiList.temp.save);
    let payload = {
      Key: CONSTANTS.PAY_MODES.ATTACH,
      Value: JSON.stringify({
        BillData: [],
        HeaderID: plan.HeaderID,
        Total: { balance: 0, paid: 0 },
      })
    };
    this.http.post<ApiResponse>(endpoint, payload).subscribe((response) => {
      this.savingInProgress = false;
      this.utility.setTempData('tempId', response.Data);
      this.router.navigate(['/dashboard/scheduled-payment-confirmation'])
    }, (err: HttpErrorResponse) => {
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.savingInProgress = false;
    })
  }

  private getPercentage(value: number, total: number): number {
    return Math.round((value / total) * 100);
  }

 
  public makePayment(i:number) {
    this.makePaymentInProgress = true;
    this.clickedBtn = i ;
    let endpoint = getApiUrl(apiList.temp.save);
    let payload = {
      Key: CONSTANTS.PAY_MODES.NOW,
      Value: JSON.stringify({
        BillData: [],
        Total: { balance: 0, paid: 0 },
        isRmex: true
      })
    };
    this.http.post<ApiResponse>(endpoint, payload).subscribe((response) => {
      this.makePaymentInProgress = false;
      this.utility.setTempData('tempId', response.Data);
      this.router.navigate(['/payment/rmex-pay'])
    }, (err: HttpErrorResponse) => {
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.makePaymentInProgress = false;
    })
  }

}
