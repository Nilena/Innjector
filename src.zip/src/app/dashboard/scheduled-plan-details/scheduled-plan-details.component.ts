import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/auth/services/user.service';
import { getApiUrl, apiList } from 'src/app/core/constants/api-list';
import { ApiResponse, Profile, PaymentPlanDetails, MakePaymentHeaderList } from 'src/app/core/models/auth';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { CONSTANTS } from 'src/app/core/constants/constants';

@Component({
  selector: 'app-scheduled-plan-details',
  templateUrl: './scheduled-plan-details.component.html',
  styleUrls: ['./scheduled-plan-details.component.css']
})
export class ScheduledPlanDetailsComponent implements OnInit {

  private headerId: string | null = null;
  private tempId: string | null;
  private tempData: any;
  public fetchingInProgress: boolean = false;
  public paymentPlanDetails: PaymentPlanDetails | null = null;
  public MakePaymentHeaderList: MakePaymentHeaderList | null = null;
  userInfoData: Profile | null = null;
  id: any;
  public totalAmount: number = 0;
  public paymentMethodCount: number = 0;

  public classListMap: any = {
    "Completed": "status--completed",
    "Pending": "status--pending",
    "Scheduled": "status--sheduled",
    "Paid": "status--paid"
  }

  constructor(
    private utility: UtilityService,
    private http: HttpClient,
    private userService: UserService,
    private router: Router,
    private activatedRoute: ActivatedRoute) {
    this.tempId = this.utility.getTempData('tempId');
  }

  ngOnInit(): void {
    let headerId = this.activatedRoute.snapshot.paramMap.get('headerId');
    this.userInfoData = this.userService.getUserInfo();
    this.getPaymentMethodCount();
    if (this.tempId) {
      headerId ? (this.headerId = atob(headerId as string)) : null;
      this.getTempData();
    } else if (headerId) {
      this.tempData = {};
      this.headerId = atob(headerId as string);
      this.getPaymentPlanDetails();
    }
  }

  public getPaymentMethodCount() {
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.payment.paymentMethodCount);
    this.http.get<ApiResponse>(endpoint).subscribe((response) => {
      if (response.Status == true) {
        this.paymentMethodCount = response.Data;
      }
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.utility.loader.next(false);
    })
  }

  public getTempData() {
    //this.fetchingInProgress = true;
    this.utility.loader.next(true);
    let endpoint = getApiUrl(apiList.temp.get + this.tempId);
    this.http.get<any>(endpoint).subscribe((response) => {
      if (response.Status == true) {
        this.tempData = response.Data;
        this.tempData.Value = JSON.parse(this.tempData.Value);
        this.headerId = this.headerId || this.tempData.Value.HeaderID;
        this.getPaymentPlanDetails();
      } else {
        this.utility.alert.toast({ title: response.Message, type: 'error' });
      }
      // this.fetchingInProgress = false;
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      //this.fetchingInProgress = false;
      this.utility.loader.next(false);
    })
  }
  print() {
    let encString = btoa(JSON.stringify({ HeaderID: this.headerId }));

    this.router.navigate(['/payment-plans/print/' + encString]);
  }
  edit() {
    this.utility.loader.next(true);
    let facilities: string[] = [];
    this.paymentPlanDetails?.MakePaymentHeaderList.forEach(el => {
      facilities.push(el.ClientCode);
    })
    this.tempData.Key = this.tempData.Key || CONSTANTS.PAY_MODES.ATTACH;
    this.tempData.Value = this.tempData.Value || {};
    this.tempData.Value['facilities'] = facilities;
    this.tempData.Value['HeaderID'] = this.headerId;
    this.tempData.Value['ProcessorType'] = this.paymentPlanDetails?.MakePaymentHeaderList[0]?.ProcessorType;
    this.tempData.Value['PaymentTokenId'] = this.paymentPlanDetails?.MakePaymentHeaderList[0]?.PaymentTokenId;
    let payload = {
      ...this.tempData,
      Value: JSON.stringify(this.tempData.Value)
    }
    let endpoint = getApiUrl(apiList.temp.save);
    this.http.post<ApiResponse>(endpoint, payload).subscribe((response) => {
      this.utility.setTempData('tempId', response.Data);
      if (this.paymentMethodCount == 0) {
        this.router.navigate(['/payment-methods/electronic-check']);
      } else {
        this.router.navigate(['/payment/methods']);
      }
    }, (err: HttpErrorResponse) => {
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      this.utility.loader.next(false);
    })
  }

  getActivityList(headerID: any) {
    let endpoint = getApiUrl(apiList.dashboard.PlanActivityList);
    let payload = { PlanHeaderId: headerID }
    this.http.post<ApiResponse>(endpoint, payload).subscribe((response) => {
      if (response.Status == true) {
        // this.getActivityList();
        // this.paymentPlanDetails = response.Data as PaymentPlanDetails;
        // this.MakePaymentHeaderList = this.paymentPlanDetails.MakePaymentHeaderList[0];

        // this.utility.alert.toast({ title: response.Message, type: 'success' });
      } else {
        this.utility.alert.toast({ title: response.Message, type: 'error' });
      }
      //this.fetchingInProgress = false;
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      //this.fetchingInProgress = false;
      this.utility.loader.next(false);
    })
  }
  public getPaymentPlanDetails() {
    //this.fetchingInProgress = true;
    this.utility.loader.next(true);
    let encString = btoa(JSON.stringify({ HeaderID: this.headerId }));
    let endpoint = getApiUrl(apiList.dashboard.getPaymentPlanDetails + encString);
    this.http.get<ApiResponse>(endpoint).subscribe((response) => {
      if (response.Status == true) {
        this.id = response.Data.PaymentPlanHeaderDetails.PlanHeaderID;
        this.getActivityList(this.headerId);
        this.openAllCollapsedItems();
        this.paymentPlanDetails = response.Data as PaymentPlanDetails;
        this.MakePaymentHeaderList = this.paymentPlanDetails.MakePaymentHeaderList[0];

        this.totalAmount = this.paymentPlanDetails?.ScheduledInstallmentList.reduce((total: number, item: any) => {
          return total + item.AmountPaid
        }, 0)
        // this.utility.alert.toast({ title: response.Message, type: 'success' });
      } else {
        this.utility.alert.toast({ title: response.Message, type: 'error' });
      }
      //this.fetchingInProgress = false;
      this.utility.loader.next(false);
    }, (err: HttpErrorResponse) => {
      console.log(err);
      this.utility.alert.toast({ title: err?.error?.message, type: 'error' });
      //this.fetchingInProgress = false;
      this.utility.loader.next(false);
    })
  }
  /*
   author:Nilena Aelxander
   dec:to go back
   */
  cancel() {
    if (!this.tempId) {
      this.router.navigate(['/payment-plans/list'])
    } else {
      let loginConfig = this.utility.getTempData(CONSTANTS.APP_CONFIG.login_config);
      if (loginConfig && (loginConfig.eLogin == 1 || loginConfig.eLogin == 2))
        this.router.navigate(['/dashboard'])
      else
        window.history.back();
    }
    // this.router.navigate(['/dashboard/scheduled-payment-confirmation' + JSON.parse(this.headerId)])
  }
  headerIdpass() {
    //this.router.navigate('/plan-activity',"this.paymentPlanDetails.PlanHeaderID")
    this.router.navigate([('/dashboard/plan-activity/' + this.id)])
  }
  private openAllCollapsedItems() {
    this.paymentPlanDetails?.MakePaymentHeaderList.forEach(el => {
      el._open = true;
    })
  }
}


