export const environment = {
  production: true,
  apiDomain:(window as any).apiDomain,
  loginDomain:(window as any).loginDomain,
  mhoDomain:(window as any).mhoDomain,
  webServer: (window as any).webServer
};
